def find_max_palindrome_substring(text: str) -> str:
    size = len(text)
    table = [[False for _ in range(size)] for _ in range(size)]
    result_length = 1
    result_start = 0

    # Diagonal initialization
    for idx in range(size):
        table[idx][idx] = True

    # Handle pairs
    for idx in range(size - 1):
        if text[idx] == text[idx + 1]:
            table[idx][idx + 1] = True
            result_length = 2
            result_start = idx

    # Iterate over substring lengths
    for substr_len in range(3, size + 1):
        for left in range(size - substr_len + 1):
            right = left + substr_len - 1
            if text[left] == text[right] and table[left + 1][right - 1]:
                table[left][right] = True
                if substr_len > result_length:
                    result_length = substr_len
                    result_start = left

    return text[result_start:result_start + result_length]