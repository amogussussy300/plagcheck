def compute_longest_palindromic(s_input: str) -> str:
    str_len = len(s_input)
    if str_len <= 1:
        return s_input

    # Initialize palindrome matrix
    pal_matrix = [[False] * str_len for _ in range(str_len)]
    longest_so_far = 1
    start_pos = 0

    for i in range(str_len):
        pal_matrix[i][i] = True  # All single letters are palindromes

    # Check adjacent characters
    for i in range(str_len - 1):
        if s_input[i] == s_input[i + 1]:
            pal_matrix[i][i + 1] = True
            longest_so_far = 2
            start_pos = i

    # Dynamically fill the rest
    current_max = 3
    while current_max <= str_len:
        for i in range(str_len - current_max + 1):
            j = i + current_max - 1
            # Ensure inner substring is a palindrome
            if s_input[i] == s_input[j] and pal_matrix[i + 1][j - 1]:
                pal_matrix[i][j] = True
                if (j - i + 1) > longest_so_far:
                    longest_so_far = j - i + 1
                    start_pos = i
        current_max += 1  # Increment length

    return s_input[start_pos:start_pos + longest_so_far]