#include <iostream>
#include <vector>

bool tree = true;

void dfs (int v, std::vector<std::vector<int>> g, std::vector<bool>& used, 
int p = -1) {
  used[v] = true;
  for (auto to : g[v]) {
    if (!tree) {
      return;
    }
    else if (used[to] && to != p) {
      tree = false;
      return;
    }
    else if (!used[to]) {
      dfs(to, g, used, v);
    }
  }
}

int main() {
    int n = 0;
    int m = 0;
    std::cin >> n >> m;
    
    std::vector<std::vector<int>> g(n);
    std::vector<bool> used(n, false);
  
    for (int i = 0; i < m; ++i){
      int u = 0;
      int v = 0;
      std::cin >> u >> v;
      --u;
      --v;
      g[u].push_back(v);
      g[v].push_back(u);
    }
    
    dfs(0, g, used);
    for (int i = 0; i < n; ++i) {
      if (!used[i]) {
          tree = false;
        }
      }
    if (tree) {
      std::cout << "YES";
    }
    else {
      std::cout << "NO";
    }
}