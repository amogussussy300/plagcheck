#include <iostream>
#include <vector>

//int INF = 1e6 +1;
int answer = 0;

void floid (int n, std::vector<std::vector<int>>& dist) {
    for (int k = 0; k < n; ++k) {
       for (int i = 0; i < n; ++i) {
           for (int j = 0; j < n; ++j) {
               if (dist[i][j] < dist[i][k] + dist[k][j]) {
                  dist[i][j] = dist[i][k] + dist[k][j];
               }
               answer = std::max(answer, dist[i][j]);
            }
        }
    }
}

int main(){
    int n = 0;
    int m = 0;
    std::cin >> n >> m;
    std::vector<std::vector<int>> dist (n, std::vector<int> (n, -10001)); 

    for (int i = 0; i < m; ++i){
        int b = 0;
        int e = 0;
        std::cin >> b >> e;
        --b;
        --e;
        dist[b][e] = 1;
    }
    
    floid(n, dist);
    std::cout << answer;
}