#include <iostream>
#include <vector>

int16_t answer = 0;

void floid (int n, std::vector<std::vector<int16_t>>& dist) {
    for (int k = 0; k < n; ++k) {
       for (int i = 0; i < n; ++i) {
           for (int j = 0; j < n; ++j) {
               if (dist[i][j] < dist[i][k] + dist[k][j]) {
                  dist[i][j] = dist[i][k] + dist[k][j];
               }
               answer = std::max(answer, dist[i][j]);
            }
        }
    }
}

int main(){
    int n = 0;
    int m = 0;
    std::cin >> n >> m;
    std::vector<std::vector<int16_t>> dist (n, std::vector<int16_t> (n, -1000001)); 

    for (int i = 0; i < m; ++i){
        int16_t b = 0;
        int16_t e = 0;
        std::cin >> b >> e;
        --b;
        --e;
        dist[b][e] = 1;
    }
    
    floid(n, dist);
    std::cout << answer;
}