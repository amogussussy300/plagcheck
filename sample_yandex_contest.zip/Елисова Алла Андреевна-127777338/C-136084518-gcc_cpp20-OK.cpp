#include <iostream>
#include <vector>
#include <queue>

int INF = 1e9 + 1;

void diij(int start, std::vector<std::vector<std::pair<int, int>>>& g, std::vector<int>& prev, 
std::vector<int>& dist) {
    
  std::priority_queue<std::pair<int, int>> q;
  dist[start] = 0; 
  q.push({0, start});
  while (!q.empty()) {
    int v = q.top().second;
    int cur_dist = -q.top().first;
    q.pop();
    if (cur_dist > dist[v]) {
      continue;
    }
    for (int j = 0; j < g[v].size(); ++j) {
      int to = g[v][j].first;
      int cost = g[v][j].second;
      if (dist[v] + cost < dist[to]) {
        dist[to] = dist[v] + cost;
        prev[to] = v;
        q.push({-dist[to], to});
      }
    }
  }
}

int main() {
  int n = 0;
  int s = 0;
  int m = 0;
  std::cin >> n >> s >> m;
  --s;
  
  std::vector<std::vector<std::pair<int, int>>> g(n);
  std::vector<int> dist(n, INF);
  std::vector<int> prev(n, -1);

  for (int i = 0; i < m; ++i) {
    int a = 0;
    int b = 0;
    std::cin >> a >> b;
    --a;
    --b;
    g[b].push_back({a, 1});
  }

  diij(s, g, prev, dist);
  
  for (int i = 0; i < n; ++i) {
      if (dist[i] != INF) {
        std::cout << dist[i] << ' ';
      }
      else {
          std::cout << -1 << ' ';
      }
  }
}