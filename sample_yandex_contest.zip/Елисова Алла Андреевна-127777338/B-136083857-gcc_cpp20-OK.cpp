#include <iostream>
#include <vector>
#include <queue>

void bfs (int s, std::vector<std::vector<int>> children, std::vector<int>& dist){
    std::queue<int> q;
    dist[s] = 0;
    q.push(s);
    while (!q.empty()){
        auto elem = q.front();
        q.pop();
        for (auto& to : children[elem]){
            if (dist[to] == -1){
                q.push(to);
                dist[to] = dist[elem] + 1;
            }
        }
    }
}

int main(){
    int n = 0;
    std::cin >> n;
    std::vector<std::vector<int>> children (n + 1);
    std::vector<int> dist(n + 1, -1);
    
    for (int i = 2; i <= n; ++i){
        int v = 0;
        std::cin >> v;
        children[v].push_back(i);
    }
    
    
    bfs(1, children, dist);
    
    int answer = 0;
    int count = 0;
    std::vector<int> list;
    
    for (int i = 0; i <=n ; ++i){
        answer = std::max(answer, dist[i]);
    }
    
    for (int i = 0; i <= n; ++i){
        if (dist[i] == answer){
            ++count;
            list.push_back(i);
        }
    }
    
    std::cout << answer << '\n' << count << '\n';
    for (int i = 0; i < list.size(); ++i){
        std::cout << list[i] << ' ';
    }
    
}