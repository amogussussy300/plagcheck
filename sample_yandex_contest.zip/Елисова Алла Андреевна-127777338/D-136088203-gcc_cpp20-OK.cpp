#include <iostream>
#include <vector>
#include <queue>

int main() {
	int n = 0;
	int m = 0;
	std::cin >> n >> m;

	std::vector<std::vector<int>> adj(n);
	std::vector<int> in_degree(n, 0);

	for (int i = 0; i < m; ++i) {
		int b, e;
		std::cin >> b >> e;
		--b;
		--e;
		adj[b].push_back(e);
		++in_degree[e];
	}

	std::queue<int> q;
	std::vector<int> top_order;
	std::vector<int> max_dist(n, 0);

	for (int i = 0; i < n; ++i) {
		if (in_degree[i] == 0) {
			q.push(i);
		}
	}

	while (!q.empty()) {
		int u = q.front();
		q.pop();
		top_order.push_back(u);

		for (int v : adj[u]) {
			if (--in_degree[v] == 0) {
				q.push(v);
			}
			
			if (max_dist[v] < max_dist[u] + 1) {
				max_dist[v] = max_dist[u] + 1;
			}
		}
	}

	int answer = 0;
	for (int d : max_dist) {
		answer = std::max(answer, d);
	}

	std::cout << answer;
}