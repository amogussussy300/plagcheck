#include <iostream>
#include <vector>

bool cycle = false;

void dfs (int v, std::vector<std::vector<int>> g, std::vector<bool>& used, 
std::vector <int>& p) {
  used[v] = true;
  for (auto to : g[v]) {
    if (!used[to]) {
      p[to] = v;
      dfs(to, g , used, p);
    } 
    else if (used[to] && to != p[v]) {
        cycle = true;
    }
  }
}

int main() {
    int n = 0;
    int m = 0;
    std::cin >> n >> m;
    
    std::vector<std::vector<int>> g(n);
    std::vector<bool> used(n, false);
    std::vector<int> p(n, -1);
  
    for (int i = 0; i < m; ++i){
      int u = 0;
      int v = 0;
      std::cin >> u >> v;
      --u;
      --v;
      g[u].push_back(v);
      g[v].push_back(u);
    }
    
    for (int i = 0; i < n; ++i){
        if (cycle){
            break;
        }
        if (!used[i]){
            dfs(i, g, used, p);
        }
    }
    
    if (!cycle){
        std::cout << "YES";
    }
    else{
        std::cout << "NO";
    }
}