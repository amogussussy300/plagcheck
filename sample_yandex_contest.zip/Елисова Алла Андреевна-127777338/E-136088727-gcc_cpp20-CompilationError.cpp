#include <iostream>
#include <vector>

bool flag = false;

void check_binarity(int n, std::vector<std::vector<int>> g, std::vector<int>& metka, int v){
    for (int to : g[v]){
        if (flag){
            return;
        }
        if (!metka[to]){
            metka[to] = 3 - metka[v];
            check_binarity(n, g, metka, to);
        }
        else if (metka[to] == metka[v]){
            flag = true;
            return;
        }
    }
    
    for (int i = 0; i < n; ++i) {
     if (flag) {
      std::cout << 0;
      break;
     }
     if (!metka[i]) {
      metka[i] = 1;
      check_binarity(n, g, metka, i);
     }
    }
    if (!flag) {
     std::cout << 1;
    }
}

int main(){
    int n = 0;
    int m = 0;
    std::cin >> n >> m;
    std::vector<std::vector<int>> g (n);
    std::vector<int> metka (n);
    
    for (int i = 0; i < m; ++i){
        int v1 = 0;
        int v2 = 0;
        std::cin >> v1 >> v2;
        --v1;
        --v2;
        g[v1].push_back(v2);
        g[v2].push_back(v1);
        check_binarity(n, g, metka, 0)
    }
}
