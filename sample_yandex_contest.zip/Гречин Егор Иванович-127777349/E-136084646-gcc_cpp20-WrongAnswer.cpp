#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct DSU {
    vector<int> parent;
    vector<int> rank;
    vector<int> parity;

    DSU(int n) {
        parent.resize(n);
        rank.resize(n, 0);
        parity.resize(n, 0);
        for (int i = 0; i < n; ++i) {
            parent[i] = i;
        }
    }

    int find(int u) {
        if (parent[u] != u) {
            int orig_parent = parent[u];
            parent[u] = find(parent[u]);
            parity[u] ^= parity[orig_parent];
        }
        return parent[u];
    }

    bool unite(int u, int v) {
        int root_u = find(u);
        int root_v = find(v);

        if (root_u == root_v) {
            return (parity[u] != parity[v]);
        } else {
            if (rank[root_u] < rank[root_v]) {
                swap(root_u, root_v);
                swap(u, v);
            }
            parent[root_v] = root_u;
            parity[root_v] = (parity[u] + parity[v] + 1) % 2;
            if (rank[root_u] == rank[root_v]) {
                rank[root_u]++;
            }
            return true;
        }
    }
};

int main() {
    int n, m;
    cin >> n >> m;

    DSU dsu(n);
    string result;

    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        u--; v--;

        bool is_bipartite = dsu.unite(u, v);
        result += (is_bipartite ? '1' : '0');
    }

    cout << result << endl;

    return 0;
}