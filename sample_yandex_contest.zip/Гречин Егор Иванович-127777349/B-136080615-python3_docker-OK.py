import sys
from collections import deque

n = int(sys.stdin.readline())
children = [[] for _ in range(n + 1)]
for i in range(2, n + 1):
    p = int(sys.stdin.readline())
    children[p].append(i)

dist = [0] * (n + 1)
queue = deque([1])

while queue:
    u = queue.popleft()
    for v in children[u]:
        dist[v] = dist[u] + 1
        queue.append(v)

max_dist = max(dist[1: n+1])
nodes = [i for i in range(1, n+1) if dist[i] == max_dist]
nodes.sort()

print(max_dist)
print(len(nodes))
print(' '.join(map(str, nodes)))