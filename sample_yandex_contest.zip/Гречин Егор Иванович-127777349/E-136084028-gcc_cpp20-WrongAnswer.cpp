#include <iostream>
#include <vector>
using namespace std;

vector<int> parent;
vector<int> color;

int find(int u) {
    if (parent[u] != u) {
        int orig_parent = parent[u];
        parent[u] = find(parent[u]);
        color[u] ^= color[orig_parent];
    }
    return parent[u];
}

int main() {
    int n, m;
    cin >> n >> m;
    parent.resize(n + 1);
    color.resize(n + 1, 0);
    for (int i = 1; i <= n; ++i) {
        parent[i] = i;
    }
    string result;
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        int pu = find(u);
        int pv = find(v);
        if (pu == pv) {
            if (color[u] == color[v]) {
                result += '0';
            } else {
                result += '1';
            }
        } else {
            parent[pu] = pv;
            color[pu] = (color[u] + color[v] + 1) % 2;
            result += '1';
        }
    }
    cout << result << endl;
    return 0;
}