import sys
from collections import defaultdict, deque

n, m = map(int, sys.stdin.readline().split())
graph = defaultdict(list)
in_degree = [0] * (n + 1)
for _ in range(m):
    b, e = map(int, sys.stdin.readline().split())
    graph[b].append(e)
    in_degree[e] += 1

dist = [0] * (n + 1)
q = deque()
for i in range(1, n + 1):
    if in_degree[i] == 0:
        q.append(i)

while q:
    u = q.popleft()
    for v in graph[u]:
        if dist[v] < dist[u] + 1:
            dist[v] = dist[u] + 1
        in_degree[v] -= 1
        if in_degree[v] == 0:
            q.append(v)

print(max(dist))