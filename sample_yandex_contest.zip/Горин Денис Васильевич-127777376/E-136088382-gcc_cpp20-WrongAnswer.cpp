#include <iostream>
#include <vector>
#include <stack>

std::vector<std::vector<std::pair<int, int>>> v;
std::vector<int> color;
bool check(int cur, int time) {
    for (auto i : v[cur]) {
        if (i.second > time) continue;
        if (color[i.first] == color[cur]) return true;
        if (color[i.first] == 0) {
            color[i.first] = 3 - color[cur];
            if (check(i.first, time)) return true;
        }
    } 
    return false;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    v.resize(n);

    for (int i = 0; i < m; ++i) {
        int q1, q2;
        std::cin >> q1 >> q2;
        --q1; --q2;
        v[q1].push_back({q2, i});
        v[q2].push_back({q1, i});
    }

    int l = 0, r = m, mid;
    while (r - l > 1) {
        // std::cout << l << ' ' << r << ' ' << mid << '\n';;
        mid = (l + r) / 2;

        color.assign(n, 0);
        bool flag = false;
        for (int i = 0; i < color.size(); ++i) {
            if (color[i] == 0) {
                color[i] = 1;
                if (check(i, mid)) {flag = true; break;}
            }
        }
        if (flag) {
            l = mid;
        }
        else {
            r = mid;
        }
        // std::cout << l << ' ' << r << ' ' << m << '\n';;
    }
    // std::cout << mid;
    for (int i = 0; i <= r; ++i) std::cout << 1;
    for (int i = r+1; i < m; ++i) std::cout << 0;
    return 0;
}