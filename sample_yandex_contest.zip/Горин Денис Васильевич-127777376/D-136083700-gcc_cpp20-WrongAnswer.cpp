#include <iostream>
#include <vector>
#include <queue>

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> v(n);
    std::vector<std::vector<int>> vrev(n);

    for (int i = 0; i < m; ++i) {
        int q1, q2;
        std::cin >> q1 >> q2;
        --q1; --q2;
        v[q1].push_back(q2);
        vrev[q2].push_back(q1);
    }

    std::vector<int> used(n, -1);
    used[0] = 0;
    std::pair<int, int> mx {0, 0};
    std::queue<int> q;
    q.push(0);

    while (!q.empty()) {
        int cur = q.front();
        q.pop();
        if (used[cur] > mx.first) {
            mx = {used[cur], cur};
        }

        for (int i : vrev[cur]) {
            if (used[i] == -1) {
                used[i] = used[cur]+1;
                q.push(i);
            }
        }
    }

    used.assign(n, -1);
    used[mx.second] = 0;
    q.push(mx.second);
    mx.first = 0;
     
    while (!q.empty()) {
        int cur = q.front();
        q.pop();
        /// std::cout << cur << '\n';
        if (used[cur] > mx.first) {
            mx = {used[cur], cur};
        }

        for (int i : v[cur]) {
            /// std::cout << i << ' ' << used[i] << '\n';
            if (used[i] == -1) {
                used[i] = used[cur]+1;
                q.push(i);
            }
        }
    }

    std::cout << mx.first;
    return 0;
}