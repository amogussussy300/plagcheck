#include <iostream>
#include <vector>
#include <queue>

int main() {
    int n, s, m;
    std::cin >> n >> s >> m;
    --s;

    std::vector<std::vector<int>> v(n);

    for (int i = 0; i < m; ++i) {
        int q1, q2;
        std::cin >> q1 >> q2;
        --q1; --q2;
        v[q2].push_back(q1);
    }

    std::vector<int> used(n, -1);
    used[s] = 0;
    std::queue<int> q;
    q.push(s);

    while (!q.empty()) {
        int cur = q.front();
        q.pop();
        
        for (int i : v[cur]) {
            if (used[i] == -1) {
                used[i] = used[cur]+1;
                q.push(i);
            }
        }
    }

    for (int i : used) {
        std::cout << i << ' ';
    }
    return 0;
}