#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

int main() {
    int n;
    std::cin >> n;
    std::vector<std::vector<int>> v(n);

    for (int i = 1; i < n; ++i) {
        int parent;
        std::cin >> parent;
        --parent;
        v[parent].push_back(i);
    }

    int max_depth{0};
    std::vector<int> verts;
    std::stack<std::pair<int, int>> q;
    q.push({0, 0});
    while (!q.empty()) {
        std::pair<int, int> cur = q.top();
        q.pop();

        if (cur.second > max_depth) {
            max_depth = cur.second;
            verts.clear();
        }
        if (cur.second == max_depth) {
            verts.push_back(cur.first);
        }

        for (int i : v[cur.first]) {
            q.push({i, cur.second+1});
        }
    }

    // ort(verts.begin(), verts.end());

    std::cout << max_depth << '\n';
    std::cout << verts.size() << '\n';
    for (int i : verts) std::cout << i+1 << ' ';
    return 0;
}