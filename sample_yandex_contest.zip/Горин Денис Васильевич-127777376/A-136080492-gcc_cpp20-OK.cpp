#include <iostream>
#include <vector>

std::vector<std::vector<int>> v;
std::vector<bool> used;

bool dfs(int cur, int parent) {
    if (used[cur] == 1) return true;
    if (used[cur] == 2) return false;

    used[cur] = 1;

    for (int i : v[cur]) if (i != parent && dfs(i, cur)) return true;

    used[cur] = 2;
    return false;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    v.resize(n);
    used.assign(n, false);

    for (int i = 0; i < m; ++i) {
        int q1, q2;
        std::cin >> q1 >> q2;
        --q1; --q2;
        v[q1].push_back(q2);
        v[q2].push_back(q1);
    }

    if (dfs(0, -1)) {
        std::cout << "NO\n";
        return 0;
    }

    for (int i = 1; i < n; ++i) {
        if (used[i]) continue;

        std::cout << "NO\n";
        return 0;
    }

    std::cout << "YES\n";
    return 0;
}