#include <iostream>
#include <vector>
#include <queue>

std::vector<std::vector<int>> v;
std::vector<int> used;
int max_depth {0};

int bfs(int cur) {
    if (used[cur] != 0) return used[cur];

    int mx {0};
    for (int i : v[cur]) {
        mx = std::max(mx, bfs(i));
    }

    ++mx;
    max_depth = std::max(max_depth, mx);
    used[cur] = mx;
    return mx;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    v.resize(n);
    used.assign(n, 0);

    for (int i = 0; i < m; ++i) {
        int q1, q2;
        std::cin >> q1 >> q2;
        --q1; --q2;
        v[q1].push_back(q2);
    }

    for (int i = 0; i < n; ++i) {
        if (used[i] == 0) bfs(i);
    }

    std::cout << max_depth-1;
    return 0;
}