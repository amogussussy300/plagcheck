#include <iostream>
#include <vector>
#include <queue>

int main() {
    int a, s, d = 0;
    std::cin >> a >> s >> d;
    std::vector<std::vector<int>> qwe(a + 1);
    for (int i = 0; i < d; i++) {
        int a, b = 0;
        std::cin >> a >> b;
        qwe[b].push_back(a);
    }
    std::vector<int> asd(a + 1, -1);
    std::queue<int> q;
    q.push(s);
    asd[s] = 0;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v: qwe[u]) {
            if (asd[v] == -1) {
                asd[v] = asd[u] + 1; // ne zabub
                q.push(v);
            }
        }
    }
    for (int i = 1; i <= a; i++) {
        std::cout << asd[i] << " ";
    }
    std::cout << std::endl;
    return 0;
}