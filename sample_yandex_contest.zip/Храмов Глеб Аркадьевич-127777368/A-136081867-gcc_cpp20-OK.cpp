#include <iostream>
#include <vector>
#include <queue>

std::vector<std::vector<int>> g;

int isTree(int n, int m) {
    if (m != n - 1) {
        return 0;
    }
    std::vector<int> v(n + 1, 0);
    std::queue<int> q;
    q.push(1);
    v[1] = 1;
    int resss = 1;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int x : g[u]) {
            if (!v[x]) {
                v[x] = 1;
                q.push(x);
                resss++;
            }
        }
    }
    if (resss == n) {
        return 1;
    }
    else {
        return 0;
    }
}

int main() {
    int n, m = 0;
    std::cin >> n >> m;
    g.resize(n + 1);
    for (int i = 0; i < m; i++) {
        int q, w;
        std::cin >> q >> w;
        g[q].push_back(w);
        g[w].push_back(q);
    }
    if (isTree(n, m)) {
        std::cout << "YES";
    }
    else {
        std::cout << "NO";
    }
    return 0;
}