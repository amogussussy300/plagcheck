#include <iostream>
#include <vector>
#include <queue>

int main() {
    int n, m = 0;
    std::cin >> n >> m;
    std::vector<std::vector<int>> g(n + 1);
    std::vector<int> arrayy(n + 1, 0);
    for (int i = 0; i < m; i++) {
        int b, e = 0;
        std::cin >> b >> e;
        g[b].push_back(e);
        arrayy[e]++;
    }
    std::queue<int> q;
    for (int i = 1; i <= n; i++) {
        if (arrayy[i] == 0) {
            q.push(i);
        }
    }
    std::vector<int> asd;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        asd.push_back(u);
        for (int v : g[u]) {
            arrayy[v]--;
            if (arrayy[v]) { // pridf
                q.push(v);
            }
        }

    }
    std::vector<int> qwe(n + 1, 0);
    for (int u : asd) {
        for (int v : g[u]) {
            if (qwe[v] < qwe[u] + 1) {
                qwe[v] = qwe[u] + 1;
            }
        }
    }
    int maxx = 0;
    for (int tempor : qwe) {
        if (tempor > maxx) {
            maxx = tempor;
        }
    }
    std::cout << maxx;
}

