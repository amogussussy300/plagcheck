#include <iostream>
#include <vector>
#include <queue>

int main() {
    int s = 0;
    std::cin >> s;
    std::vector<std::vector<int>> qwe(s + 1);
    for (int i = 2; i <= s; i++) {
        int p = 0;
        std::cin >> p;
        qwe[p].push_back(i);
    }
    std::vector<int> d(s + 1, 0);
    std::queue<int> q;
    q.push(1);
    int maxx = 0;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : qwe[u]) {
            d[v] = d[u] + 1;
            if (d[v] > maxx) {
                maxx = d[v];
            }
            q.push(v);
        }
    }
    std::vector<int> resss;
    for (int i = 1; i <= s; i++) {
        if (d[i] == maxx) {
            resss.push_back(i);
        }
    }
    std::cout << maxx << std::endl;
    std::cout << resss.size() << std::endl;
    for (int i = 0; i < resss.size(); i++) {
        if (i > 0) {
            std::cout << " ";
        }
        std::cout << resss[i];
    }
    return 0;
}