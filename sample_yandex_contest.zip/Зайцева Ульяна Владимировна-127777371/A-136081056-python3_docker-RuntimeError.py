n, m = map(int, input().split())
if m != n - 1:
    print("NO")
    exit()

p = list(range(n + 1))

def f(u):
    while p[u] != u:
        p[u] = p[p[u]]
        u = p[u]
    return u

c = False
for _ in range(m):
    u, v = map(int, input().split())
    ru = f(u)
    rv = f(v)
    if ru == rv:
        c = True
    p[rv] = ru

if c:
    print("NO")
    exit()

r = f(1)
for u in range(2, n + 1):
    if f(u) != r:
        print("NO")
        exit()

print("YES")