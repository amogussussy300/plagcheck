n, m = map(int, input().split())
def f(n, m):
    if m != n - 1:
        return False
    
    p = [[] for _ in range(n+1)]
    for _ in range(m):
        u, v = map(int, input().split())
        p[u].append(v)
        p[v].append(u)
    
    v = [0] * (n + 1)
    s = [1]
    count = 0
    
    while s:
        curr = s.pop()
        if not v[curr]:
            v[curr] = 1
            count += 1
            s.extend(p[curr])
    return count == n

result = f(n, m)
print("YES" if result else "NO")