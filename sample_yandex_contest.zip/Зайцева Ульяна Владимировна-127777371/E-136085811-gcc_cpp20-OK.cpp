#include <iostream>
#include <vector>
using namespace std;

int F(int x, vector<int>& p, vector<int>& c) {
    if (p[x] != x) {
        int t = p[x];
        p[x] = F(p[x], p, c);
        c[x] ^= c[t];
    }
    return p[x];
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n, m;
    cin >> n >> m;
    
    vector<int> p(n + 1);
    vector<int> c(n + 1, 0);
    for (int i = 0; i <= n; ++i) {
        p[i] = i;
    }
    
    int f = 1;
    vector<char> r;
    
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        
        if (!f) {
            r.push_back('0');
            continue;
        }
        
        if (u == v) {
            f = 0;
            r.push_back('0');
            continue;
        }
        
        int a = F(u, p, c);
        int b = F(v, p, c);
        
        if (a == b) {
            if (c[u] == c[v]) {
                f = 0;
            }
            r.push_back(f ? '1' : '0');
        } else {
            p[a] = b;
            c[a] = 1 ^ c[u] ^ c[v];
            r.push_back('1');
        }
    }
    
    for (char ch : r) {
        cout << ch;
    }
    cout << endl;
    return 0;
}