n = int(input())
d = [0] * (n + 1) 

for i in range(2, n + 1):
    p = int(input())
    d[i] = d[p] + 1

m = max(d)
c = sum(1 for i in range(1, n + 1) if d[i] == m) 
v = sorted([i for i in range(1, n + 1) if d[i] == m]) 

print(m)
print(c)
print(' '.join(map(str, v)))