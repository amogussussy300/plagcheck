def F(x, p, c):
    if p[x] != x:
        t = p[x]
        p[x] = F(p[x], p, c)
        c[x] ^= c[t]
    return p[x]

n, m = map(int, input().split())
p = list(range(n + 1))
c = [0] * (n + 1)
f = 1
r = []

for _ in range(m):
    u, v = map(int, input().split())
    
    if not f:
        r.append('0')
        continue
    
    if u == v:
        f = 0
        r.append('0')
        continue
    
    a = F(u, p, c)
    b = F(v, p, c)
    
    if a == b:
        if c[u] == c[v]:
            f = 0
        r.append('1' if f else '0')
    else:
        p[a] = b
        c[a] = 1 ^ c[u] ^ c[v]
        r.append('1')

print(''.join(r))