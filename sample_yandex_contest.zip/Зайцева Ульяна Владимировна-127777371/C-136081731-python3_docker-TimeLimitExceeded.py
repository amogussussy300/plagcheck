import sys
from collections import deque

def main():
    data = sys.stdin.read().split()
    ptr = 0
    n = int(data[ptr])
    ptr += 1
    s = int(data[ptr])
    ptr += 1
    m = int(data[ptr])
    ptr += 1

    adj = [[] for _ in range(n + 1)]
    for _ in range(m):
        a = int(data[ptr])
        ptr += 1
        b = int(data[ptr])
        ptr += 1
        adj[b].append(a)

    dist = [-1] * (n + 1)
    dist[s] = 0
    q = deque([s])

    while q:
        u = q.popleft()
        for v in adj[u]:
            if dist[v] == -1:
                dist[v] = dist[u] + 1
                q.append(v)

    print(' '.join(map(str, dist[1:n+1])))

main()