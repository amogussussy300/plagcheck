n = int(input())
d = [0] * (n + 1)
for i in range(2, n+1):
    p = int(input())
    d[i] = d[p] + 1
md = max(d)
c = d.count(md)
v = sorted([i for i in range(n+1) if d[i] == md])
print(md)
print(c)
print(' '.join(map(str, v)))