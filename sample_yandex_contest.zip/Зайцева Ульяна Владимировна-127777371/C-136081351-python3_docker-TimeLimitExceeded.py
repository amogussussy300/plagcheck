n, s, m = map(int, input().split())
g = [[] for _ in range(n+1)]
for _ in range(m):
    a, b = map(int, input().split())
    g[b].append(a)

d = [-1]*(n+1)
d[s] = 0
q = [s]

while q:
    u = q.pop(0)
    for v in g[u]:
        if d[v] == -1:
            d[v] = d[u] + 1
            q.append(v)

print(' '.join(map(str, d[1:])))