def F(x, p, c):
    stack = []
    while p[x] != x:
        stack.append(x)
        x = p[x]
    for y in stack:
        c[y] ^= c[p[y]]
        p[y] = x
    return x

n, m = map(int, input().split())
p = list(range(n + 1))
c = [0] * (n + 1)
f = 1
r = []

for _ in range(m):
    u, v = map(int, input().split())
    
    if not f:
        r.append('0')
        continue
    
    if u == v:
        f = 0
        r.append('0')
        continue
    
    a = F(u, p, c)
    b = F(v, p, c)
    
    if a == b:
        if c[u] == c[v]:
            f = 0
        r.append('1' if f else '0')
    else:
        p[a] = b
        c[a] = 1 ^ c[u] ^ c[v]
        r.append('1')

print(''.join(r))