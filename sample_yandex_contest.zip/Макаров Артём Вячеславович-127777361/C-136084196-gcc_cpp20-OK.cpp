#include <iostream>
#include <vector>
#include <queue>

int main()
{
    int n, s, m;
    std::cin >> n >> s >> m;

    std::vector<std::vector<int>> g(n + 1);
    for (int i = 0; i < m; ++i)
    {
        int a, b;
        std::cin >> a >> b;
        g[b].push_back(a);
    }

    std::queue<int> q;
    q.push(s);
    std::vector<bool> used(n + 1);
    std::vector<int> d(n + 1, -1);
    used[s] = true;
    d[s] = 0;

    while (!q.empty())
    {
        int v = q.front();
        q.pop();

        for (size_t i = 0; i < g[v].size(); ++i)
        {
            int to = g[v][i];
            if (!used[to])
            {
                used[to] = true;
                d[to] = d[v] + 1;
                q.push(to);
            }
        }
    }

    for (int i = 1; i <= n; ++i)
    {
        if (i != 1)
        {
            std::cout << " ";
        }
        std::cout << d[i];
    }
    std::cout << std::endl;

    return 0;
}