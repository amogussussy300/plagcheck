#include <iostream>
#include <vector>
#include <algorithm>


int main() 
{
    int n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int>> a(n + 1);
    std::vector<int> d(n + 1, 0);

    for (int i = 0; i < m; ++i) 
    {
        int u, v;
        std::cin >> u >> v;
        a[u].push_back(v);
        d[v]++;
    }

    std::vector<int> top;
    top.reserve(n);
    std::vector<int> q;

    for (int i = 1; i <= n; ++i) 
    {
        if (d[i] == 0) 
        {
            q.push_back(i);
        }
    }

    while (!q.empty()) {
        int u = q.back();
        q.pop_back();
        top.push_back(u);

        for (int v : a[u]) 
        {
            if (--d[v] == 0) 
            {
                q.push_back(v);
            }
        }
    }

    std::vector<int> max_path(n + 1, 0);
    int result = 0;

    for (int u : top) 
    {
        result = std::max(result, max_path[u]);
        for (int v : a[u]) {
            if (max_path[v] < max_path[u] + 1) 
            {
                max_path[v] = max_path[u] + 1;
            }
        }
    }

    std::cout << result << std::endl;


    return 0;
}