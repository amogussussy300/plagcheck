#include <iostream>
#include <vector>
#include <numeric>

std::vector<int> parent;
std::vector<int> rank;
std::vector<int> color;
bool is_bipartite = true;

void make_set(int v)
{
    parent[v] = v;
    rank[v] = 0;
    color[v] = 0;
}

std::pair<int, int> find_set(int v)
{
    if (v != parent[v])
    {
        int parity = color[v];
        parent[v] = find_set(parent[v]).first;
        color[v] ^= parity;
    }
    return {parent[v], color[v]};
}

bool add_edge(int a, int b)
{
    auto [root_a, x] = find_set(a);
    auto [root_b, y] = find_set(b);

    if (root_a == root_b)
    {
        if (x == y)
            return false;
        return true;
    }

    if (rank[root_a] < rank[root_b])
        std::swap(root_a, root_b);

    parent[root_b] = root_a;
    color[root_b] = x ^ y ^ 1;

    if (rank[root_a] == rank[root_b])
        ++rank[root_a];

    return true;
}

int main()
{
    int n, m;
    std::cin >> n >> m;

    parent.resize(n+1);
    rank.resize(n+1, 0);
    color.resize(n+1, 0);

    for (int i = 1; i <= n; ++i)
        make_set(i);

    std::string result;

    for (int i = 0; i < m; ++i)
    {
        int a, b;
        std::cin >> a >> b;

        if (is_bipartite)
        {
            is_bipartite = add_edge(a, b);
        }

        result.push_back(is_bipartite ? '1' : '0');
    }

    std::cout << result << std::endl;

    return 0;
}