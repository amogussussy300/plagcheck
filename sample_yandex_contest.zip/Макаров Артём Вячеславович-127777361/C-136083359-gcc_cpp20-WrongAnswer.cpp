#include <iostream>
#include <vector>
#include <queue>


std::vector<std::vector<int>> graph;
std::vector<int> color;
bool isBipartite = true;

void checkBipartite(int start)
{
    std::queue<int> q;
    q.push(start);
    color[start] = 1;

    while (!q.empty() && isBipartite)
    {
        int v = q.front();
        q.pop();

        for (int to : graph[v])
        {
            if (color[to] == 0)
            {
                color[to] = 3 - color[v];
                q.push(to);
            }
            else if (color[to] == color[v])
            {
                isBipartite = false;
                return;
            }
        }
    }
}

int main()
{
    int n, m;
    std::cin >> n >> m;

    graph.resize(n + 1);
    color.assign(n + 1, 0);
    std::string result;

    for (int i = 0; i < m; ++i)
    {
        int a, b;
        std::cin >> a >> b;
        graph[a].push_back(b);
        graph[b].push_back(a);

        isBipartite = true;
        for (int j = 1; j <= n; ++j)
        {
            color[j] = 0;
        }

        for (int j = 1; j <= n; ++j)
        {
            if (color[j] == 0)
            {
                checkBipartite(j);
                if (!isBipartite)
                {
                    break;
                }
            }
        }

        result += (isBipartite ? '1' : '0');
    }

    std::cout << result << std::endl;


    return 0;
}