#include <iostream>
#include <vector>
#include <algorithm>


int main()
{
    int n;
    std::cin >> n;
    
    std::vector<std::vector<int>> tree(n + 1);
    
    for (int i = 2; i <= n; ++i)
    {
        int p;
        std::cin >> p;
        tree[p].push_back(i);
    }

    std::vector<int> d(n + 1);
    std::vector<int> q = {1};
    d[1] = 0;
    
    for (int i = 0; i < q.size(); ++i)
    {
        int v = q[i];
        
        for (int u : tree[v])
        {
            d[u] = d[v] + 1;
            q.push_back(u);
        }
    }

    int max_d = *std::max_element(d.begin(), d.end());
    std::vector<int> ans;
    
    for (int i = 1; i <= n; ++i)
    {
        if (d[i] == max_d)
        {
            ans.push_back(i);
        }
    }

    std::cout << max_d << std::endl;
    std::cout << ans.size() << std::endl;
    
    for (int i = 0; i < ans.size(); ++i)
    {
        if (i)
        {
            std::cout << " ";
        }
        std::cout << ans[i];
    }
    std::cout << std::endl;


    return 0;
}