#include <iostream>
#include <vector>
#include <numeric>


std::vector<int> parent;
std::vector<int> rank;
std::vector<int> color;
bool is_bipartite = true;

void make_set(int v)
{
    parent[v] = v;
    rank[v] = 0;
    color[v] = 0;
}

int find_set(int v)
{
    if (v == parent[v])
        return v;
    return parent[v] = find_set(parent[v]);
}

bool union_sets(int a, int b)
{
    int root_a = find_set(a);
    int root_b = find_set(b);

    if (root_a == root_b)
    {
        if (color[a] == color[b])
            return false;
        return true;
    }

    if (rank[root_a] < rank[root_b])
        std::swap(root_a, root_b);

    parent[root_b] = root_a;
    if (color[a] == color[b])
        color[root_b] ^= 1;

    if (rank[root_a] == rank[root_b])
        ++rank[root_a];

    return true;
}

int main()
{
    int n, m;
    std::cin >> n >> m;

    parent.resize(n+1);
    rank.resize(n+1);
    color.resize(n+1);

    for (int i = 1; i <= n; ++i)
        make_set(i);

    std::string result;

    for (int i = 0; i < m; ++i)
    {
        int a, b;
        std::cin >> a >> b;

        if (is_bipartite)
        {
            if (!union_sets(a, b))
                is_bipartite = false;
        }

        result.push_back(is_bipartite ? '1' : '0');
    }

    std::cout << result << std::endl;


    return 0;
}