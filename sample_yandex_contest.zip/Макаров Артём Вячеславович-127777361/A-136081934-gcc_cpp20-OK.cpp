#include <iostream>
#include <vector>
#include <queue>


bool Tree(int n, int m, std::vector<std::vector<int>>& adj)
{
    if (m != n - 1)
    {
        return false;
    }

    std::vector<bool> visited(n + 1, false);
    std::queue<int> q;
    q.push(1);
    visited[1] = true;
    int visited_cnt = 1;

    while (!q.empty())
    {
        int u = q.front();
        q.pop();

        for (int v : adj[u])
        {
            if (!visited[v])
            {
                visited[v] = true;
                visited_cnt++;
                q.push(v);
            }
        }
    }

    return (visited_cnt == n);
}

int main()
{
    int n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int>> a(n + 1);

    for (int i = 0; i < m; ++i)
    {
        int u, v;
        std::cin >> u >> v;
        a[u].push_back(v);
        a[v].push_back(u);
    }

    if (Tree(n, m, a) == 1)
    {
        std::cout << "YES" << std::endl;
    }
    else
    {
        std::cout << "NO" << std::endl;
    }


    return 0;
}