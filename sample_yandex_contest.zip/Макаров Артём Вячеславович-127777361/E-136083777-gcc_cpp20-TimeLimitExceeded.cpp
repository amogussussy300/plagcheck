#include <iostream>
#include <vector>
#include <queue>


std::vector<std::vector<int>> graph;
std::vector<int> color;
bool isBipartite;

void checkBipartite(int start)
{
    std::queue<int> q;
    q.push(start);
    color[start] = 1;

    while (!q.empty() && isBipartite)
    {
        int v = q.front();
        q.pop();

        for (int to : graph[v])
        {
            if (color[to] == 0)
            {
                color[to] = 3 - color[v];
                q.push(to);
            }
            else if (color[to] == color[v])
            {
                isBipartite = false;
                return;
            }
        }
    }
}

int main()
{
    int n, m;
    std::cin >> n >> m;

    graph.resize(n + 1);
    color.resize(n + 1);
    std::vector<std::pair<int, int>> edges(m);

    for (int i = 0; i < m; ++i)
    {
        std::cin >> edges[i].first >> edges[i].second;
    }

    std::string result;
    result.reserve(m);

    for (int i = 0; i < m; ++i)
    {
        int a = edges[i].first;
        int b = edges[i].second;
        graph[a].push_back(b);
        graph[b].push_back(a);

        isBipartite = true;
        std::fill(color.begin(), color.end(), 0);

        for (int j = 1; j <= n && isBipartite; ++j)
        {
            if (color[j] == 0)
            {
                checkBipartite(j);
            }
        }

        result.push_back(isBipartite ? '1' : '0');
    }

    std::cout << result << std::endl;


    return 0;
}