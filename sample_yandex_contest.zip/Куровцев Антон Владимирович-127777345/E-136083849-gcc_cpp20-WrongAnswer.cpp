#include <bits/stdc++.h>
using namespace std;

vector<int> p, r, c;

int f(int u) {
    if (p[u] != u) {
        int t = p[u];
        p[u] = f(p[u]);
        c[u] ^= c[t];
    }
    return p[u];
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n, m;
    cin >> n >> m;
    p.resize(n + 1);
    iota(p.begin(), p.end(), 0);
    r.assign(n + 1, 1);
    c.assign(n + 1, 0);
    
    string s;
    while (m--) {
        int u, v;
        cin >> u >> v;
        if (u == v) {
            s += '0';
            continue;
        }
        int ru = f(u), rv = f(v);
        if (ru == rv) {
            s += (c[u] == c[v]) ? '0' : '1';
        } else {
            if (r[ru] > r[rv]) {
                swap(u, v);
                swap(ru, rv);
            }
            p[ru] = rv;
            c[ru] = 1 ^ c[u] ^ c[v];
            if (r[ru] == r[rv])
                r[rv]++;
            s += '1';
        }
    }
    cout << s << '\n';
}