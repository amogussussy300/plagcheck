n=int(input())
d=[0]*(n+1)
for i in range(2,n+1):
    p=int(input())
    d[i]=d[p]+1
m=max(d)
print(m)
c=d.count(m)
print(c)
print(*sorted(i for i in range(n+1) if d[i]==m))