#include <bits/stdc++.h>
using namespace std;

int main() {
    int n, s, m, a, b;
    cin >> n >> s >> m;
    
    vector<vector<int>> g(n+1);
    while (m--) {
        cin >> a >> b;
        g[b].push_back(a);
    }
    
    vector<int> d(n + 1, -1);
    d[s] = 0;
    queue<int> q{{s}};
    while (!q.empty()) {
        int u = q.front(); 
        q.pop();
        for (int v : g[u]) {
            if (d[v] == -1) {
                d[v] = d[u] + 1;
                q.push(v);
            }
        }
    }
    
    for (int i = 1; i <= n; i++) 
        cout << d[i] << " ";
}