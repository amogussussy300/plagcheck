from collections import deque

n = int(input())
c = [[] for _ in range(n+1)]
for i in range(2, n+1):
    p = int(input())
    c[p].append(i)

d = [0]*(n+1)
q = deque([1])
while q:
    u = q.popleft()
    for v in c[u]:
        d[v] = d[u] + 1
        q.append(v)

m = max(d[1:])
r = [i for i in range(1, n+1) if d[i] == m]
print(m)
print(len(r))
print(' '.join(map(str, sorted(r))))