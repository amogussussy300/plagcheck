n, m = map(int, input().split())
e = [tuple(map(int, input().split())) for _ in range(m)]

p = list(range(n + 1))
r = [1] * (n + 1)
c = [0] * (n + 1)

def find(u):
    if p[u] != u:
        o = p[u]
        p[u] = find(p[u])
        c[u] ^= c[o]
    return p[u]

res = []
for u, v in e:
    ru = find(u)
    rv = find(v)
    if ru == rv:
        res.append('0' if c[u] == c[v] else '1')
    else:
        if r[ru] > r[rv]:
            u, v = v, u
            ru, rv = rv, ru
        p[ru] = rv
        c[ru] = (1 + c[u] + c[v]) % 2
        if r[ru] == r[rv]:
            r[rv] += 1
        res.append('1')

print(''.join(res))