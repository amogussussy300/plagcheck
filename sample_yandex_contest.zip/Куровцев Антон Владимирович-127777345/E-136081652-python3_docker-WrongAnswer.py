import sys

n, m = map(int, input().split())
p = list(range(n+1))
c = [0]*(n+1)

def f(u):
    if p[u] != u:
        pu = p[u]
        p[u] = f(pu)
        c[u] ^= c[pu]
    return p[u]

res = []
for _ in range(m):
    u, v = map(int, input().split())
    pu, pv = f(u), f(v)
    if pu == pv:
        res.append('1' if c[u] != c[v] else '0')
    else:
        p[pv] = pu
        c[pv] = 1 ^ c[u] ^ c[v]
        res.append('1')

print(''.join(res))