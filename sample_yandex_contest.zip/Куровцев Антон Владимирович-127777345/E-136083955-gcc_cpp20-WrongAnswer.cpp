#include<bits/stdc++.h>
using namespace std;
int F(int x,vector<int>&p,vector<int>&c){
    if(p[x]!=x){
        int t=p[x];
        p[x]=F(p[x],p,c);
        c[x]^=c[t];
    }
    return p[x];
}
int main(){
    int n,m,u,v;
    cin>>n>>m;
    vector<int>p(n+1),c(n+1);
    for(int i=1;i<=n;i++)p[i]=i;
    string r;
    while(m--){
        cin>>u>>v;
        int a=F(u,p,c),b=F(v,p,c);
        if(a==b) r+=((c[u]^c[v])?"1":"0");
        else{
            p[a]=b;
            c[a]=1^c[u]^c[v];
            r+="1";
        }
    }
    cout<<r;
}