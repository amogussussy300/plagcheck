import sys
from collections import deque

n, m = map(int, input().split())
g = [[] for _ in range(n+1)]
d = [0]*(n+1)
q = deque()
c = [0]*(n+1)

for _ in range(m):
    u, v = map(int, input().split())
    g[u].append(v)
    c[v] += 1

for i in range(1, n+1):
    if c[i] == 0:
        q.append(i)

r = 0
while q:
    u = q.popleft()
    for v in g[u]:
        if d[v] < d[u] + 1:
            d[v] = d[u] + 1
            r = max(r, d[v])
        c[v] -= 1
        if c[v] == 0:
            q.append(v)

print(r)