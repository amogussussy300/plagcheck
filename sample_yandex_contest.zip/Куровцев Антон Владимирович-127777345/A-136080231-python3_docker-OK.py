n, m = map(int, input().split())
if m != n - 1:
    print("NO")
else:
    g = [[] for _ in range(n+1)]
    for _ in range(m):
        u, v = map(int, input().split())
        g[u].append(v)
        g[v].append(u)
    v = [0]*(n+1)
    s = [1]
    c = 0
    while s:
        x = s.pop()
        if not v[x]:
            v[x] = 1
            c += 1
            s += g[x]
    print("YES" if c == n else "NO")