import sys
sys.setrecursionlimit(1 << 25)
n, m = map(int, input().split())
p = list(range(n+1))
r = [1]*(n+1)
c = [0]*(n+1)
res = []
for _ in range(m):
    u, v = map(int, input().split())
    def f(u):
        if p[u] != u:
            o = p[u]
            p[u] = f(p[u])
            c[u] ^= c[o]
        return p[u]
    x, y = f(u), f(v)
    if x == y:
        res.append('1' if c[u]^c[v] else '0')
    else:
        if r[x] < r[y]:
            x, y = y, x
            u, v = v, u
        p[y] = x
        c[y] = c[u] ^ c[v] ^ 1
        if r[x] == r[y]:
            r[x] += 1
        res.append('1')
print(''.join(res))