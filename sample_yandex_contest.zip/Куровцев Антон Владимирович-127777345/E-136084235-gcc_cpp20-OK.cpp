#include <bits/stdc++.h>
using namespace std;

int F(int x, vector<int>& p, vector<int>& c) {
    if (p[x] != x) {
        int t = p[x];
        p[x] = F(p[x], p, c);
        c[x] ^= c[t];
    }
    return p[x];
}

int main() {
    int n, m, u, v, f = 1;
    cin >> n >> m;
    
    vector<int> p(n + 1), c(n + 1);
    iota(p.begin(), p.end(), 0);
    
    string r;
    while (m--) {
        cin >> u >> v;
        
        if (!f) {
            r += '0';
            continue;
        }
        
        if (u == v) {
            f = 0;
            r += '0';
            continue;
        }
        
        int a = F(u, p, c);
        int b = F(v, p, c);
        
        if (a == b) {
            if (c[u] == c[v]) {
                f = 0;
            }
            r += f ? '1' : '0';
        } else {
            p[a] = b;
            c[a] = 1 ^ c[u] ^ c[v];
            r += '1';
        }
    }
    
    cout << r;
    return 0;
}