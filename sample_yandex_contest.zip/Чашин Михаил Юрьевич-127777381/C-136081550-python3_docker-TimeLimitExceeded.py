from collections import deque, defaultdict

n, s, m = map(int, input().split())
gr = defaultdict(list)

for _ in range(m):
    a, b = map(int, input().split())
    gr[b].append(a)

dis = [-1] * (n + 1)
dis[s] = 0
queue = deque([s])

while queue:
    temp = queue.popleft()

    for i in gr[temp]:
        if dis[i] == -1:
            dis[i] = dis[temp] + 1
            queue.append(i)

print(*dis[1:])
