#include <iostream>
#include <vector>
#include <queue>

using namespace std;

const int max_n = 1000000;

vector<int> adj[max_n + 1];
int color[max_n + 1];


void addEdge(int u, int v) {
    adj[u].push_back(v);
    adj[v].push_back(u);
}


bool isbi(int start) {
    queue<int> q;
    q.push(start);
    color[start] = 0;

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        for (int i : adj[node]) {
            if (color[i] == -1) {
                color[i] = 1 - color[node];
                q.push(i);
            } else if (color[i] == color[node]) {
                return false;
            }
        }
    }
    return true;
}


bool check(int n) {
    fill(color, color + n + 1, -1);
    for (int i = 1; i <= n; ++i) {
        if (color[i] == -1) {
            if (!isbi(i)) {
                return false;
            }
        }
    }
    return true;
}

int main() {
    int n, m;
    cin >> n >> m;

    string ans;

    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        addEdge(u, v);
        if (check(n)) {
            ans += '1';
        } else {
            ans += '0';
        }
    }

    cout << ans << endl;
    return 0;
}
