#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;

    vector<vector<int>> gr(n + 1);
    vector<int> ind(n + 1, 0);

    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        gr[u].push_back(v);
        ind[v]++;
    }

    queue<int> q;
    for (int i = 1; i <= n; ++i) {
        if (ind[i] == 0) {
            q.push(i);
        }
    }

    vector<int> temp;
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        temp.push_back(node);

        for (int i : gr[node]) {
            ind[i]--;
            if (ind[i] == 0) {
                q.push(i);
            }
        }
    }

    vector<int> arr(n + 1, 0);
    for (int node : topo_order) {
        for (int i : gr[node]) {
            arr[i] = max(arr[i], arr[node] + 1);
        }
    }

    int max_len = 0;
    for (int i = 1; i <= n; ++i) {
        max_len = max(max_len, arr[i]);
    }

    cout << max_len << endl;

    return 0;
}

