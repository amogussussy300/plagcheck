#include <iostream>
#include <vector>
#include <deque>
#include <string>

using namespace std;

int main() {
    int n, s, m;
    cin >> n >> s >> m;

    vector<vector<int>> gr(n + 1);
    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        gr[b].push_back(a);
    }

    vector<int> dis(n + 1, -1);
    dis[s] = 0;
    deque<int> queue;
    queue.push_back(s);

    while (!queue.empty()) {
        int temp = queue.front();
        queue.pop_front();

        for (int i : gr[temp]) {
            if (dis[i] == -1) {
                dis[i] = dis[temp] + 1;
                queue.push_back(i);
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        cout << dis[i] << (i < n ? " " : "");
    }
    cout << endl;

    return 0;
}
