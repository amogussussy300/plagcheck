#include <iostream>
#include <vector>
#include <queue>

using namespace std;

bool bfs(int s, vector<vector<int>>& g, vector<int>& color) {
    queue<int> q;
    q.push(s);
    color[s] = 0;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : g[u]) {
            if (color[v] == -1) {
                color[v] = 1 - color[u];
                q.push(v);
            } else if (color[v] == color[u]) {
                return false;
            }
        }
    }
    return true;
}

bool is_bipartite(int n, vector<pair<int, int>>& edges) {
    vector<vector<int>> g(n + 1);
    vector<int> color(n + 1, -1);

    for (auto& edge : edges) {
        int u = edge.first;
        int v = edge.second;
        g[u].push_back(v);
        g[v].push_back(u);
        if (!bfs(u, g, color)) {
            return false;
        }
    }
    return true;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<pair<int, int>> edges(m);
    for (int i = 0; i < m; ++i) {
        cin >> edges[i].first >> edges[i].second;
    }

    string res;
    for (int i = 0; i < m; ++i) {
        if (is_bipartite(n, vector<pair<int, int>>(edges.begin(), edges.begin() + i + 1))) {
            res += '1';
        } else {
            res += '0';
        }
    }

    cout << res << endl;
    return 0;
}
