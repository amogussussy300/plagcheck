def dfs(node, depth):
    global max_d, far
    if depth > max_d:
        max_d = depth
        far = [node]
    elif depth == max_d:
        far.append(node)

    for i in tree[node]:
        dfs(i, depth + 1)


n = int(input())
tree = [[] for _ in range(n + 1)]

for i in range(2, n + 1):
    g = int(input())
    tree[g].append(i)

max_d = 0
far = []

dfs(1, 0)
far.sort()

print(max_d)
print(len(far))
print(" ".join(map(str, far)))
