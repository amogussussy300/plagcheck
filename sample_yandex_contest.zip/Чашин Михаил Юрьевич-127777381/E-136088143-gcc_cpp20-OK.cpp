#include <iostream>
#include <vector>
#include <algorithm>

std::vector<int> p;
std::vector<int> h;
std::vector<int> c;

std::pair<int, int> f(int x) {
    if (p[x] != x) {
        auto r = f(p[x]);
        p[x] = r.first;    
        c[x] ^= r.second; 
        return {p[x], c[x]};
    }
    return {x, c[x]};
}

bool u(int x, int y) {
    auto a = f(x);
    auto b = f(y);
    int rx = a.first, cx = a.second;
    int ry = b.first, cy = b.second;

    if (rx == ry) {
        return cx != cy;
    }

    if (h[rx] > h[ry]) {
        p[ry] = rx;
        c[ry] = cx ^ cy ^ 1;
    }
    else {
        p[rx] = ry;
        c[rx] = cx ^ cy ^ 1;
        if (h[rx] == h[ry]) {
            h[ry]++;
        }
    }
    return true;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    p.resize(n);
    h.resize(n, 0);
    c.resize(n, 0);

    for (int i = 0; i < n; ++i) {
        p[i] = i;
    }

    std::string s(m, '0');
    bool ok = true;

    for (int i = 0; i < m; ++i) {
        int u_, v;
        std::cin >> u_ >> v;
        u_--; v--;

        if (ok) {
            ok = u(u_, v);
            if (ok) {
                s[i] = '1';
            }
        }
    }

    std::cout << s << std::endl;
}