#include <iostream>
#include <vector>
#include <queue>

using namespace std;

const int MAX_N = 100000;

vector<int> adj[MAX_N + 1];
int color[MAX_N + 1];


void addEdge(int u, int v) {
    adj[u].push_back(v);
    adj[v].push_back(u);
}


bool bfs(int start) {
    queue<int> q;
    q.push(start);
    color[start] = 0;

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        for (int neighbor : adj[node]) {
            if (color[neighbor] == -1) {
                color[neighbor] = 1 - color[node];
                q.push(neighbor);
            } else if (color[neighbor] == color[node]) {
                return false;
            }
        }
    }
    return true;
}


bool сheck(int u,int v){
    fill(color, color + MAX_N + 1, -1);
    color[u] = 0;


    if (!bfs(u)) {
        return false;
    }
    return true;
}

int main() {
    int n, m;
    cin >> n >> m;

    string result;

    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        addEdge(u, v);

        if (сheck(u, v)) {
            result += '1';
        } else {
            for (int j = i; j < m; j++){
                result += '0';
            }
            break;
        }
    }

    cout << result << endl;
    return 0;
}
