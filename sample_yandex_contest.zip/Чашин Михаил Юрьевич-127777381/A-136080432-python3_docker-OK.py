from collections import defaultdict, deque


n, m = map(int, input().split())
v = [list(map(int, input().split())) for _ in range(m)]

if len(v) != n - 1:
    print("NO")
else:
    gr = defaultdict(list)
    for u, v in v:
        gr[u].append(v)
        gr[v].append(u)

    vis = [False] * (n + 1)
    queue = deque([1])
    vis[1] = True

    while queue:
        node = queue.popleft()
        for i in gr[node]:
            if not vis[i]:
                vis[i] = True
                queue.append(i)

    if all(vis[1:]):
        print("YES")
    else:
        print("NO")