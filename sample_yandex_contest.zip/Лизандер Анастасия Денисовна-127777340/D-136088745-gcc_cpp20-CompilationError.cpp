#include <iostream>
#include <vector>
#include<queue>
#include<algorithm>
int64_t n, b;

int64_t bfs(std::vector<std::vector<int64_t>>& g, int start, int finish){
    std::vector<bool> used(n);
    std::vector<int64_t> d(n);
    std::queue<int64_t> q;
    
    used[start] = true;
    d[start] = 0;
    q.push(start);
    
    while (!q.empty()){
        auto v = q.front();
        q.pop();
        for (auto i : g[v]){
            if (!used[i]){
                used[i] = true;
                q.push(i);
                d[i] = d[v] + 1;
            }
        }
    }
    
    return d[finish];
}

int main() {
    
    std::cin >> n;
    std::vector<std::vector<int64_t>> g(n);

    for (int64_t i = 1; i < m; ++i){
        std::cin >> b;
        --b;
        g[b].push_back(i);
        g[i].push_back(b);
    }
    
    int64_t dmax = -1;
    std::vector<int64_t> ans;
    
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < n; ++j){
            dmax = std::max(dmax, bfs(g, i, j));
        }
    }
    std::cout << dmax<< '\n';
    return 0;
}