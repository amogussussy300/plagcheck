#include <iostream>
#include <queue>
#include <vector>

int n, s, m, a, b;
int INF = 1e9 + 7;

std::vector<int> used;
bool cycle = false;

std::vector<int> p;

void check_cycle(std::vector<std::vector<int>>& g, int v){
    used[v] = 1;
    for (auto i : g[v]){
        if (used[i] == 0){
            p[i] = v;
            check_cycle(g, i);
        } else if (used[i] == 1 && i != p[v]){
            cycle = true;
            break;
        }
    }
    used[v] = 2;
}

void comp(std::vector<std::vector<int>>& g, int v, std::vector<std::vector<int>>& ans){
    used[v] = 1;
    ans[ans.size() - 1].push_back(v + 1);
    for (auto i : g[v]){
        if (used[i] == 0){
            comp(g, i, ans);
        }
    }
}

int main() {
    std::cin >> n >> m;
    std::vector<std::vector<int>> g(n);
    
    for (int i = 0; i < m; ++i){
        std::cin >> a >> b;
        --a;
        --b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    
    used.resize(n);
    p.resize(n);
    
    std::vector<std::vector<int>> ans;
    
    for (int i = 0; i < n; ++i){
        if (used[i] == 0){
            ans.push_back(std::vector<int>());
            comp(g, i, ans);
        }
        
    }
    used.clear();
    used.resize(n);
    
    check_cycle(g, 0);
    
    if (!cycle && ans.size() == 1){
        std::cout << "YES" << '\n';
    } else {
        std::cout << "NO" << '\n';
    }
    return 0;
}