#include <iostream>
#include <queue>
#include <vector>
int n, s, m, a, b;
int INF = 1e9 + 7;

void dfs(std::vector<std::vector<std::pair<int, int>>>& g){
    std::priority_queue<std::pair<int, int>> q;
    std::vector<int> d(n, INF);
    
    d[s] = 0;
    q.push({0, s});
    
    while (!q.empty()){
        auto [len, v] = q.top();
        q.pop();
        len = -len;
        if (len > d[v]) continue;
        
        for (auto i : g[v]){
            auto [to, cost] = i;
            if (d[to] > d[v] + cost){
                d[to] = d[v] + cost;
                q.push({-d[to], to});
            }
        }
    }
    for (auto i : d){
        if (i == INF){
            std::cout << -1 << " ";
        } else {
            std::cout << i << " ";
        }
    }
}

int main() {
    std::cin >> n >> s >> m;
    --s;
    std::vector<std::vector<std::pair<int, int>>> g(n);
    for (int i = 0; i < m; ++i){
        std::cin >> a >> b;
        --a;
        --b;
        g[b].push_back({a, 1});
    }
    
    dfs(g);
    return 0;
}