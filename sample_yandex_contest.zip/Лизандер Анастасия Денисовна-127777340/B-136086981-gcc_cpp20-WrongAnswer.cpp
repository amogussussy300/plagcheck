#include <iostream>
#include <vector>
#include<queue>
#include<algorithm>
int n, b;

int bfs(std::vector<std::vector<int>>& g, int start, int finish){
    std::vector<bool> used(n);
    std::vector<int64_t> d(n);
    std::queue<int64_t> q;
    
    used[start] = true;
    d[start] = 0;
    q.push(start);
    
    while (!q.empty()){
        auto v = q.front();
        q.pop();
        for (auto i : g[v]){
            if (!used[i]){
                used[i] = true;
                q.push(i);
                d[i] = d[v] + 1;
            }
        }
    }
    
    return d[finish];
}

int main() {
    
    std::cin >> n;
    std::vector<std::vector<int>> g(n);

    for (int i = 1; i < n; ++i){
        std::cin >> b;
        --b;
        g[b].push_back(i);
        g[i].push_back(b);
    }
    
    int dmax = -1;
    std::vector<int> ans;
    
    for (int i = 1; i < n; ++i){
        auto temp = bfs(g, 0, i);
        if (temp > dmax){
            dmax = temp;
            ans.clear();
            ans.push_back(i);
        } else if (temp == dmax){
            ans.push_back(i);
        }
    }
    std::cout << dmax << '\n';
    std::cout << ans.size() << '\n';
    std::sort(ans.begin(), ans.end());
    for (auto i : ans){
        std::cout << i + 1 << " ";
    }
    return 0;
}