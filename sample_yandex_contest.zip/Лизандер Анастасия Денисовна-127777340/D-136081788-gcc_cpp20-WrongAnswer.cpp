#include <iostream>
#include <vector>
#include <queue>
int INF = 1e9 + 7;
int s, n, m, a, b;

std::pair<int, int> dfs(std::vector<std::vector<std::pair<int, int>>>& g){
    std::priority_queue<std::pair<int, int>> q;
    std::vector<int> d(n, INF);
    
    d[s] = 0;
    q.push({0, s});
    
    while (!q.empty()){
        auto [len, v] = q.top();
        q.pop();
        
        for (auto i : g[v]){
            auto [to, cost] = i;
            if (d[to] > d[v] + cost){
                d[to] = d[v] + cost;
                q.push({d[to], to});
            }
        }
    }
    int mx = -1;
    int ans = -1;
    for (int i = 0; i < n; ++i){
        if (d[i] > ans){
            mx = d[i];
            ans = i;
        }
    }
    return {ans, mx};
}
int main() {
    std::cin >> n >> m;
    s = 0;
    std::vector<std::vector<std::pair<int, int>>> g(n);
    for (int i = 0; i < m; ++i){
        std::cin >> a >> b;
        --a;
        --b;
        g[a].push_back({b, 1});
    }
    auto [start, mx] = dfs(g);
    s = start;
    auto [ans, mix] = dfs(g);
    std::cout << ans - 1 << '\n';
    return 0;
}