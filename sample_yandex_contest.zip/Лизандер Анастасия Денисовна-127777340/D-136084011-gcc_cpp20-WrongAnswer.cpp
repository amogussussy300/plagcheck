#include <iostream>
#include <vector>
#include <queue>

int INF = 1e9 + 7;
int s, n, m, a, b;
int ans = -1;

std::pair<int, int> bfs(std::vector<std::vector<int>>& g, int start){
    std::vector<bool> used(n);
    std::vector<int> d(n);
    std::queue<int> q;
    
    used[start] = true;
    
    d[start] = 0;
    q.push(start);
    
    while (!q.empty()){
        auto v = q.front();
        q.pop();
        for (auto i : g[v]){
            if (!used[i]){
                used[i] = true;
                q.push(i);
                d[i] = d[v] + 1;
            }
        }
    }
    int dmax = -1;
    int indmax = 0;
    for (int i = 0; i < n; ++i){
        if (d[i] > dmax){
            indmax = i;
            dmax = d[i];
        }
    }
    
    return {dmax, indmax};
    
}
int main() {
    std::cin >> n >> m;
    s = 0;
    std::vector<std::vector<int>> g(n);
    for (int i = 0; i < m; ++i){
        std::cin >> a >> b;
        --a;
        --b;
        g[a].push_back(b);
    }
    
    for (int i = 0; i < n; ++i){
        auto [mx, start] = bfs(g, s);
        ans = std::max(mx, ans);
    }
    std::cout << ans;
    return 0;
}