from collections import deque

n, m = map(int, input().split())

childs = [[] for _ in range(n + 1)]


for i in range(0, m):
    
    a, b = map(int, input().split())
    childs[a-1].append(b-1)


q = deque()
q.append((1, 0))  
maxx = 0
last = []

while q:
    node, dist = q.popleft()
    if dist > maxx:
        maxx = dist
        last = [node]
    elif dist == maxx:
        last.append(node)
    
    for child in childs[node]:
        q.append((child, dist + 1))


#print(q)

print(maxx+1)
#print(len(last))
