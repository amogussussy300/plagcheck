from collections import deque

n,s, m = map(int, input().split())
s=s-1
grf = [[] for _ in range(n )]
for _ in range(m):
    a,b = map(int, input().split())
    grf[b-1].append(a-1)


dist = [-1] * (n )
dist[s] = 0


q = deque()
q.append(s)

while q:
    v = q.popleft()
    for x in grf[v]:
        if dist[x] == -1:
            dist[x] = dist[v] + 1
            q.append(x)



print(*dist)
