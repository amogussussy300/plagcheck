from collections import deque

n,s, m = map(int, input().split())
grf = [[] for _ in range(n + 1)]
for _ in range(m):
    a,b = map(int, input().split())
    grf[a].append(b)


dist = [-1] * (n + 1)
dist[s] = 0


q = deque()
q.append(s)

while q:
    v = q.popleft()
    for x in grf[v]:
        if dist[x] == -1:
            dist[x] = dist[v] + 1
            q.append(x)

print(*dist)