#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, s, m;
    cin >> n >> s >> m;
    s--; 

    vector<vector<int>> grf(n);
    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        grf[b - 1].push_back(a - 1); 
    }

    vector<int> dist(n, -1);
    dist[s] = 0;
    queue<int> q;
    q.push(s);

    while (!q.empty()) {
        int v = q.front();
        q.pop();
        for (int x : grf[v]) {
            if (dist[x] == -1) {
                dist[x] = dist[v] + 1;
                q.push(x);
            }
        }
    }

    for (int d : dist) {
        cout << d << ' ';
    }
    

    return 0;
}