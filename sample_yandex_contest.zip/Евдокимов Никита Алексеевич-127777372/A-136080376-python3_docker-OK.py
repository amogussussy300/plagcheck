n, m = map(int, input().split())
adj = [[] for ti in range(n + 1)]  

for ti in range(m):
    u, v = map(int, input().split())
    adj[u].append(v)
    adj[v].append(u)

if m != n - 1:
    print("NO")
else:
    vis = [False] * (n + 1)
    stack = [1]
    vis[1] = True
    rez = 1

    while stack:
        u = stack.pop()
        for v in adj[u]:
            if not vis[v]:
                vis[v] = True
                stack.append(v)
                rez += 1

    if rez == n:
        print("YES")
    else:
        print("NO")