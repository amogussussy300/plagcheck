from collections import deque

n = int(input())

childs = [[] for _ in range(n + 1)]


for i in range(2, n + 1):
    p = int(input())
    
    childs[p].append(i)


q = deque()
q.append((1, 0))  
maxx = 0
last = []

while q:
    node, dist = q.popleft()
    if dist > maxx:
        maxx = dist
        last = [node]
    elif dist == maxx:
        last.append(node)
    
    for child in childs[node]:
        q.append((child, dist + 1))


#print(q)

print(maxx)
print(len(last))
for i in sorted(last):
    print(i,end=" ")
