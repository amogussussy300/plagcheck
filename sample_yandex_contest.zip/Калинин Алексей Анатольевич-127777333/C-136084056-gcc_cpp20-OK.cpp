#include <queue>
#include <vector>
#include <iostream>

int main(){
    int n, m, s;
    std::cin >> n >> s >> m;

    std::vector<std::vector<int>> gr(n + 1);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        gr[b].push_back(a);
    }
    
    std::vector<int> distance(n + 1, -1);
    std::queue<int> q;
    q.push(s);
    distance[s] = 0;

    while (!q.empty()) {
        int v = q.front();
        q.pop();
        for (int u : gr[v]) {
            if (distance[u] == -1) {
                distance[u] = distance[v] + 1;
                q.push(u);
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        std::cout << distance[i];
        if (i != n) {
            std::cout << " ";
        }
    }
    std::cout << std::endl;


    return 0;
}
