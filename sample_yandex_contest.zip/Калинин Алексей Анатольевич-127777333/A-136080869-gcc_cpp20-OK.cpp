#include <iostream>
#include<vector>
#include<queue>

int main()
{
    int n, m;
    std::cin >> n >> m;

    if (m != n - 1) {
        std::cout << "NO";
        return 0;
    }

    std::vector<std::vector<int>> gr(n + 1);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        gr[a].push_back(b);
        gr[b].push_back(a);
    }

    std::vector<bool> used(n + 1, false);
    std::queue<int> q;
    q.push(1);
    used[1] = true;
    int count = 1;

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : gr[u]) {
            if (!used[v]) {
                used[v] = true;
                ++count;
                q.push(v);
            }
        }
    }

    if (count == n) {
        std::cout << "YES";
    }
    else {
        std::cout << "NO";
    }
    return 0;
}
