#include <iostream>
#include <vector>
#include <queue>

int main() {
    int n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int>> gr(n + 1);
    std::vector<int> d(n + 1, 0);

    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        gr[a].push_back(b);
        d[b]++;
    }

    std::queue<int> q;
    for (int i = 1; i <= n; ++i) {
        if (d[i] == 0) {
            q.push(i);
        }
    }

    std::vector<int> dp(n + 1, 0);
    int max_len = 0;

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : gr[u]) {
            if (dp[v] < dp[u] + 1) {
                dp[v] = dp[u] + 1;
                max_len = std::max(max_len, dp[v]);
            }
            if ((d[v] - 1) == 0) {
                q.push(v);
            }
        }
    }

    std::cout << max_len << std::endl;
}