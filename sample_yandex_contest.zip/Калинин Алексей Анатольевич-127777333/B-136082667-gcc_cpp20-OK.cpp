#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>
#include <utility>

void dfs(int s, const std::vector<std::vector<int>>& g, std::vector<int>& depth) {
    std::stack<std::pair<int, int>> st;
    st.push({ s, 0 });
    std::vector<bool> visited(depth.size(), false);

    while (!st.empty()) {
        auto node = st.top();
        st.pop();
        int v = node.first;
        int cur_len = node.second;

        if (!visited[v]) {
            visited[v] = true;
            depth[v] = cur_len;
            for (auto to : g[v]) {
                if (!visited[to]) {
                    st.push({ to, cur_len + 1 });
                }
            }
        }
    }
}


int main()
{
    int n;
    std::cin >> n;
    
    if (n == 1) {
        std::cout << 0 << std::endl << 1 << std::endl << 1;
        return 0;
    }

    std::vector<std::vector<int>> gr(n + 1);
    for (int i = 2; i <= n; ++i) {
        int parrent;
        std::cin >> parrent;
        gr[parrent].push_back(i);
    }

    std::vector<int> depth(n + 1, 0);
    dfs(1, gr, depth);

    int max_depth = depth[1];
    for (int i = 2; i <= n; ++i) {
        if (depth[i] > max_depth) {
            max_depth = depth[i];
        }
    }

    std::vector<int> nodes;

    for (int i = 1; i <= n; ++i) {
        if (depth[i] == max_depth) {
            nodes.push_back(i);
        }
    }

    sort(nodes.begin(), nodes.end());
    std::cout << max_depth << std::endl;
    std::cout << nodes.size() << std::endl;
    for (size_t i = 0; i < nodes.size(); ++i) {
        std::cout << nodes[i];
        if (i < nodes.size() - 1) {
            std::cout << " ";
        }
    }
    std::cout << std::endl;




    return 0;
}
