#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    int n, m;
    cin >> n >> m;
    
    vector<vector<int>> g(n + 1);
    vector<int> deg(n + 1);
    
    while (m--) {
        int a, b;
        cin >> a >> b;
        g[a].push_back(b);
        deg[b]++;
    }
    
    queue<int> q;
    vector<int> len(n + 1);
    
    for (int i = 1; i <= n; i++)
        if (!deg[i]) q.push(i);
    
    while (!q.empty()) {
        int v = q.front();
        q.pop();
        
        for (int u : g[v]) {
            len[u] = max(len[u], len[v] + 1);
            if (--deg[u] == 0) q.push(u);
        }
    }
    
    cout << *max_element(len.begin(), len.end());
    
    return 0;
}