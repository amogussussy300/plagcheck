#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int main() {
    int total;
    cin >> total;
    
    vector<vector<int>> child(total + 1);
    for (int n = 2; n <= total; ++n) {
        int parent;
        cin >> parent;
        child[parent].push_back(n);
    }
    
    vector<int> depth(total + 1, 0);
    queue<int> nodes_queue;
    nodes_queue.push(1);
    
    while (!nodes_queue.empty()) {
        int curr = nodes_queue.front();
        nodes_queue.pop();
        
        for (int child : child[curr]) {
            depth[child] = depth[curr] + 1;
            nodes_queue.push(child);
        }
    }
    
    int max_depth = *max_element(depth.begin() + 1, depth.end());
    vector<int> d_n;
    
    for (int n = 1; n <= total; ++n) {
        if (depth[n] == max_depth) {
            d_n.push_back(n);
        }
    }
    
    sort(d_n.begin(), d_n.end());
    
    cout << max_depth << "\n";
    cout << d_n.size() << "\n";
    for (int n : d_n) {
        cout << n << " ";
    }
    
    return 0;
}