#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

struct DSU {
    vector<int> par, r, col;
    
    DSU(int n) : par(n + 1), r(n + 1, 0), col(n + 1, 0) {
        for (int i = 1; i <= n; i++) {
            par[i] = i;
            col[i] = 0;
        }
    }

    int find(int x) {
        if (par[x] == x)
            return x;
        int p = find(par[x]);
        col[x] ^= col[par[x]];
        return par[x] = p;
    }

    bool sett(int u, int v) {
        int ru = find(u), rv = find(v);
        if (ru == rv) {
            if ((col[u] ^ col[v]) != 1)
                return false;
            return true;
        }
        int offsett = col[u] ^ col[v] ^ 1;
        if (r[ru] < r[rv])
            swap(ru, rv);
        par[rv] = ru;
        col[rv] = offsett;
        if (r[ru] == r[rv])
            r[ru]++;
        return true;
    }
};

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n, m;
    cin >> n >> m;
    
    DSU dsu(n);
    string ans;
    bool bip = true; 
    for (int i = 0; i < m; i++){
        int u, v;
        cin >> u >> v;
        if (bip) {

            if (!dsu.sett(u, v))
                bip = false;
        }
        ans.push_back(bip ? '1' : '0');
    }
    
    cout << ans;
    return 0;
}
