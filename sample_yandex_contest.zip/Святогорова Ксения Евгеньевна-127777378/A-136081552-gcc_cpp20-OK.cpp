#include <iostream>
#include <vector>
using namespace std;

const int N = 100;
vector<int> g[N];
bool used[N];

void dfs(int v, int p) {
    used[v] = true;
    for (int to : g[v]) {
        if (!used[to]) {
            dfs(to, v);
        } else if (to != p) {
            throw false;
        }
    }
}

int main() {
    int n, m;
    cin >> n >> m;

    if (m != n - 1) {
        cout << "NO" << endl;
        return 0;
    }

    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a);
    }

    try {
        dfs(1, -1);

        for (int i = 1; i <= n; ++i) {
            if (!used[i]) {
                cout << "NO" << endl;
                return 0;
            }
        }

        cout << "YES" << endl;
    } catch (...) {
        cout << "NO" << endl;
    }

    return 0;
}