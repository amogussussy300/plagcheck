#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, s, m;
    cin >> n >> s >> m;

    vector<vector<int>> revGraph(n + 1);
    for (int i = 0; i < m; i++){
        int a, b;
        cin >> a >> b;
        revGraph[b].push_back(a);
    }

    vector<int> d(n + 1, -1);
    queue<int> q;

    d[s] = 0;
    q.push(s);
    
    while(!q.empty()){
        int cur = q.front();
        q.pop();
        for (int nxt : revGraph[cur]){
            if(d[nxt] == -1){
                d[nxt] = d[cur] + 1;
                q.push(nxt);
            }
        }
    }
    
    for (int i = 1; i <= n; i++){
        cout << d[i] << " ";
    }
    
    return 0;
}