#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int n;
    std::cin >> n;
    std::vector<std::vector<int>> children(n+1);
    


    std::vector<int> parent(n+1);
    for (int v = 2; v <= n; v++) {
        std::cin >> parent[v];
        children[parent[v]].push_back(v);
    }

    std::vector<int> depth(n+1);
    std::vector<int> stack = {1};
    
    while (!stack.empty()) {
        int v = stack.back();
        stack.pop_back();
        
        for (int child : children[v]) {
            depth[child] = depth[v] + 1;
            stack.push_back(child);
        }
    }

    std::vector<int> nodes;
    for (int i = 1; i <= n; i++) nodes.push_back(i);
    std::sort(nodes.begin(), nodes.end());

    int max_d = *std::max_element(depth.begin(), depth.end());
    std::vector<int> result;
    
    for (int v : nodes) {
        if (depth[v] == max_d) result.push_back(v);
    }

    std::cout << max_d << '\n' << result.size() << '\n';
    

    for (size_t i = 0; i < result.size(); i++) {
        if (i) std::cout << ' ';
        std::cout << result[i];
    }
    std::cout << '\n';


    return 0;
}