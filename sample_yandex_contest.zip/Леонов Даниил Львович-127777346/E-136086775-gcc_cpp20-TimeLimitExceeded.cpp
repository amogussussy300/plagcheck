#include <iostream>
#include <vector>
#include <cmath>

std::vector<int> par, rk_, col;

int fnd(int v) {
    if (par[v] == v) {
        return v;
    }
    int original_parent = par[v];
    int p = fnd(original_parent);
    int current_color = col[v];
    int parent_color = col[original_parent];
    col[v] = current_color ^ parent_color;
    par[v] = p;
    return p;
}

bool uni(int x, int y, int c) {
    int rx = fnd(x);
    int ry = fnd(y);
    bool same_root = (rx == ry);
    
    if (same_root) {
        int color_diff = col[x] ^ col[y];
        bool valid = (color_diff == c);
        return valid;
    }
    
    int rank_rx = rk_[rx];
    int rank_ry = rk_[ry];
    bool rx_smaller = (rank_rx < rank_ry);
    bool ry_smaller = (rank_rx > rank_ry);
    
    if (rx_smaller) {
        par[rx] = ry;
        int new_color = col[x] ^ col[y] ^ c;
        col[rx] = new_color;
    } else if (ry_smaller) {
        par[ry] = rx;
        int new_color = col[x] ^ col[y] ^ c;
        col[ry] = new_color;
    } else {
        par[ry] = rx;
        rk_[rx] += 1;
        int new_color = col[x] ^ col[y] ^ c;
        col[ry] = new_color;
    }
    
    return true;
}

int main() {
    int n, k;
    std::cin >> n >> k;
    
    par.resize(n + 1);
    rk_.resize(n + 1, 0);
    col.resize(n + 1, 0);
    
    for (int i = 1; i <= n; i++) {
        par[i] = i;
    }
    
    bool ok = true;
    while (k--) {
        int a, b;
        std::cin >> a >> b;
        
        if (ok) {
            bool union_result = uni(a, b, 1);
            if (!union_result) {
                ok = false;
            }
        }
        
        std::cout << (ok ? 1 : 0);
    }
    
    std::cout << "\n";
    return 0;
}