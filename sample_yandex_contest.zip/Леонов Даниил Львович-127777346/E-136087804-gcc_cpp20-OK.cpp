#include <iostream>
#include <vector>
#include <cmath>
#include <stack>





struct DSU {
    std::vector<int> p;
    std::vector<int> r;
    std::vector<int> c;

    DSU(int n) {
        p.resize(n + 1);
        r.assign(n + 1, 0);
        c.assign(n + 1, 0);
        for (int i = 0; i <= n; i++) {
            p[i] = i;
        }
    }

    int f(int x) {
        if (p[x] == x)
            return x;
        int root = f(p[x]);
        c[x] ^= c[p[x]];
        p[x] = root;
        return p[x];
    }

    bool u(int x, int y) {
        int rx = f(x);
        int ry = f(y);
        if (rx == ry) {
            if (c[x] == c[y])
                return false;
            return true;
        }
        int newC = c[x] ^ c[y] ^ 1;
        if (r[rx] < r[ry]) {
            p[rx] = ry;
            c[rx] = newC;
        } else {
            p[ry] = rx;
            c[ry] = newC;
            if (r[rx] == r[ry])
                r[rx]++;
        }
        return true;
    }
};

int main(){
    int n, m;
    std::cin >> n >> m;
    
    DSU d(n);
    bool ok = true;
     std::string ans;
    
    int lst = 0;
    for (int i = 0; i < n; ++i){
        if (ok){
            int c = n;
            while(c>0){
                c--;
            }
        }
    }
    
    for (int i = 0; i < m; i++) {
        int u, v;
        std::cin >> u >> v;
        if(ok) {
            if(!d.u(u, v)) {
                ok = false;
            }
        }
        ans.push_back(ok ? '1' : '0');
    }
    
    std::cout << ans;
    return 0;
}