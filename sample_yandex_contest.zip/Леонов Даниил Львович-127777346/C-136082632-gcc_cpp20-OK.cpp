#include <iostream>
#include <vector>
#include <queue>

int main() {
  int n, s, m;
  std::cin >> n >> s >> m;
  
  std::vector<std::vector<int>> rev(n+1);
  while (m--) {
    int a, b;
    std::cin >> a >> b;
    rev[b].push_back(a);
  }

  std::vector<int> dist(n+1, -1);
  std::queue<int> q;
  q.push(s);
  dist[s] = 0;

  int iterations = 0;
  while (!q.empty()) {
    iterations++;
    int u = q.front();
    q.pop();

    for (int v : rev[u]) {
      if (dist[v] == -1) {
        dist[v] = dist[u] + 1;
        q.push(v);
      }
    }
  }

  for (int i = 1; i <= n; i++) {
    if (i > 1) std::cout << ' ';
    std::cout << dist[i];
  }
  std::cout << '\n';

  return 0;
}