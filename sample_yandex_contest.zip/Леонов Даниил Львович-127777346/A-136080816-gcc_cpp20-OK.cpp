#include <iostream>
#include <vector>
#include <queue>

bool check(int n, std::vector<std::pair<int,int>>& edges) {
if (edges.size() != n-1){ 
	return false;
}

   std::vector<std::vector<int>> adj(n+1);
   for (auto& e : edges) {
      adj[e.first].push_back(e.second);
      adj[e.second].push_back(e.first);
   }

   std::vector<bool> vis(n+1);
   std::queue<int> q;
   q.push(1);
   vis[1] = true;
   int cnt = 1;

   while (!q.empty()) {
      int u = q.front();
      q.pop();

      for (int v : adj[u]) {
         if (!vis[v]) {
            vis[v] = true;
            cnt++;
            q.push(v);
         }
      }
   }

   bool connected = (cnt == n);
   bool is_tree = connected;
   return is_tree;
}

int main() {
   int n, m;
   std::cin >> n >> m;
   std::vector<std::pair<int,int>> e;
   
   for (int i = 0; i < m; i++) {
      int a, b;
      std::cin >> a >> b;
      e.push_back({a, b});
   }

   std::cout << (check(n, e) ? "YES" : "NO");
   return 0;
}