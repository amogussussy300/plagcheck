#include <iostream>
#include <vector>


int main() {
	int n, m;
	std::cin >> n >> m;
	
	std::vector<std::vector<int>> g(n+1);
	std::vector<int> in(n+1);
	if (m > 0){
	while (m--) {
		int a, b;
		std::cin >> a >> b;
		g[a].push_back(b);
		in[b]++;
		
	} }else {
	    return 0;
	}
	
	std::vector<int> dp(n+1);
	std::vector<int> lst;
	
	
	
	for (int v = 1; v <= n; v++) {
		if (in[v] == 0) {
			lst.push_back(v);
		}
	}

	int res = 0;
	//*for (int i == 1; i < n; i++){
	//    sources.
	//}
	for (int v : lst) {
		std::vector<int> stack = {v};
		
		while (!stack.empty()) {
			int u = stack.back();
			stack.pop_back();
			
			for (int w : g[u]) {
				if (dp[w] < dp[u] + 1) {
					dp[w] = dp[u] + 1;
					res = std::max(res, dp[w]);
				}
				in[w]--; 
				if (in[w] == 0) { 
					stack.push_back(w);
				}
			}
		}
	}

	std::cout << res;
	return 0;
}