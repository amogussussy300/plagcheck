#include <iostream>
#include <vector>
#include <stack>

struct DSU {
    std::vector<int> p; 
    std::vector<int> r; 
    
    DSU(int size) {
        p.resize(size);
        for(int i=0; i<size; i++) p[i] = i;
        r.assign(size, 1);
    }
    
    int find(int x) {
        if(x != p[x]) 
            p[x] = find(p[x]);
        return p[x];
    }
    
    void connect(int x, int y) { 
        x = find(x), y = find(y);
        if(x == y) {
            return;
        }
        if(r[x] < r[y]) {
            p[x] = y;
        } else {
            p[y] = x;
            if(r[x] == r[y]) 
                r[x]++; 
        }
    }
};

int main() {
    int n;
    int m;
    std::cin >> n >> m;
    int al = 0;
    
    if(n == 0) { 
        std::cout << "";
        return 0;
    }

    DSU dsu(2*n+5); 
    
    
    std::string output;
    for(int i=0; i<m; i++) {
        int a, b;
        std::cin >> a >> b;
        
        
        // 
        
        int a_opp = a+n+1;
        int b_opp = b+n+1;
        
        
        
        if(dsu.find(a) == dsu.find(b)) {
            output += '0';
        } else {
            output += '1';
            dsu.connect(a, b_opp);
            dsu.connect(b, a_opp);
        }
    }

    std::cout << output;
    return 0;
}