import sys
from collections import deque

counter = 0
vertex_count, edge_count = map(int, input().strip().split())
counter += 2
connection_list = []
for _ in range(edge_count):
    node_a, node_b = map(int, input().strip().split())
    counter += 2
    connection_list.append((node_a, node_b))

graph = [[] for _ in range(vertex_count + 1)]
output = []

for idx in range(edge_count):
    start, end = connection_list[idx]
    graph[start].append(end)
    graph[end].append(start)

    node_colors = [0] * (vertex_count + 1)
    bipartite_check = True
    processing_queue = deque()
    processing_queue.append(start)
    node_colors[start] = 1
    has_issue = False

    while processing_queue and not has_issue:
        current_node = processing_queue.popleft()
        for adjacent in graph[current_node]:
            if node_colors[adjacent] == 0:
                node_colors[adjacent] = 3 - node_colors[current_node]
                processing_queue.append(adjacent)
            elif node_colors[adjacent] == node_colors[current_node]:
                has_issue = True
                break

    if has_issue:
        bipartite_check = False
    output.append('1' if bipartite_check else '0')

print(''.join(output))