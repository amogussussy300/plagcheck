#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int main() {
    int n, s, m;
    cin >> n >> s >> m;
    
    vector<vector<int>> list_items(n + 1);
    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        list_items[b].push_back(a);
    }
    
    vector<int> path_dist(n + 1, -1);
    path_dist[s] = 0;
    
    queue<int> ququ;
    ququ.push(s);
    
    while (!ququ.empty()) {
        int u = ququ.front();
        ququ.pop();
        
        for (int v : list_items[u]) {
            if (path_dist[v] == -1) {
                path_dist[v] = path_dist[u] + 1;
                ququ.push(v);
            }
        }
    }
    
    for (int i = 1; i <= n; ++i) {
        cout << path_dist[i] << (i < n ? " " : "");
    }
    cout << endl;
    
    return 0;
}