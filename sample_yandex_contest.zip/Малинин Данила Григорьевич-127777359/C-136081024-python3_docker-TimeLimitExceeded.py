from collections import deque

input_line = input().split()
n = int(input_line[0])
s = int(input_line[1])
m = int(input_line[2])
list_items = [[] for _ in range(n + 1)]
for _ in range(m):
    a, b = map(int, input().split())
    list_items[b].append(a)
path_dist = (n + 1) * [-1]
path_dist[s] = 0

ququ = deque([s])
while ququ:
    u = ququ.popleft()
    for v in list_items[u]:
        if path_dist[v] == -1:
            path_dist[v] = path_dist[u] + 1
            ququ.append(v)

result = map(str, path_dist[1:n+1])
print(' '.join(result))