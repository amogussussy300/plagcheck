from collections import deque



n, m = map(int, input().strip().split())

list_items = [[] for _ in range(n + 1)]
in_de = [0] * (n + 1)

for _ in range(m):
    u, v = map(int, input().strip().split())
    list_items[u].append(v)
    in_de[v] += 1

ququ = deque()
list_order = []

for u in range(1, n + 1):
    if in_de[u] == 0:
        ququ.append(u)

while ququ:
    u = ququ.popleft()
    list_order.append(u)
    for v in list_items[u]:
        in_de[v] -= 1
        if in_de[v] == 0:
            ququ.append(v)

list_dap = (n + 1) * [0]
max_result = 0

for q in list_order:
    for v in list_items[q]:
        if list_dap[v] < list_dap[q] + 1:
            list_dap[v] = list_dap[q] + 1
            if list_dap[v] > max_result:
                max_result = list_dap[v]

print(max_result)