from collections import deque

n = int(input())

parent = [0] * (n + 1)
children = [[] for _ in range(n + 1)]

for i in range(2, n + 1):
    p = int(input())
    parent[i] = p
    children[p].append(i)

distance = [0] * (n + 1)
queue = deque([1])
max_distance = 0
while queue:
    u = queue.popleft()
    for v in children[u]:
        distance[v] = distance[u] + 1
        if distance[v] > max_distance:
            max_distance = distance[v]
        queue.append(v)

max_vertices = []
for v in range(1, n + 1):
    if distance[v] == max_distance:
        max_vertices.append(v)
max_vertices.sort()

print(max_distance)
print(len(max_vertices))
print(' '.join(map(str, max_vertices)))