#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;
    
    vector<vector<int>> children(n + 1);
    for (int i = 2; i <= n; ++i) {
        int parent;
        cin >> parent;
        children[parent].push_back(i);
    }

    vector<int> distances(n + 1, 0);
    queue<int> q;
    q.push(1);
    
    while (!q.empty()) {
        int current = q.front();
        q.pop();
        
        for (int child : children[current]) {
            distances[child] = distances[current] + 1;
            q.push(child);
        }
    }

    int max_distance = *max_element(distances.begin(), distances.end());
    vector<int> farthest_nodes;
    
    for (int i = 1; i <= n; ++i) {
        if (distances[i] == max_distance) {
            farthest_nodes.push_back(i);
        }
    }

    cout << max_distance << endl;
    cout << farthest_nodes.size() << endl;
    for (int node : farthest_nodes) {
        cout << node << " ";
    }

    return 0;
}