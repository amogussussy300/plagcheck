#include <iostream>
#include <vector>
#include <utility>
using namespace std;

struct DSU {
    vector<int> parent;
    vector<int> rank;
    vector<int> parity;

    DSU(int n) : parent(n + 1), rank(n + 1, 0), parity(n + 1, 0) {
        for (int i = 1; i <= n; ++i) {
            parent[i] = i;
        }
    }

    pair<int, int> find(int u) {
        if (u != parent[u]) {
            int orig_parity = parity[u];
            pair<int, int> root = find(parent[u]);
            parent[u] = root.first;
            parity[u] = orig_parity ^ root.second;
        }
        return make_pair(parent[u], parity[u]);
    }

    bool unite(int u, int v) {
        pair<int, int> root_u = find(u);
        pair<int, int> root_v = find(v);
        if (root_u.first == root_v.first) {
            return root_u.second != root_v.second;
        }
        if (rank[root_u.first] > rank[root_v.first]) {
            swap(root_u, root_v);
        }
        parent[root_u.first] = root_v.first;
        parity[root_u.first] = root_u.second ^ root_v.second ^ 1;
        if (rank[root_u.first] == rank[root_v.first]) {
            rank[root_v.first]++;
        }
        return true;
    }
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;
    DSU dsu(n);
    bool is_bipartite = true;
    string result;

    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        if (is_bipartite) {
            is_bipartite = dsu.unite(u, v);
        }
        result += is_bipartite ? '1' : '0';
    }

    cout << result << endl;
    return 0;
}