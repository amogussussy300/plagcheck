n, m = map(int, input().split())
adj = [[] for _ in range(n + 1)]

for _ in range(m):
    u, v = map(int, input().split())
    adj[u].append(v)
    adj[v].append(u)

visited = [False] * (n + 1)
parent = [-1] * (n + 1)
has_cycle = False

stack = [(1, -1)]
while stack and not has_cycle:
    u, p = stack.pop()
    if visited[u]:
        has_cycle = True
        break
    visited[u] = True
    for v in adj[u]:
        if v != p:
            if visited[v]:
                has_cycle = True
                break
            stack.append((v, u))
    if has_cycle:
        break

if not has_cycle and all(visited[1:]):
    print("YES")
else:
    print("NO")