#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

vector<int> topologicalSort(const vector<vector<int>>& adj, vector<int>& inDegree) {
    int n = adj.size() - 1;
    queue<int> q;
    vector<int> topOrder;
    
    for (int i = 1; i <= n; ++i) {
        if (inDegree[i] == 0) {
            q.push(i);
        }
    }
    
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        topOrder.push_back(u);
        
        for (int v : adj[u]) {
            if (--inDegree[v] == 0) {
                q.push(v);
            }
        }
    }
    
    return topOrder;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n, m;
    cin >> n >> m;
    
    vector<vector<int>> adj(n + 1);
    vector<int> inDegree(n + 1, 0);
    
    for (int i = 0; i < m; ++i) {
        int b, e;
        cin >> b >> e;
        adj[b].push_back(e);
        inDegree[e]++;
    }
    
    vector<int> topOrder = topologicalSort(adj, inDegree);
    vector<int> dist(n + 1, 0);
    
    for (int u : topOrder) {
        for (int v : adj[u]) {
            if (dist[v] < dist[u] + 1) {
                dist[v] = dist[u] + 1;
            }
        }
    }
    
    int maxLength = *max_element(dist.begin(), dist.end());
    cout << maxLength << endl;
    
    return 0;
}