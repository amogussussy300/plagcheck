n = int(input())
parent = [0] * (n + 1)
depth = [0] * (n + 1)

for i in range(2, n + 1):
    p = int(input())
    parent[i] = p
    depth[i] = depth[p] + 1

max_depth = max(depth[1:])
count = depth.count(max_depth)
nodes = [i for i in range(1, n + 1) if depth[i] == max_depth]

print(max_depth)
print(count)
print(' '.join(map(str, sorted(nodes))))