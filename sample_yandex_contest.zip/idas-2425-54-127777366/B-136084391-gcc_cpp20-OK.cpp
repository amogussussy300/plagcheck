#include<iostream>
#include<vector>
#include<deque>
#include<set>
using namespace std;


int main() {
    int n;
    cin >> n;

    vector<vector<int>> graph(n);
    vector<bool> used (n, false);
    vector<int> distances(n, 0);
    int max_dist = 0;
    for (int i = 1; i < n; i++) {
        int a;
        cin >> a;
        a--;
        graph[a].push_back(i);
    }

    deque<pair<int, int>> q;
    q.push_back({0, 0});
    while (!q.empty()) {
        auto [cur, dist] = *q.begin();
        q.pop_front();
        //int cur = t.first, dist = t.second;
        max_dist = max(max_dist, dist);
        distances[cur] = dist;
        //cout << "NOW " << cur << " HAS " << dist << endl;
        for (int i: graph[cur]) {
            q.push_back({i, dist + 1});
        }
    }

    //cout << "YO" << endl;
    //for (int i : distances)
    //    cout << i;
    //cout << "YO" << endl;



    set<int> farest;
    for (int i = 0; i < n; i++)
        if (distances[i] == max_dist)
            farest.insert(i);
    cout << max_dist << '\n' << farest.size() << '\n';
    for (int i : farest)
        cout << i + 1 << ' ';
    return 0;
}
