#include<iostream>
#include<vector>
#include<queue>
using namespace std;

bool dfs(int v, int parent, vector<bool>& used, const vector<vector<int>>& graph) {
    used[v] = true;
    for (int to : graph[v]) {
        if (!used[to]) {
            if (dfs(to, v, used, graph)) {
                return true;
            }
        } else if (to != parent) {
            return true;
        }
    }
    return false;
}


int main() {
    int n, m;
    cin >> n >> m;

    vector<vector<int>> graph(n);
    vector<bool> used (n, false);

    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        a--; b--;
        graph[a].push_back(b);
        graph[b].push_back(a);
    }

    bool is_tree = true;
    if (dfs(0, -1, used, graph)) {
        is_tree = false;
    }
    
    cout << (is_tree ? "YES" : "NO");

    return 0;
}
