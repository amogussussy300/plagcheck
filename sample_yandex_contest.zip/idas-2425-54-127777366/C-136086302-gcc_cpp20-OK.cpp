#include<iostream>
#include<vector>
#include<deque>
#include<set>
using namespace std;


int main() {
    int n, s, m;
    cin >> n >> s >> m;
    s--;
    vector<vector<int>> graph(n);
    vector<int> distances(n, -1);

    distances[s] = 0;

    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        a--;
        b--;
        graph[b].push_back(a);
    }

    deque<int> q;
    q.push_back(s);

    while (!q.empty()) {
        auto cur = *q.begin();
        q.pop_front();

        for (int i: graph[cur]) {
                if (distances[i] == -1) {
                distances[i] = distances[cur] + 1;
                q.push_back(i);
            }
        }
    }

    for (int i : distances)
        cout << i << ' ';
    return 0;
}
