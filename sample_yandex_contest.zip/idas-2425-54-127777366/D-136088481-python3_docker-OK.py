from collections import deque
n, m = map(int, input().split())

graph = [[] for _ in range(n + 1)]
in_power = [0] * (n + 1)

for _ in range(m):
    a, b = map(int, input().split())
    a-=1
    b-=1
    graph[a].append(b)
    in_power[b] += 1

q = deque()
for i in range(n):
    if in_power[i] == 0:
        q.append(i)

topo_order = []
while q:
    cur = q.popleft()
    topo_order.append(cur)
    for to in graph[cur]:
        in_power[to] -= 1
        if in_power[to] == 0:
            q.append(to)

dp = [0] * n
max_length = 0

for u in reversed(topo_order):
    for v in graph[u]:
        if dp[u] < dp[v] + 1:
            dp[u] = dp[v] + 1
    if dp[u] > max_length:
        max_length = dp[u]

print(max_length)