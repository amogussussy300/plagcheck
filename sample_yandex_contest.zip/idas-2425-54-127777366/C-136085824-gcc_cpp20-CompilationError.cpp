from collections import  deque

n, s, m = map(int, input().split())
s -= 1
rev_graph = [list() for _ in range(n)]
distances = [-1 for _ in range(n)]
distances[s] = 0

for _ in range(m):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    rev_graph[b].append(a)

queue = deque([s])

while queue:
    cur = queue.popleft()
    for to in rev_graph[cur]:
        if distances[to] == -1:
            distances[to] = distances[cur] + 1
            queue.append(to)

print(' '.join(map(str, distances)))
