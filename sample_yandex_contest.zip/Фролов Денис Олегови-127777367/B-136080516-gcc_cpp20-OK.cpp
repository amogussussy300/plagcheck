#include <iostream>
#include <queue>
#include <vector>

const int INF = 1e9 + 7;
int used[110];
std::vector<std::vector<int>> g(110);

void DFS(int v, int r) {
    used[v] = r + 1;
    for(auto to: g[v]) {
        if (used[to] == INF) {
            DFS(to, used[v]);
        }
    }
}

int main() {
    int n;
    std::cin >> n;
    for(int i = 1; i < n; ++i) {
        used[i] = INF;
    }
    for(int i = 0; i < n - 1; ++i) {
        int x;
        std::cin >> x;
        --x;
        g[i + 1].push_back(x);
        g[x].push_back(i + 1);
    }
    DFS(0, -1);
    std::vector <int> v;
    int ans = 0;
    for(int i = 0; i < n; ++i) {
        ans = std::max(ans, used[i]);
    }
    for(int i = 0; i < n; ++i) {
        if (used[i] == ans) {
            v.push_back(i);
        }
    }
    std::cout << ans << "\n";
    std::cout << v.size() << "\n";
    for(auto to: v) {
        std::cout << to + 1 << " ";
    }
    return 0;
}
