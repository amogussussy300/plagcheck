#include <iostream>
#include <queue>
#include <vector>
#include <string>

const int INF = 1e9 + 7;

int used[300000];

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> g(n);
    std::string ans;
    char flag = '1';
    for(int i = 0; i < m; ++i) {
        int x, y;
        std::cin >> x >> y;
        --x;
        --y;
        if (used[x] == 1 && used[y] == 0) {
            used[y] = 2;
        } else if (used[x] == 2 && used[y] == 0) {
            used[y] = 1;
        } else if (used[y] == 1 && used[x] == 0) {
            used[x] = 2;
        } else if (used[y] == 2 && used[x] == 0) {
            used[x] = 1;
        } else if (used[x] == 0 && used[y] == 0) {
            used[x] = 1;
            used[y] = 2;
        } else if (used[x] == used[y]) {
            flag = '0';
        }
        ans += flag;
    }
    std::cout << ans;
    return 0;
}
