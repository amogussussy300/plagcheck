#pragma GCC Optimize("Ofast")

#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <set>

const int INF = 1e9 + 7;
const int N = 3e5;
int flag = 0;
int n;
std::vector<std::vector<std::pair<int, int>>> g(N);

void DFS(int v, int c, int cur, std::vector<int>& used) {
    used[v] = c;
    if (flag == 1) return;
    for(auto to: g[v]) {
        //std::cout << v << " " << to.first << " " << to.second << "\n";
        if (to.second > cur) continue;
        if (used[to.first] == c) {
            flag = 1;
            return;
        }
    }
    for(auto to: g[v]) {
        if (to.second > cur) continue;
        if (used[to.first] == 0) {
            DFS(to.first, 3 - c, cur, used);
        }
    }
}

void TRY(int mid) {
    std::vector<int> used(n, 0);
    for(int i = 0; i < n; ++i) {
        if (!used[i]) {
            DFS(i, 1, mid, used);
        }
    }
}

int main() {
    std::ios_base::sync_with_stdio(0);
    std::cin.tie(0);
    std::cout.tie(0);
    int m;
    std::cin >> n >> m;
    int x, y;
    for(int i = 0; i < m; ++i) {
        std::cin >> x >> y;
        --x;
        --y;
        g[x].push_back({y, i});
        g[y].push_back({x, i});
    }
    int l = 0, r = m - 1;
    int cur = m;
    while(l <= r) {
        int mid = (l + r) >> 1;
        flag = 0;
        TRY(mid);
        if (flag == 1) {
            r = mid - 1;
            cur = mid;
        } else {
            l = mid + 1;
        }
    }
    for(int i = 0; i < cur; ++i) {
        std::cout << '1';
    }
    for(int i = cur; i < m; ++i) {
        std::cout << '0';
    }
    return 0;
}
