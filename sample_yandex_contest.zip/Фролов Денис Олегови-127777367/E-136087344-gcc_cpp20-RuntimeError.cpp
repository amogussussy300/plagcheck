#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <set>

const int INF = 1e9 + 7;
const int N = 2e5;
int used[N];
char flag = 0;

std::vector<std::vector<std::pair<int, int>>> g(N);

void DFS(int v, int c, int cur) {
    used[v] = c;
    if (flag == 1) return;
    for(auto to: g[v]) {
        //std::cout << v << " " << to.first << " " << to.second << "\n";
        if (to.second > cur) continue;
        if (used[to.first] == c) {
            flag = 1;
            return;
        }
    }
    for(auto to: g[v]) {
        if (to.second > cur) continue;
        if (used[to.first] == 0) {
            DFS(to.first, 3 - c, cur);
        }
    }
}
int main() {
    int n, m;
    std::cin >> n >> m;
    int x, y;
    for(int i = 0; i < m; ++i) {
        std::cin >> x >> y;
        --x;
        --y;
        g[x].push_back({y, i});
        g[y].push_back({x, i});
    }
    int l = 0, r = m - 1;
    int cur = m;
    while(l <= r) {
        int mid = (l + r) >> 1;
        for(int i = 0; i < n; ++i) {
            used[i] = 0;
        }
        flag = 0;
        for(int i = 0; i < n; ++i) {
            if (!used[i]) {
                DFS(i, 1, mid);
            }
        }
        if (flag == 1) {
            r = mid - 1;
            cur = mid;
        } else {
            l = mid + 1;
        }
    }
    for(int i = 0; i < cur; ++i) {
        std::cout << '1';
    }
    for(int i = cur; i < m; ++i) {
        std::cout << '0';
    }
    return 0;
}
