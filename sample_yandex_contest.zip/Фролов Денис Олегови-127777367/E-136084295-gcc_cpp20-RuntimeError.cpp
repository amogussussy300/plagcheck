#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <set>

const int INF = 1e9 + 7;
const int N = 5e5;
std::vector<std::vector<int>> g(N);
char flag = '1';

void DFS(int v, int c, std::vector<int>& used) {
    used[v] = c;
    for(auto to: g[v]) {
        if (used[to] == c) {
            flag = '0';
        }
    }
    for(auto to: g[v]) {
        if (used[to] == 0) {
            DFS(to, 3 - c, used);
        }
    }
}

void TRY(int v, int n) {
     std::vector<int> used(n);
     DFS(v, 1, used);
}

int main() {
    int n, m;
    std::cin >> n >> m;
    std::string ans;
    int x, y;
    for(int i = 0; i < m; ++i) {
        std::cin >> x >> y;
        --x;
        --y;
        g[x].push_back(y);
        g[y].push_back(x);
        if (flag == '0') {
            ans += flag;
            continue;
        }
        TRY(x, 1);
        ans += flag;
    }
    std::cout << ans;
    return 0;
}
