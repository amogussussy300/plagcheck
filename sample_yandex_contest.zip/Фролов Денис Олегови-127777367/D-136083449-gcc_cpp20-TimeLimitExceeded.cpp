#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <set>

const int INF = 1e9 + 7;
const int N = 1e4;

int d[N];
int k[N];

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> g(n);
    for(int i = 0; i < m; ++i) {
        int x, y;
        std::cin >> x >> y;
        --x;
        --y;
        g[x].push_back(y);
        k[y]++;
    }
    int ans = 0;
    for(int i = 0; i < n; ++i) {
        if (k[i] == 0) {
            std::queue<std::pair<int, int>> q;
            q.push({i, 0});
            while(!q.empty()) {
                int v = q.front().first;
                int dist = q.front().second;
                q.pop();
                if (dist < d[v]) {
                    continue;
                }
                for(auto to: g[v]) {
                    //std::cout << to << " " << d[to] << "\n";
                    if (d[to] < dist + 1) {
                        d[to] = dist + 1;
                        q.push({to, d[to]});
                    }
                }
            }
            for(int j = 0; j < n; ++j) {
                ans = std::max(ans, d[j]);
                d[j] = 0;
            }
        }
    }
    std::cout << ans;
    return 0;
}

