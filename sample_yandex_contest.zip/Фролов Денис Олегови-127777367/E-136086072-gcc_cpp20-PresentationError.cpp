#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <set>

const int INF = 1e9 + 7;
const int N = 2e5;
int used[N];
char flag = 0;

void DFS(int v, int c, const std::vector<std::vector<int>>& g) {
    used[v] = c;
    if (flag == '0') return;
    for(auto to: g[v]) {
        if (used[to] == c) {
            flag = 1;
            return;
        }
    }
    for(auto to: g[v]) {
        if (used[to] == 0) {
            DFS(to, 3 - c, g);
        }
    }
}
int main() {
    int n, m;
    std::cin >> n >> m;
    std::string ans;
    int x[m], y[m];
    for(int i = 0; i < m; ++i) {
        std::cin >> x[i] >> y[i];
        --x[i];
        --y[i];
    }
    int l = 0, r = m - 1;
    int cur = n;
    while(l <= r) {
        std::vector<std::vector<int>> g(n);
        int mid = (l + r) >> 1;
        for(int i = 0; i <= mid; ++i) {
            g[x[i]].push_back(y[i]);
            g[y[i]].push_back(x[i]);
        }
        for(int i = 0; i < n; ++i) {
            used[i] = 0;
        }
        flag = 0;
        for(int i = 0; i < n; ++i) {
            if (!used[i]) {
                DFS(i, 1, g);
            }
        }
        if (flag == 1) {
            r = mid - 1;
            cur = mid;
        } else {
            l = mid + 1;
        }
    }
    for(int i = 0; i < cur; ++i) {
        std::cout << '1';
    }
    for(int i = cur; i < n; ++i) {
        std::cout << '0';
    }
    return 0;
}
