#include <iostream>
#include <queue>
#include <vector>

int used[110];
std::vector<std::vector<int>> g(110);

void DFS(int v) {
    used[v] = 1;
    for(auto to: g[v]) {
        if (!used[to]) {
            DFS(to);
        }
    }
}

int main() {
    int n, m;
    std::cin >> n >> m;
    for(int i = 0; i < m; ++i) {
        int x, y;
        std::cin >> x >> y;
        --x;
        --y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    if (m != n - 1) {
        std::cout << "NO";
    } else {
        DFS(0);
        for(int i = 1; i < n; ++i) {
            if (!used[i]) {
                std::cout << "NO";
                return 0;
            }
        }
        std::cout << "YES";
    }
    return 0;
}
