#include <iostream>
#include <queue>
#include <vector>

int main() {
    int n, m;
    std::cin >> n >> m;
    for(int i = 0; i < m; ++i) {
        int x, y;
        std::cin >> x >> y;
    }
    if (m == n - 1) {
        std::cout << "YES";
    } else {
        std::cout << "NO";
    }
    return 0;
}
