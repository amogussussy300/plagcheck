#include <iostream>
#include <queue>
#include <vector>

const int INF = 1e9 + 7;

int main() {
    int n, s, m;
    std::cin >> n >> s >> m;
    --s;
    int d[n];
    for(int i = 0; i < n; ++i) {
        d[i] = INF;
    }
    std::vector<std::vector<std::pair<int, int>>> g(n);
    for(int i = 0; i < m; ++i) {
        int x, y;
        std::cin >> x >> y;
        --x;
        --y;
        g[y].push_back({1, x});
    }
    d[s] = 0;
    std::priority_queue<std::pair<int, int>> q;
    q.push({0, s});
    while(!q.empty()) {
        int v = q.top().second;
        int dist = -q.top().first;
        q.pop();
        if (d[v] < dist) {
            continue;
        }
        for(auto to: g[v]) {
            if (d[to.second] > dist + to.first) {
                d[to.second] = dist + to.first;
                q.push({-d[to.second], to.second});
            }
        }
    }
    for(int i = 0; i < n; ++i) {
        if (d[i] == INF) {
            std::cout << -1 << " ";
        }
        else {
            std::cout << d[i] << " ";
        }
    }
    return 0;
}
