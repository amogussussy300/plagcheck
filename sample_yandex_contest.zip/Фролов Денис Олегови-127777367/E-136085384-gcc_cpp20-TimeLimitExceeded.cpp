#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <set>

const int INF = 1e9 + 7;
const int N = 2e5;
std::vector<std::vector<int>> g(N);
char flag = '1';
int p[N], sz[N];

int n;

int root(int x) {
    if (p[x] == x) return x;
    return p[x] = root(p[x]);
}


void DFS(int v, int c, std::vector<int>& used) {
    used[v] = c;
    if (flag == '0') return;
    for(auto to: g[v]) {
        if (used[to] == c) {
            flag = '0';
            return;
        }
    }
    for(auto to: g[v]) {
        if (used[to] == 0) {
            DFS(to, 3 - c, used);
        }
    }
}

void TRY(int v) {
     std::vector<int> used(n);
     DFS(v, 1, used);
}

void unite(int x, int y) {
    x = root(x);
    y = root(y);
    if (x == y) {
        TRY(x);
        return;
    }
    if (sz[y] > sz[x]) std::swap(x, y);
    sz[x] += sz[y];
    p[y] = x;
}

int main() {
    int m;
    std::cin >> n >> m;
    std::string ans;
    int x, y;
    for(int i = 0; i < n; ++i) {
        p[i] = i;
        sz[i] = 1;
    }
    for(int i = 0; i < m; ++i) {
        std::cin >> x >> y;
        --x;
        --y;
        g[x].push_back(y);
        g[y].push_back(x);
        if (flag == '0') {
            ans += flag;
            continue;
        }
        unite(x, y);
        ans += flag;
    }
    std::cout << ans;
    return 0;
}
