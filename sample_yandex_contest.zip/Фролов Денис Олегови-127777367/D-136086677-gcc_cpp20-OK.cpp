#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <set>

const int INF = 1e9 + 7;
const int N = 1e4;

int d[N];
int k[N];
int used[N];

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> g(n);
    for(int i = 0; i < m; ++i) {
        int x, y;
        std::cin >> x >> y;
        --x;
        --y;
        g[x].push_back(y);
        k[y]++;
    }
    std::queue<int> q;
    for(int i = 0; i < n; ++i) {
        if (k[i] == 0) {
            q.push(i);
        }
    }
    std::vector<int> top;
    while(!q.empty()) {
        int v = q.front();
        q.pop();
        top.push_back(v);
        for(auto to: g[v]) {
            if (--k[to] == 0) {
                q.push(to);
            }
        }
    }
    for(auto to: top) {
        for(auto u: g[to]) {
            d[u] = std::max(d[u], d[to] + 1);
        }
    }
    int ans = 0;
    for(int i = 0; i < n; ++i) {
        ans = std::max(ans, d[i]);
    }
    std::cout << ans;
    return 0;
}

