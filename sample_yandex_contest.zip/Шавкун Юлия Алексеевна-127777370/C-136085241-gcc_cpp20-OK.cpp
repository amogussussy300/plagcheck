#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

const int INF = 1e9;

void bfs(int start, const std::vector<std::vector<int>>& g, std::vector<int>& d) {
    std::queue<int> q;
    q.push(start); 

    while (!q.empty()) {
        int v = q.front();
        q.pop();

        for (int to : g[v]) {
            if (d[to] == -1){
                d[to] = d[v] + 1;
                q.push(to);
            }
        }
    }
}

int main() {
    int n, m, s, a, b;
    std::cin >> n >> s >> m;
    std::vector<std::vector<int>> g(n + 1);
    std::vector<int> d(n + 1, -1);
    d[s] = 0;
    for (int i = 0; i < m; ++i) {
        std::cin >> a >> b;
        g[b].push_back(a);
    }

    bfs(s, g, d);

    for (int i =1; i < d.size(); ++i) {
        std::cout << d[i] << " ";
    }


}