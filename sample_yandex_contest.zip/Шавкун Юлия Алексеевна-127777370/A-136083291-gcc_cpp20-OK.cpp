#include <iostream>
#include <vector>
#include <queue>



bool bfs(int n, int m, std::vector<std::vector<int>>& g) {
    std::queue<int> q;
    if (m != n - 1) {
        return false;
    }
    int cnt = 0;
    std::vector<bool> used(n + 1, false);

    q.push(1);
    used[1] = true;

    while (!q.empty()) {
        int v = q.front();
        q.pop();
        cnt++;

        for (int to : g[v]) {
            if (!used[to]) {
                used[to] = true;
                q.push(to);
            }
        }
    }
    return cnt == n;
}

int main() {
    int n, m, x, y;
    std::cin >> n >> m;
    std::vector<std::vector<int>> g(n + 1);

    for (int i = 0; i < m; i++) {
        std::cin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    if (bfs(n, m, g)) {
        std::cout << "YES" << std::endl;
    }
    else {
        std::cout << "NO" << std::endl;
    }
}