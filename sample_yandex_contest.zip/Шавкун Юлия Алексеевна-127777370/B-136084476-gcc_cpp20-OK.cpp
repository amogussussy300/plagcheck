#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>


void bfs(const std::vector<std::vector<int>>& g, std::vector<int>& d, int& mx) {
    std::queue<int> q;
    q.push(1); 

    while (!q.empty()) {
        int v = q.front();
        q.pop();

        for (int to : g[v]) {
            d[to] = d[v] + 1; 
            if (d[to] > mx) {
                mx = d[to];
            }
            q.push(to);
        }
    }
}

int main() {
    int n;
    std::cin >> n;

    std::vector<int> d(n + 1, -1);
    d[1] = 0; 
    std::vector<std::vector<int>> g(n + 1);

    for (int i = 2; i <= n; ++i) {
        int a;
        std::cin >> a;
        g[a].push_back(i); 
    }

    int mx = 0;
    bfs(g, d, mx);

    std::cout << mx << std::endl;

    std::vector<int> v;
    for (int to = 1; to <= n; ++to) {
        if (d[to] == mx) {
            v.push_back(to);
        }
    }
    std::sort(v.begin(), v.end());

    std::cout << v.size() << std::endl; 
    for (size_t i = 0; i < v.size(); ++i) {
        if (i != 0) std::cout << " ";
        std::cout << v[i]; 
    }
    std::cout << std::endl;

}