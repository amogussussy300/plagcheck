#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>


void dfs(int v, const std::vector<std::vector<int>>& g, std::vector<bool>& used, std::stack<int>& s, int& mx, std::vector<int>& d){
    used[v] = true;

    while (!s.empty()) {
        int v = s.top();
        s.pop();

        for (int to : g[v]) {
            if (d[to] < d[v] + 1) {
                d[to] = d[v] + 1;
                mx = std::max(mx, d[to]);
                if (!used[to]) {
                    dfs(to, g, used, s, mx, d);
                    s.push(to);
                }
            }
        }
 
    }
    s.push(v);
}

int main() {
    int n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int>> g(n + 1);
    std::vector<int> cnt(n + 1, 0);
    std::vector<int> d(n + 1, 0);
    int mx = 0;

    for (int i = 0; i < m; ++i) {
        int b, e;
        std::cin >> b >> e;
        g[b].push_back(e);
        cnt[e]++;
    }


    std::stack<int> s;
    std::vector<bool> used(n + 1, false);

    for (int i = 1; i <= n; ++i) {
        if (!used[i]) {
            dfs(i, g, used, s, mx, d);
        }
    }

    std::cout << mx;
}