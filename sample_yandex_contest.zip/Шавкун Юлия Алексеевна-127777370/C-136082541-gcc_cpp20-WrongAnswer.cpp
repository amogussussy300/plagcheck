#include <iostream>
#include <vector>
#include <set>

const int64_t INF = 1e18;

void dij(int s, std::vector<std::vector<std::pair<int, int>>>& g, std::vector<int64_t>& d) {
    d[s] = 0;
    std::set<std::pair<int, int>> q;
    q.insert({ d[s], s });
    while (!q.empty()) {
        int v = q.begin()->second;
        q.erase(q.begin());
        for (auto c : g[v]) {
            int to = c.first;
            int64_t len = c.second;
            if (d[v] + len < d[to]) {
                q.erase({ d[to], to });
                d[to] = d[v] + len;
                q.insert({ d[to], to });
            }
        }
    }
}

int main() {
    int n, m, s;
    std::cin >> n >> m >> s;

    std::vector<int64_t> d(n + 1, INF);
    std::vector<std::vector<std::pair<int, int>>> g(n + 1);
    int a, b;
    for (int i = 0; i < m; ++i) {
        std::cin >> a >> b;
       
        g[a].push_back({ b, 1 });
    }

    dij(s, g, d);

    for (int i = 1; i <= n; ++i) {
        if (d[i] == INF) {
            std::cout << -1 << " ";
        }
        else if (s == i){
            std::cout << 0 << " ";
        }
        else {
            std::cout << d[i] << " ";
        }
    }

}