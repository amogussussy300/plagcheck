#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

const int INF = 1e9;

void dfs(int start, const std::vector<std::vector<int>>& g, std::vector<int>& d, int& mx){
    std::stack<int> s;
    s.push(start); 
    d[start] = 0;
    while (!s.empty()) {
        int v = s.top();
        s.pop();

        for (int to : g[v]) {
            if (d[to] == -1){
                d[to] = d[v] + 1;
                if (d[to] > mx) {
                    mx = d[to];
                }
                s.push(to);
            }
        }
    }
}

int main() {
    int n, m, b, e;
    std::cin >> n >> m;
    int mx = -1;
    std::vector<std::vector<int>> g(n +1);
    std::vector<int> d(n + 1, -1);
    for (int i = 0; i < m; ++i) {
        std::cin >> b >> e;
        g[b].push_back(e);
    }
    for (int i = 1; i <= n; ++i) {
        dfs(i, g, d, mx);
    }
    

    std::cout << mx;
}