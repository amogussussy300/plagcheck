#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

const int INF = 1e9;


void dfs(int v, const std::vector<std::vector<int>>& g, int& mx, std::vector<int>& d, std::vector<bool>& used){

    std::stack<int> s;
    s.push(v);

    while (!s.empty()) {
        int v = s.top();
        s.pop();

        for (int to : g[v]) {
            if (!used[to]) {
                used[to] = true;
                d[to] = d[v] + 1;
                if (mx < d[to]) {
                    mx = d[to];
                }
                s.push(to);
            }
            
        }
    }
}

int main() {
    int n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int>> g(n + 1);
    std::vector<int> d(n + 1, INF);
    std::vector<bool> used(n + 1, false);
    int mx = 0;

    for (int i = 0; i < m; ++i) {
        int b, e;
        std::cin >> b >> e;
        g[b].push_back(e);
    }
    for (int i = 1; i <= n; ++i) {
        std::vector<int> d(n + 1, 0);
        d[i] = 0;
        if (!used[i]) {
            used[i] = true;
            dfs(i, g, mx, d, used);
        }
        

    }
    std::cout << mx;
}
