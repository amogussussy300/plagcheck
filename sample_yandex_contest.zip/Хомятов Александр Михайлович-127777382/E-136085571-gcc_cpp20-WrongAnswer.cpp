#include <iostream>
#include <vector>
#include <string>

using namespace std;

vector<int> prt, rnk, pty;

int fnd(int x) {
    if (prt[x] != x) {
        int orig = prt[x];
        prt[x] = fnd(orig);
        pty[x] ^= pty[orig];
    }
    return prt[x];
}

int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int n, m;
    cin >> n >> m;
    
    prt.resize(n+1);
    rnk.resize(n+1, 1);
    pty.resize(n+1, 0);
    for (int i = 0; i <= n; ++i) 
    {
        prt[i] = i;
    }
    
    string res;
    bool flg = true;
    
    for (int i = 0; i < m; ++i) 
    {
        int u, v;
        cin >> u >> v;
        if (!flg) 
        {
            res += '0';
            continue;
        }
        int pu = fnd(u);
        int pv = fnd(v);
        if (pu == pv) 
        {
            if ((pty[u] ^ pty[v]) == 0) 
            {
                flg = false;
                res += '0';
            } 
            else 
            {
                res += '1';
            }
        } 
        else 
        {
            if (rnk[pu] > rnk[pv]) 
            {
                prt[pv] = pu;
                pty[pv] = pty[u] ^ pty[v] ^ 1;
            } 
            else 
            {
                prt[pu] = pv;
                pty[pu] = pty[u] ^ pty[v] ^ 1;
                if (rnk[pu] == rnk[pv]) 
                {
                    rnk[pv]++;
                }
            }
            res += '2';
        }
    }
    
    cout << res << endl;
    return 0;
}