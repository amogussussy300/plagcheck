#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

int main() 
{
    int abc;
    cin >> abc;
    
    vector<vector<int>> jjj(abc + 1);
    for (int i = 2; i <= abc; ++i) 
    {
        int ppp;
        cin >> ppp;
        jjj[ppp].push_back(i);
    }
    
    vector<int> ddd(abc + 1);
    queue<int> qwe;
    qwe.push(1);
    ddd[1] = 0;
    
    while (!qwe.empty()) 
    {
        int crt = qwe.front();
        qwe.pop();
        for (int nxt : jjj[crt]) 
        {
            ddd[nxt] = ddd[crt] + 1;
            qwe.push(nxt);
        }
    }
    
    int mmm = *max_element(ddd.begin(), ddd.end());
    vector<int> vvv;
    for (int i = 1; i <= abc; ++i) 
    {
        if (ddd[i] == mmm) 
        {
            vvv.push_back(i);
        }
    }
    
    sort(vvv.begin(), vvv.end());
    cout << mmm << endl << vvv.size() << endl;
    for (size_t i = 0; i < vvv.size(); ++i) 
    {
        cout << (i ? " " : "") << vvv[i];
    }
    cout << endl;
}