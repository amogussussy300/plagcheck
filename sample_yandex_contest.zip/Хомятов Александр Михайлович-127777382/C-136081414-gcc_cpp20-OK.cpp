#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() 
{
    int abc, def, ghi;
    cin >> abc >> def >> ghi;
    
    vector<vector<int>> jkl(abc + 1);
    
    for (int i = 0; i < ghi; ++i) 
    {
        int aaa, bbb;
        cin >> aaa >> bbb;
        jkl[bbb].push_back(aaa);
    }
    
    vector<int> mno(abc + 1, -1);
    mno[def] = 0;
    
    queue<int> pqr;
    pqr.push(def);
    
    while (!pqr.empty()) 
    {
        int uuu = pqr.front();
        pqr.pop();
        for (int vvv : jkl[uuu]) 
        {
            if (mno[vvv] == -1) 
            {
                mno[vvv] = mno[uuu] + 1;
                pqr.push(vvv);
            }
        }
    }
    
    for (int i = 1; i <= abc; ++i) 
    {
        cout << mno[i] << " ";
    }
    cout << endl;
    
    return 0;
}