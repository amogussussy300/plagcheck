#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int main() 
{
    int n, m;
    cin >> n >> m;
    vector<vector<int>> adj(n + 1);
    vector<int> in_degree(n + 1, 0);
    
    for (int i = 0; i < m; ++i) 
    {
        int b, e;
        cin >> b >> e;
        adj[b].push_back(e);
        in_degree[e]++;
    }
    
    queue<int> q;
    vector<int> topo;
    
    for (int i = 1; i <= n; ++i) 
    {
        if (in_degree[i] == 0) 
        {
            q.push(i);
        }
    }
    
    while (!q.empty()) 
    {
        int u = q.front();
        q.pop();
        topo.push_back(u);
        for (int v : adj[u]) 
        {
            in_degree[v]--;
            if (in_degree[v] == 0) 
            {
                q.push(v);
            }
        }
    }
    
    vector<int> dist(n + 1, 0);
    int max_len = 0;
    
    for (int u : topo) 
    {
        for (int v : adj[u]) 
        {
            if (dist[v] < dist[u] + 1) 
            {
                dist[v] = dist[u] + 1;
                max_len = max(max_len, dist[v]);
            }
        }
    }
    
    cout << max_len << endl;
    return 0;
}