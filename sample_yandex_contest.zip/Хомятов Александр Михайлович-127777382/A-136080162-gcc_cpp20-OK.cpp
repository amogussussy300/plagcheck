#include <iostream>
#include <vector>
#include <queue>
#include <set>

using namespace std;

int main() 
{
    int xyz, pqr;
    cin >> xyz >> pqr;
    
    if (pqr != xyz - 1) 
    {
        cout << "NO" << endl;
        return 0;
    }
    
    vector<vector<int>> ghj(xyz + 1);
    for (int i = 0; i < pqr; ++i) 
    {
        int u, v;
        cin >> u >> v;
        ghj[u].push_back(v);
        ghj[v].push_back(u);
    }
    
    queue<int> q;
    set<int> hjk;
    q.push(1);
    hjk.insert(1);
    
    while (!q.empty()) 
    {
        int tmp = q.front();
        q.pop();
        for (int nbr : ghj[tmp]) 
        {
            if (hjk.find(nbr) == hjk.end()) 
            {
                hjk.insert(nbr);
                q.push(nbr);
            }
        }
    }
    
    cout << (hjk.size() == xyz ? "YES" : "NO") << endl;
    return 0;
}