#include <iostream>
#include <queue>
#include <vector>

void tops(std::vector<std::vector<int>> &gr, std::vector<int> &used,
          std::vector<int> &ord, int s) {
  used[s] = 1;
  for (int to : gr[s]) {
    if (used[to] == 0) {
      tops(gr, used, ord, to);
    }
  }
  ord.push_back(s);
}

int main() {
  int n, m;
  std::cin >> n >> m;
  std::vector<std::vector<int>> gr(n);
  for (int i = 0; i < m; ++i) {
    int a, b;
    std::cin >> a >> b;
    gr[a - 1].push_back(b - 1);
  }
  std::vector<int> used(n, 0);
  std::vector<int> ord;
  for (int i = 0; i < n; ++i) {
    if (used[i] == 0) {
      tops(gr, used, ord, i);
    }
  }
  std::vector<int> d(n, 0);
  int ans = 0;
  for (int i = ord.size() - 1; i >= 0; --i) {
    int v = ord[i];
    for (int to : gr[v]) {
      if (d[to] < d[v] + 1) {
        d[to] = d[v] + 1;
        ans = std::max(ans, d[to]);
      }
    }
  }
  std::cout << ans;

  return 0;
}
