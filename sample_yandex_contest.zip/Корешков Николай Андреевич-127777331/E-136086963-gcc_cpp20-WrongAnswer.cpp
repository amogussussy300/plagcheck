#include <iostream>
#include <queue>
#include <string>

struct DSU {
  std::vector<int> par;
  std::vector<int> size;
  DSU(int n) {
    par = std::vector<int>(n);
    size = std::vector<int>(n);
    for (int i = 0; i < n; ++i) {
      par[i] = i;
      size[i] = 1;
    }
  }
  int find(int v) {
    if (v == par[v]) {
      return v;
    }
    return par[v] = find(par[v]);
  }
  void union_s(int a, int b) {
    a = find(a);
    b = find(b);
    if (a != b) {
      if (size[a] < size[b]) {
        std::swap(a, b);
      }
      par[b] = a;
      size[a] += size[b];
    }
  }
};

int main() {
  int n, m;
  std::cin >> n >> m;
  DSU g(2 * n);
  std::string ans;
  for (int i = 0; i < m; ++i) {
    int a, b;
    std::cin >> a >> b;
    if (g.find(a - 1) == g.find(b - 1) || g.find(a - 1) == g.find(b - 1 + n)) {
      ans += '0';
    } else {
      ans += '1';
    }
    g.union_s(a - 1, b - 1 + n);
    g.union_s(b - 1, a - 1 + n);
  }
  std::cout << ans;
  return 0;
}