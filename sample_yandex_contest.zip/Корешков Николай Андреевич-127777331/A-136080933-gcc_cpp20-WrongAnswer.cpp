#include <iostream>
#include <queue>
#include <vector>

int dfs(int v, std::vector<std::vector<int>> &gr, std::vector<int> &used) {
  int count = 1;
  std::queue<int> q;
  q.push(v);
  used[v] = 1;
  while (!q.empty()) {
    int to = q.front();
    q.pop();
    for (int i : gr[to]) {
      if (used[i] == 0) {
        used[i] = 1;
        ++count;
        q.push(i);
      }
    }
  }
  return count;
}

int main() {
  int n, m;
  std::cin >> n >> m;
  std::vector<std::vector<int>> gr(n);
  for (int i = 0; i < m; ++i) {
    int a, b;
    std::cin >> a >> b;
    gr[a - 1].push_back(b - 1);
    gr[b - 1].push_back(a - 1);
  }
  if (n != m - 1) {
    std::cout << "NO";
    return 0;
  }
  std::vector<int> used(n, 0);
  int count = dfs(0, gr, used);
  if (count == n) {
    std::cout << "YES";
  } else {
    std::cout << "NO";
  }

  return 0;
}