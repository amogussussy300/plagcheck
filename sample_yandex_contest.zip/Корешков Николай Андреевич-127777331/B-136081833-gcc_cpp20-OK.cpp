// #include <iostream>
// #include <queue>
// #include <vector>

// int dfs(int v, std::vector<std::vector<int>> &gr, std::vector<int> &used) {
//   int count = 1;
//   std::queue<int> q;
//   q.push(v);
//   used[v] = 1;
//   while (!q.empty()) {
//     int to = q.front();
//     q.pop();
//     for (int i : gr[to]) {
//       if (used[i] == 0) {
//         used[i] = 1;
//         ++count;
//         q.push(i);
//       }
//     }
//   }
//   return count;
// }

// int main() {
//   int n, m;
//   std::cin >> n >> m;
//   std::vector<std::vector<int>> gr(n);
//   for (int i = 0; i < m; ++i) {
//     int a, b;
//     std::cin >> a >> b;
//     gr[a - 1].push_back(b - 1);
//     gr[b - 1].push_back(a - 1);
//   }
//   if (n != m + 1) {
//     std::cout << "NO";
//     return 0;
//   }
//   std::vector<int> used(n, 0);
//   int count = dfs(0, gr, used);
//   if (count == n) {
//     std::cout << "YES";
//   } else {
//     std::cout << "NO";
//   }

//   return 0;
// }

#include <iostream>
#include <queue>
#include <vector>

const int inf = 1e9;

void bfs(std::vector<std::vector<int>> &gr, std::vector<int> &used,
         std::vector<int> &dist) {
  std::queue<int> q;
  used[0] = 1;
  dist[0] = 0;
  q.push(0);
  while (!q.empty()) {
    int v = q.front();
    q.pop();
    for (int to : gr[v]) {
      if (dist[to] > dist[v] + 1) {
        dist[to] = dist[v] + 1;
        q.push(to);
      }
    }
  }
}

int main() {
  int n;
  std::cin >> n;
  std::vector<std::vector<int>> gr(n);
  for (int i = 1; i < n; ++i) {
    int par;
    std::cin >> par;
    gr[par - 1].push_back(i);
  }
  std::vector<int> used(n, 0);
  std::vector<int> d(n, inf);
  bfs(gr, used, d);
  int ans = -inf;
  for (int i = 0; i < n; ++i) {
    if (d[i] > ans) {
      ans = d[i];
    }
  }
  std::vector<int> anss;
  for (int i = 0; i < n; ++i) {
    if (d[i] == ans) {
      anss.push_back(i + 1);
    }
  }
  std::cout << ans << '\n' << anss.size() << '\n';
  for (int i : anss) {
    std::cout << i << ' ';
  }
}
