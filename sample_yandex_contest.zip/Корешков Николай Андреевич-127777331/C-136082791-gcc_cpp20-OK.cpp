#include <iostream>
#include <queue>
#include <vector>

const int inf = 1e9;

void bfs(std::vector<std::vector<int>> &gr, std::vector<int> &used,
         std::vector<int> &dist, int &st) {
  std::queue<int> q;
  dist[st] = 0;
  q.push(st);
  while (!q.empty()) {
    int v = q.front();
    q.pop();
    for (int to : gr[v]) {
      if (dist[to] > dist[v] + 1) {
        dist[to] = dist[v] + 1;
        q.push(to);
      }
    }
  }
}

int main() {
  int n, m, s;
  std::cin >> n >> s >> m;
  std::vector<std::vector<int>> gr(n);
  for (int i = 0; i < m; ++i) {
    int a, b;
    std::cin >> a >> b;
    gr[b - 1].push_back(a - 1);
  }
  --s;
  std::vector<int> used(n, 0);
  std::vector<int> d(n, inf);
  bfs(gr, used, d, s);
  for (int i = 0; i < n; ++i) {
    if (d[i] != inf) {
      std::cout << d[i] << " ";
    } else {
      std::cout << -1 << " ";
    }
  }
  return 0;
}
