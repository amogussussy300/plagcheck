n, s, m = map(int, input().split())
s -= 1
INF = 10000000
cit = [[] for i in range(n)]
md = [10000000 for i in range(n)]
ma = [[False for i in range(n)] for j in range(n)]
visited = [False for i in range(n)]
for i in range(m):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    cit[b].append(a)
    #ma[a][b] = True

def bfs(start):
    cs = cit[start]
    ns = []
    depth = 1
    sps = [cs, []]
    for _ in range(5):
        for i in sps[-2]:
            md[i] = min(md[i], depth)
            sps[-1] += cit[i] 
        sps.append([])
        if len(sps[-2])==0:
            break
md[s] = 0
bfs(s)
for i in md:
    if i == INF:
        print(-1, end = ' ')
    else:
        print(i, end = ' ')



