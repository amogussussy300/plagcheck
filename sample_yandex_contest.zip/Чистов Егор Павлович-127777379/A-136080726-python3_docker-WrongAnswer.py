n, m = map(int, input().split())
ans = 'YES'
def dfs(start, prev):
    #print(start)
    if visited[start]:
        return 'NO'
    visited[start] = True
    for i in graph[start]:
        if i != prev:
            if dfs(i, start):
                return 'NO'
    return False

graph = [[] for i in range(n)]

for i in range(m):
    u, v = map(int, input().split())
    u -= 1
    v -= 1
    graph[u].append(v)
    graph[v].append(u)
visited = [False for i in range(n)]
if dfs(0, -1):
    print('NO')
else:
    print('YES')
