n, m = map(int, input().split())

if m > n:
    print('NO')
else:
    ans = 'YES'
    def dfs(start, prev):
        #print(start)
        if visited[start]:
            return True
        visited[start] = True
        for i in graph[start]:
            if i != prev:
                if dfs(i, start):
                    return True
        return False

    graph = [[] for i in range(n)]

    for i in range(m):
        u, v = map(int, input().split())
        u -= 1
        v -= 1
        graph[u].append(v)
        graph[v].append(u)
    visited = [False for i in range(n)]
    
    res = dfs(0, -1)    
    if res:
        print('NO')
    else:
        flag = True
        for v in visited:
            if v == False:
                flag = False
                print('NO')
                break
                
        if flag:
            print('YES')



