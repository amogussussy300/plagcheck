#include <iostream>
#include <vector>

int main() {
  int n, s, m, a, b;
  std::cin >> n >> s >> m;
  --s;
  std::vector<std::vector<int>> cit(n, std::vector<int>());

  for (int i = 0; i < m; ++i) {
    std::cin >> a >> b;
    --a;
    --b;
    cit[b].push_back(a);
  }

  std::vector<int> md(n, 1000000);
  md[s] = 0;
  std::vector<std::vector<int>> sps;
  int le = 1;
  sps.push_back(cit[s]);
  sps.push_back(std::vector<int>());
  bool flag = true;
  int depth = 1;
  while (flag) {

    flag = false;
    for (auto& j : sps[le - 1]) {
      if (le < md[j]) {
          md[j] = le;
        }

      for (auto& i : cit[j]) {
        flag = true;
        if (le + 1 < md[i]) {
          md[i] = le + 1;
          sps[le].push_back(i);
        }
      }
    }
    le++;
    sps.push_back(std::vector<int>());
  }
  for (auto& i : md) {
    if (i == 1000000) {
        std::cout << -1 << " ";
    } else {
    std::cout << i << " ";
    }
  }
}
