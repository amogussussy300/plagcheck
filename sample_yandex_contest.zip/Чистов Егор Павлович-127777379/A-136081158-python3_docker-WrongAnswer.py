n, m = map(int, input().split())

if m > n:
    print('NO')
else:
    ans = 'YES'
    def dfs(start, prev):
        #print(start)
        if visited[start]:
            return 'NO'
        visited[start] = True
        for i in graph[start]:
            if i != prev:
                if dfs(i, start):
                    return 'NO'
        return False

    graph = [[] for i in range(n)]

    for i in range(m):
        u, v = map(int, input().split())
        u -= 1
        v -= 1
        graph[u].append(v)
        graph[v].append(u)
    visited = [False for i in range(n)]
    flag = True
    while flag:
        flag = False
        for i in range(n):
            if visited[i] == False:
                flag = True
                res = dfs(i, -1)    
                if res:
                    print('NO')
                    break
    if not res:
        print('YES')

