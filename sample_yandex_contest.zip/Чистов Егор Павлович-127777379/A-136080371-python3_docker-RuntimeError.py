n, m = map(int, input().split())

def dfs(start):
    if visited[start]:
        print('NO')
        quit()
    visited[start] = True
    for i in graph[start]:
        dfs(i)

graph = [[] for i in range(n)]

for i in range(m):
    u, v = map(int, input().split())
    u -= 1
    v -= 1
    graph[u].append(v)
    graph[v].append(u)
visited = [False for i in range(n)]
dfs(0)
print('YES')
