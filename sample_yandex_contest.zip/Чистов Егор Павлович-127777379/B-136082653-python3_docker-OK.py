n = int(input())

max_d = 0
ver_md = []

depths = [0 for i in range(n)]
#parents = []
childs = [[] for i in range(n)]
for i in range(n - 1):
    parent = int(input())
    parent -= 1
    #parents.append(parent)
    childs[parent].append(i + 1)

def setd(n):
    global max_d, ver_md
    cd = depths[n]
    if len(childs[n]) == 0:
        #print(cd)
        if cd > max_d:
            max_d = cd
            ver_md = [n + 1]
        elif cd == max_d:
            ver_md.append(n + 1)
    else:
        for i in childs[n]:
            depths[i] = cd + 1
            setd(i)
setd(0)
print(max_d)
print(len(ver_md))
print(*sorted(ver_md))
