n, s, m = map(int, input().split())
s -= 1
INF = 10000000
cit = [[] for i in range(n)]
md = [10000000 for i in range(n)]
ma = [[False for i in range(n)] for j in range(n)]
visited = [False for i in range(n)]
for i in range(m):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    cit[b].append(a)
    #ma[a][b] = True

def bfs(start):
    cs = cit[start]
    ns = []
    depth = 1
    for _ in range(10):
        for i in cs:
            md[i] = min(md[i], depth)
            ns += cit[i]
            #print(i, cit[i])
        #print(cs, ns)   
        cs = ns.copy()
        ns.clear()
        if len(cs)==0:
            break
md[s] = 0
bfs(s)
for i in md:
    if i == INF:
        print(-1, end = ' ')
    else:
        print(i, end = ' ')



