#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MAXN = 1e5 + 10;

vector<vector<pair<int, int>>> g;
vector<int> us;

bool dfs(int u, int k, int c) {
    us[u] = c;
    for (auto [v, ind] : g[u]) {
        if (ind > k) continue;
        if (us[v] == c) return 0;
        if (us[v] == 0) {
            if (!dfs(v, k, 3 - c)) {
                return 0;
            }
        }
    }
    return 1;
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
	int n, m, s;
	cin >> n >> m;
	g.resize(n);
	us.resize(n);

	int x, y;
	for (int i = 0; i < m; ++i) {
	    cin >> x >> y;
	    --x;
	    --y;
	    g[x].emplase_back({y, i});
	    g[y].emplase_back({x, i});
	}

	int l = -1, r = m, mid;

	while (l + 1 < r) {
	    //cerr << l << ' ' << r << '\n';
	    mid = (l + r) / 2;
	    for (int i = 0; i < n; ++i) {
	        us[i] = 0;
	    }
	    bool fl = 1;
	    for (int i = 0; i < n; ++i) {
	        if (us[i] == 0) {
	            if (!dfs(i, mid, 1)) {
	                fl = 0;
	                break;
	            }
	        }
	    }
	    if (fl) l = mid;
	    else r = mid;
	}

	for (int i = 0; i <= l; ++i) {
	    cout << '1';
	}

	for (int i = l + 1; i < m; ++i) {
	    cout << '0';
	}

	return 0;

}