#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MAXN = 1e5 + 10;

vector<int> p;
vector<int> s;

void init(int n) {
    for (int i = 0; i < n; ++i) {
        p[i] = i;
        s[i] = 1;
    }
}

int root(int u) {
    if (u == p[u]) return p[u];
    p[u] = root(p[u]);
    return p[u];
}

void add(int u, int v) {
    u = root(u);
    v = root(v);
    if (u == v) return;
    if (s[u] < s[v]) swap(u, v);
    p[v] = u;
    s[u] += s[v];
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
	int n, m;
	cin >> n >> m;
	p.resize(n);
	s.resize(n);
	init(n);
	
	int x, y;
	
	for (int i = 0; i < m; ++i) {
	    cin >> x >> y;
	    --x;
	    --y;
	    if (root(x) == root(y)) {
	        for (int j = i; j < m; ++j) cout << '0';
	        break;
	    }
	    cout << '1';
	    add(x, y);
	}
	
	
	return 0;
	
}
