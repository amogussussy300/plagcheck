#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MAXN = 110;

vector<vector<int>> g;
//int us[MAXN];

vector<vector<int>> dp;
int d[MAXN];
int mx = 0;

void dfs(int u, int p = -1) {
    //us[u] = 1;
    d[u] = (p == -1 ? 0 : d[p] + 1);
    mx = max(mx, d[u]);
    dp[d[u]].push_back(u);
    for (auto v : g[u]) {
        if (v == p) continue;
        dfs(v, u);
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
	int n;
	cin >> n;
	g.resize(n);
	dp.resize(n);
	int x;
	for (int i = 1; i < n; ++i) {
	    cin >> x;
	    --x;
	    g[x].push_back(i);
	}
	
	dfs(0);
	
	sort(dp[mx].begin(), dp[mx].end());
	cout << mx << '\n' << dp[mx].size() << '\n';
	for (auto i : dp[mx]) cout << i + 1 << ' ';
	
	return 0;
	
}
