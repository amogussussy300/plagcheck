#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MAXN = 110;

vector<vector<int>> g;
int us[MAXN];

void dfs(int u, int p = -1) {
    us[u] = 1;
    for (auto v : g[u]) {
        if (v == p) continue;
        if (us[v]) {
            cout << "NO";
            exit(0);
        }
        dfs(v, u);
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
	int n, m;
	cin >> n >> m;
	g.resize(n);
	
	int x, y;
	for (int i = 0; i < m; ++i) {
	    cin >> x >> y;
	    --x;
	    --y;
	    g[x].push_back(y);
	    g[y].push_back(x);
	}
	
	dfs(0);
	for (int i = 0; i < n; ++i) {
	    if (!us[i]) {
	        cout << "NO";
	        return 0;
	    }
	}
	cout << "YES";
	return 0;
	
}
