#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MAXN = 1e5 + 10;

vector<vector<int>> g;
//int us[MAXN];
int tout[MAXN];
int curt = 0;
int us[MAXN];
int dp[MAXN];
int a[MAXN];

void dfs(int u) {
    us[u] = 1;
    for (auto v : g[u]) {
        if (!us[v]) {
            dfs(v);
        }
    }
    //cerr << u << ' ' << curt << '\n';
    tout[u] = curt++;
}

bool cmp(int i1, int i2) {
    return tout[i1] < tout[i2];
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
	int n, m, s;
	cin >> n >> m;
	g.resize(n);
	
	int x, y;
	for (int i = 0; i < m; ++i) {
	    cin >> x >> y;
	    --x;
	    --y;
	    g[x].push_back(y);
	}
	
	for (int i = 0; i < n; ++i) {
	    if (!us[i]) {
	        dfs(i);
	    }
	}
	
	for (int i = 0; i < n; ++i) {
	    a[i] = i;
	    //cerr << tout[i] << ' ';
	}
	//cerr << '\n';
	sort(a, a + n, cmp);
	
	int ans = 0;
	for (int i = 0; i < n; ++i) {
	    int u = a[i];
	    //cerr << u << '\n';
	    dp[u] = 0;
	    for (auto v : g[u]) {
	        dp[u] = max(dp[u], dp[v] + 1);
	    }
	    ans = max(ans, dp[u]);
	}
	cout << ans;
	
	return 0;
	
}
