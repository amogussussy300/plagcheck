#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MAXN = 1e5 + 10;

vector<int> p;
vector<int> s;
vector<vector<int>> g;

vector<int> us;


void dfs(int u, int c, int p = -1) {
    us[u] = c;
    for (auto v : g[u]) {
        if (v == p) continue;
        //if (ind > k) continue;
        //if (us[v] == c) return 0;
        dfs(v, 3 - c, u);
    }
}

void init(int n) {
    for (int i = 0; i < n; ++i) {
        p[i] = i;
        s[i] = 1;
    }
}

int root(int u) {
    if (u == p[u]) return p[u];
    p[u] = root(p[u]);
    return p[u];
}

void add(int u, int v) {
    u = root(u);
    v = root(v);
    if (u == v) return;
    if (s[u] < s[v]) swap(u, v);
    p[v] = u;
    s[u] += s[v];
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
	int n, m;
	cin >> n >> m;
	g.resize(n);
	us.resize(n);
	p.resize(n);
	s.resize(n);
	init(n);
	for (int i = 0; i < n; ++i) {
	    us[i] = 0;   
	}

	int x, y;
    int fl = m;
	for (int i = 0; i < m; ++i) {
	    //cerr << i << '\n';
	    if (fl < m) break;
	    cin >> x >> y;
	    --x;
	    --y;
	    if (us[y] == 0) swap(x, y);
	    if (us[y] == 0) {
	        us[x] = 1;
	        us[y] = 2;
	        add(x, y);
	        g[x].push_back(y);
	        g[y].push_back(x);
	        continue;
	    }
	    if (us[x] == 0) {
	        us[x] = 3 - us[y];
	        add(x, y);
	        g[x].push_back(y);
	        g[y].push_back(x);
	        continue;
	    }
	    if (root(x) == root(y)) {
	        
	        if (us[x] == us[y]) {
	            //cerr << i << '\n';
	            fl = i;
	        }
	        g[x].push_back(y);
	        g[y].push_back(x);
	        continue;
	    }
	    if (us[x] != us[y]) {
	        add(x, y);
	        g[x].push_back(y);
	        g[y].push_back(x);
	        continue;
	    }
	    
	    if (s[x] > s[y]) swap(x, y);
	    dfs(x, 3 - us[y]);
	    add(x, y);
        g[x].push_back(y);
        g[y].push_back(x);
	    
	    
	    
	}


    for (int i = 0; i < fl; ++i) cout << '1';
    for (int i = fl; i < m; ++i) cout << '0';

	return 0;

}