#include <iostream>
#include <vector>
#include <utility>
#include <string>

class DSU {
private:
    std::vector<int> parent;
    std::vector<int> color;

public:
    DSU(int n) : parent(n), color(n, 0) {
        for (int i = 0; i < n; ++i) {
            parent[i] = i;
        }
    }

    int find(int u) {
        if (parent[u] != u) {
            int orig_parent = parent[u];
            parent[u] = find(parent[u]);
            color[u] ^= color[orig_parent];
        }
        return parent[u];
    }

    bool union_sets(int u, int v) {
        int root_u = find(u);
        int root_v = find(v);
        if (root_u == root_v) {
            return color[u] != color[v];
        } else {
            parent[root_v] = root_u;
            color[root_v] = (1 + color[u] + color[v]) % 2;
            return true;
        }
    }
};

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::pair<int, int>> edges(m);
    for (int i = 0; i < m; ++i) {
        std::cin >> edges[i].first >> edges[i].second;
        edges[i].first--;
        edges[i].second--;
    }

    DSU dsu(n);
    std::string result;
    bool is_bipartite = true;

    for (const auto& edge : edges) {
        int u = edge.first;
        int v = edge.second;
        if (!is_bipartite) {
            result += '0';
            continue;
        }
        if (!dsu.union_sets(u, v)) {
            is_bipartite = false;
            result += '0';
        } else {
            result += '1';
        }
    }

    std::cout << result << std::endl;
    return 0;
}