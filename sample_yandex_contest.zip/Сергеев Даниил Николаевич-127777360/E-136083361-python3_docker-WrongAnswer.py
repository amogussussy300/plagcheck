import sys

n, m = map(int, sys.stdin.readline().split())
parent = [i for i in range(n + 1)]
color = [0] * (n + 1)
result = []

def find(u):
    while parent[u] != u:
        parent[u] = parent[parent[u]]
        u = parent[u]
    return u

def union(u, v):
    root_u = find(u)
    root_v = find(v)
    if root_u != root_v:
        parent[root_v] = root_u


for _ in range(m):
    u, v = map(int, sys.stdin.readline().split())

    if find(u) == find(v):
        if color[u] == color[v]:
            result.append('0')
            continue

    result.append('1')

    if color[u] == color[v]:
        color[v] = 1 - color[u]

    union(u, v)

print(''.join(result))