#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <string>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, m;
    std::cin >> n >> m;

    std::vector<std::pair<int, int>> edges(m);
    for (int i = 0; i < m; ++i) {
        std::cin >> edges[i].first >> edges[i].second;
    }

    std::unordered_map<int, std::vector<int>> graph;
    std::string result;

    for (int i = 0; i < m; ++i) {
        int u = edges[i].first;
        int v = edges[i].second;

        graph[u].push_back(v);
        graph[v].push_back(u);

        bool is_bipartite = true;
        std::vector<int> color(n + 1, 0);
        std::queue<int> q;

        int start = u;
        if (color[start] == 0) {
            color[start] = 1;
            q.push(start);
        }

        while (!q.empty() && is_bipartite) {
            int current = q.front();
            q.pop();

            for (int neighbor : graph[current]) {
                if (color[neighbor] == 0) {
                    color[neighbor] = 3 - color[current];
                    q.push(neighbor);
                } else if (color[neighbor] == color[current]) {
                    is_bipartite = false;
                    break;
                }
            }
        }

        for (int node = 1; node <= n && is_bipartite; ++node) {
            if (color[node] == 0 && graph.count(node)) {
                color[node] = 1;
                q.push(node);
                while (!q.empty() && is_bipartite) {
                    int current = q.front();
                    q.pop();

                    for (int neighbor : graph[current]) {
                        if (color[neighbor] == 0) {
                            color[neighbor] = 3 - color[current];
                            q.push(neighbor);
                        } else if (color[neighbor] == color[current]) {
                            is_bipartite = false;
                            break;
                        }
                    }
                }
            }
        }

        result.push_back(is_bipartite ? '1' : '0');
    }
    
    std::cout << result << '\n';
    return 0;
}