#include <iostream>
#include <vector>
#include <queue>

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    
    int n, m;
    std::cin >> n >> m;
    
    std::vector<std::vector<int>> graph(n+1);
    std::vector<char> color(n+1);
    std::vector<char> res(m);
    std::queue<int> q;
    
    for (int i = 0; i < m; ++i) {
        int u, v;
        std::cin >> u >> v;
        
        graph[u].push_back(v);
        graph[v].push_back(u);
        
        bool bipartite = true;
        if (!color[u] && !color[v]) {
            color[u] = 1;
            color[v] = 2;
        } else if (!color[u]) {
            color[u] = 3 - color[v];
        } else if (!color[v]) {
            color[v] = 3 - color[u];
        } else if (color[u] == color[v]) {
            bipartite = false;
        }
        
        if (bipartite) {
            q.push(u);
            while (!q.empty() && bipartite) {
                int cur = q.front();
                q.pop();
                
                for (int nb : graph[cur]) {
                    if (!color[nb]) {
                        color[nb] = 3 - color[cur];
                        q.push(nb);
                    } else if (color[nb] == color[cur]) {
                        bipartite = false;
                        break;
                    }
                }
            }
        }
        
        res[i] = bipartite ? '1' : '0';
    }
    
    fwrite(res.data(), 1, m, stdout);
    return 0;
}