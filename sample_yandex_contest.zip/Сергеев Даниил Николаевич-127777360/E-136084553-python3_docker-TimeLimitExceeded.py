import sys
from collections import deque, defaultdict


input = sys.stdin.read
data = input().split()
idx = 0
n = int(data[idx])
idx += 1
m = int(data[idx])
idx += 1

edges = []
for _ in range(m):
    u = int(data[idx])
    idx += 1
    v = int(data[idx])
    idx += 1
    edges.append((u, v))

graph = defaultdict(list)
result = []

for i in range(m):
    u, v = edges[i]
    graph[u].append(v)
    graph[v].append(u)

    is_bipartite = True
    color = [0] * (n + 1)
    queue = deque()

    start = u
    if color[start] == 0:
        color[start] = 1
        queue.append(start)

    while queue and is_bipartite:
        current = queue.popleft()
        for neighbor in graph[current]:
            if color[neighbor] == 0:
                color[neighbor] = 3 - color[current]
                queue.append(neighbor)
            elif color[neighbor] == color[current]:
                is_bipartite = False
                break

    for node in range(1, n + 1):
        if color[node] == 0 and node in graph:
            color[node] = 1
            queue.append(node)
            while queue and is_bipartite:
                current = queue.popleft()
                for neighbor in graph[current]:
                    if color[neighbor] == 0:
                        color[neighbor] = 3 - color[current]
                        queue.append(neighbor)
                    elif color[neighbor] == color[current]:
                        is_bipartite = False
                        break

    result.append('1' if is_bipartite else '0')

print(''.join(result))