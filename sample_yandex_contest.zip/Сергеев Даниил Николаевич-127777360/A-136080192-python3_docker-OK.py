n, m = map(int, input().split())
adj = [[] for _ in range(n + 1)]

for _ in range(m):
    u, v = map(int, input().split())
    adj[u].append(v)
    adj[v].append(u)

if m != n - 1:
    print("NO")
else:
    visited = [False] * (n + 1)
    stack = [1]
    visited[1] = True
    count = 1

    while stack:
        u = stack.pop()
        for v in adj[u]:
            if not visited[v]:
                visited[v] = True
                stack.append(v)
                count += 1

    if count == n:
        print("YES")
    else:
        print("NO")