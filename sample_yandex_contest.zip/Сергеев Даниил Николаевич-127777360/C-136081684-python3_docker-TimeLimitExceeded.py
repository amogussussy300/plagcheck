from collections import deque
import sys

input = sys.stdin.read 
data = input().split()

idx = 0
n = int(data[idx])
idx += 1
s = int(data[idx])
idx += 1
m = int(data[idx])
idx += 1

adj = [[] for _ in range(n + 1)]
for _ in range(m):
    a = int(data[idx])
    idx += 1
    b = int(data[idx])
    idx += 1
    adj[b].append(a)

distances = [-1] * (n + 1)
distances[s] = 0
q = deque([s])

while q:
    current = q.popleft()
    for neighbor in adj[current]:
        if distances[neighbor] == -1:
            distances[neighbor] = distances[current] + 1
            q.append(neighbor)

print(' '.join(map(str, distances[1:n + 1])))