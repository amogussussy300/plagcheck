from collections import deque


n = int(input())
parent = [0] * (n + 1)
distance = [0] * (n + 1)

for i in range(2, n + 1):
    parent[i] = int(input())

q = deque()
q.append(1)
distance[1] = 0

while q:
    u = q.popleft()
    for v in range(2, n + 1):
        if parent[v] == u:
            distance[v] = distance[u] + 1
            q.append(v)

max_dist = max(distance[1:n + 1])
count = distance.count(max_dist)
vertices = [i for i in range(1, n + 1) if distance[i] == max_dist]

print(max_dist)
print(count)
print(' '.join(map(str, sorted(vertices))))