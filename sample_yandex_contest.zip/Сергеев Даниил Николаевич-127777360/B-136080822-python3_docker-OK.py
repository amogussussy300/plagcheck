from collections import deque

n = int(input())
parent = [0] * (n + 1) 
children = [[] for _ in range(n + 1)]

for vertex in range(2, n + 1):
    parent_vertex = int(input())
    parent[vertex] = parent_vertex
    children[parent_vertex].append(vertex)
 
distances = [0] * (n + 1)
queue = deque([1])

while queue:
    current_vertex = queue.popleft()
    for child in children[current_vertex]:
        distances[child] = distances[current_vertex] + 1
        queue.append(child)

max_distance = max(distances[1:])

farthest_vertices = [v for v in range(1, n + 1) if distances[v] == max_distance]
count = len(farthest_vertices)

print(max_distance)
print(count)
print(' '.join(map(str, sorted(farthest_vertices))))