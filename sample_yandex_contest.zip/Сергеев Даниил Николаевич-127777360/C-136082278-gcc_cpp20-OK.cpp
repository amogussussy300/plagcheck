#include <iostream>
#include <vector>
#include <queue>
#include <string>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, s, m;
    std::cin >> n >> s >> m;

    std::vector<std::vector<int>> reverse_adj(n + 1);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        reverse_adj[b].push_back(a);
    }

    std::vector<int> dist(n + 1, -1);
    dist[s] = 0;
    std::queue<int> q;
    q.push(s);

    while (!q.empty()) {
        int v = q.front();
        q.pop();
        for (int u : reverse_adj[v]) {
            if (dist[u] == -1) {
                dist[u] = dist[v] + 1;
                q.push(u);
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        if (i > 1) std::cout << " ";
        std::cout << dist[i];
    }
    std::cout << "\n";

    return 0;
}