import sys
from collections import deque

n, s, m = map(int, sys.stdin.readline().split())
reverse_adj = [[] for _ in range(n + 1)]

for _ in range(m):
    a, b = map(int, sys.stdin.readline().split())
    reverse_adj[b].append(a)

dist = [-1] * (n + 1)
dist[s] = 0
q = deque([s])

while q:
    v = q.popleft()
    for u in reverse_adj[v]:
        if dist[u] == -1:
            dist[u] = dist[v] + 1
            q.append(u)

print(' '.join(map(str, dist[1:n+1])))