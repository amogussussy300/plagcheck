import sys
from collections import defaultdict, deque

n, m = map(int, sys.stdin.readline().split())
edges = [tuple(map(int, sys.stdin.readline().split())) for _ in range(m)]

graph = defaultdict(list)
color = [0] * (n + 1)
is_bipartite = True
result = []

for u, v in edges:
    graph[u].append(v)
    graph[v].append(u)

    if color[u] == color[v] and color[u] != 0:
        is_bipartite = False

    if color[u] == 0 and color[v] == 0:
        color[u] = 1
        color[v] = 2
    elif color[u] == 0:
        color[u] = 3 - color[v]
    elif color[v] == 0:
        color[v] = 3 - color[u]

    if is_bipartite:
        queue = deque()
        queue.append(u)
        visited = set()

        while queue and is_bipartite:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)

            for neighbor in graph[current]:
                if color[neighbor] == color[current]:
                    is_bipartite = False
                    break
                if color[neighbor] == 0:
                    color[neighbor] = 3 - color[current]
                if neighbor not in visited:
                    queue.append(neighbor)

    result.append('1' if is_bipartite else '0')

print(''.join(result))