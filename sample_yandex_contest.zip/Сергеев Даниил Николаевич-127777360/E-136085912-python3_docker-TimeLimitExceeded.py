n, m = map(int, input().split())
edges = [tuple(map(int, input().split())) for _ in range(m)]

parent = list(range(n))
color = [0] * n
is_bipartite = True
result = []

def find(u):
    if parent[u] != u:
        orig_parent = parent[u]
        parent[u] = find(parent[u])
        color[u] ^= color[orig_parent]
    return parent[u]

for u, v in edges:
    if not is_bipartite:
        result.append('0')
        continue
    u -= 1
    v -= 1
    root_u = find(u)
    root_v = find(v)
    if root_u == root_v:
        if color[u] == color[v]:
            is_bipartite = False
            result.append('0')
        else:
            result.append('1')
    else:
        parent[root_v] = root_u
        color[root_v] = (1 + color[u] + color[v]) % 2
        result.append('1')

print(''.join(result))