n, start, m = map(int, input().split())
adj_matrix = [[0] * n for _ in range(n)]

for _ in range(m):
    u, v = map(int, input().split())
    adj_matrix[u-1][v-1] = 1

result = []
for i in range(1, n+1):
    count = 0
    for j in range(i, start):
        if j < n-1 and adj_matrix[j][j+1] == 1:
            count += 1
    if i > start and count == 0:
        result.append('-1')
    else:
        result.append(str(count))

print(' '.join(result))