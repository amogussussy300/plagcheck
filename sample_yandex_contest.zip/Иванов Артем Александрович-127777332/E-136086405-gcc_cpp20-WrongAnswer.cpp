#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <queue>
#include <cmath>
#define int long long
using namespace std;

struct edge {
    int from, to;
};

vector<int> p, dist;

int find(int v) {
    if (v == p[v]) return v;
    int root = find(p[v]);
    dist[v] ^= dist[p[v]];
    p[v] = root;
    return root;
}

bool unite(int a, int b) {
    int pa = find(a), pb = find(b);
    if (pa == pb) {
        return dist[a] != dist[b];
    }
    p[pa] = pb;
    dist[pa] = dist[a] ^ dist[b] ^ 1;
    return true;
}

vector<edge> v;
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    p.resize(n + 1);
    dist.resize(n + 1, 0);
    for (int i = 0; i <= n; i++) {
        p[i] = i;
    }

    string result;
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        if (unite(a, b)) {
            result += '1';
        } else {
            result += '0';
        }
    }

    cout << result << "\n";

    return 0;
}
