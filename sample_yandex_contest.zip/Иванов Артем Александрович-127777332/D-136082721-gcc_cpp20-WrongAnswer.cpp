#include <bits/stdc++.h>

#define int long long
using namespace std;

vector<vector<int>> dist;

const int INF = 1e9;
signed main() {
    int n, m;
    cin >> n >> m;
    dist.resize(n, vector<int>(n, INF));

    for (int i = 0; i < m; i++) {
        int a; int b;
        cin >> a >> b;
        a--;b--;
        dist[a][b] = 1;
    }

    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (dist[i][k] < INF && dist[k][j] < INF) {
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
    }
    int ans = 0;
    for (int i = 0; i < dist.size(); i++) {
        for (int j = 0; j < dist[i].size(); j++) {
            if (dist[i][j] != INF)
                ans = max(dist[i][j], ans);
        }
    }
    cout << ans;

    return 0;
}