#include <iostream>
#include <vector>
#include <string>
#define int long long
using namespace std;

vector<int> parent, dist;

pair<int, int> find(int v) {
    if (v == parent[v]) {
        return {v, 0};
    }
    auto [root, d] = find(parent[v]);
    parent[v] = root;
    dist[v] ^= d;
    return {parent[v], dist[v]};
}

bool unite(int u, int v) {
    auto [root_u, dist_u] = find(u);
    auto [root_v, dist_v] = find(v);

    if (root_u == root_v) {
        return dist_u != dist_v;
    }

    parent[root_u] = root_v;
    dist[root_u] = dist_u ^ dist_v ^ 1;
    return true;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    parent.resize(n + 1);
    dist.resize(n + 1, 0);
    for (int i = 0; i <= n; ++i) {
        parent[i] = i;
    }

    string result;
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        if (unite(u, v)) {
            result += '1';
        } else {
            result += '0';
        }
    }

    cout << result << "\n";

    return 0;
}
