#include <iostream>
#include <vector>

using namespace std;
vector<vector<int>> gr;
vector<int> d;

bool dfs(int v, int p) {
    for (int i = 0; i < gr[v].size(); i++) {
        if (gr[v][i] == p)
            continue;
        //cout << d[gr[v][i]] << ' ' << gr[v][i] << ' ' << v << '\n';
        d[gr[v][i]] = d[v] + 1;
        dfs(gr[v][i], v);

    }
    return true;
}

int main()
{
    int n;
    cin >> n;
    gr.resize(n);
    for (int i = 1; i < n; i++) {
        int t1;
        cin >> t1;
        t1--;
        gr[t1].push_back(i);
    }
    d.resize(n, 0);
    dfs(0, -1);

    int n_ans = 0;
    for (int i = 0; i < n; i++) {
        n_ans = max(d[i], n_ans);
    }
    cout << n_ans << '\n';
    vector<int> ans;
    for (int i = 0; i < n; i++) {
        if (d[i] == n_ans) {
            ans.push_back(i + 1);
        }
    }
    cout << ans.size() << '\n';
    for (int i = 0; i < ans.size(); i++) {
        cout << ans[i] << ' ';
    }
}