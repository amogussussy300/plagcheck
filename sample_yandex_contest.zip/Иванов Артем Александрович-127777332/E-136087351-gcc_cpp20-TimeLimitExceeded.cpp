#include <iostream>
#include <vector>
#include <queue>
using namespace std;

bool check(int n, const vector<vector<int>>& graph) {

    vector<int> color(n + 1, 0);

    for (int i = 1; i <= n; ++i) {
        if (color[i] == 0) {
            queue<int> q;
            q.push(i);
            color[i] = 1;

            while (!q.empty()) {
                int v = q.front();
                q.pop();
                for (int u : graph[v]) {
                    if (color[u] == 0) {
                        color[u] = 3 - color[v];
                        q.push(u);
                    } else if (color[u] == color[v]) {
                        return false;
                    }
                }
            }
        }
    }

    return true;
}

int main() {
    int n, m;
    cin >> n >> m;

    vector<vector<int>> graph(n + 1);

    string result;

    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;

        graph[a].push_back(b);
        graph[b].push_back(a);

        if (check(n, graph)) {
            result += '1';
        } else {
            result += '0';
        }
    }

    cout << result << "\n";

    return 0;
}
