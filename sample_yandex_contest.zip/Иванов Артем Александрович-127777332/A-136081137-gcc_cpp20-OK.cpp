#include <iostream>
#include <vector>

using namespace std;
vector<vector<int>> gr;
vector<int> d;

bool dfs(int v, int p) {
    bool ans = true;
    for (int i = 0; i < gr[v].size(); i++) {
        if (gr[v][i] == p)
            continue;
        //cout << d[gr[v][i]] << ' ' << gr[v][i] << ' ' << v << '\n';
        if (d[gr[v][i]] != 1) {

            return false;
        }
        d[gr[v][i]] = 0;
        ans = dfs(gr[v][i], v);
        if (!ans)
            return ans;
    }
    return ans;
}

int main()
{
    int n, m;
    cin >> n >> m;
    gr.resize(n);
    for (int i = 0; i < m; i++) {
        int t1, t2;
        cin >> t1 >> t2;
        t1--;t2--;
        gr[t1].push_back(t2);
        gr[t2].push_back(t1);
    }
    d.resize(n, 1);
    bool ans = dfs(0, -1);

    for (int i = 1; i < n; i++) {
        if (d[i] == 1) {
            cout << "NO";
            return 0;
        }
    }
    if (ans)
        cout << "YES";
    else
        cout <<"NO";
}