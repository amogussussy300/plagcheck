#include <iostream>
#include <string>
#include <vector>
using namespace std;

vector<int> parent, rank_, dist;

int find(int v) {
    if (parent[v] == v) return v;
    int p = parent[v];
    int d = dist[v];
    int root = find(p);
    parent[v] = root;
    dist[v] = d ^ dist[p];
    return root;
}

bool unite(int a, int b) {
    int pa = find(a), pb = find(b);
    if (pa == pb) return (dist[a] ^ dist[b]) != 0;
    if (rank_[pa] < rank_[pb]) {
        swap(pa, pb);
        swap(a, b);
    }
    parent[pb] = pa;
    dist[pb] = dist[a] ^ dist[b] ^ 1;
    if (rank_[pa] == rank_[pb]) rank_[pa]++;
    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    cin >> n >> m;
    parent.resize(n + 1);
    rank_.resize(n + 1, 1);
    dist.resize(n + 1, 0);
    for (int i = 0; i <= n; ++i) parent[i] = i;
    string res;
    while (m--) {
        int a, b;
        cin >> a >> b;
        res += unite(a, b) ? '1' : '0';
    }
    cout << res << "\n";
}
