#include <iostream>
#include <string>
#include <vector>
using namespace std;

vector<int> parent, dist;

int find(int v) {
    if (v == parent[v]) return v;
    int root = find(parent[v]);
    dist[v] ^= dist[parent[v]];
    parent[v] = root;
    return root;
}

bool unite(int a, int b) {
    int pa = find(a), pb = find(b);
    if (pa == pb) {
        return dist[a] != dist[b];
    }
    parent[pa] = pb;
    dist[pa] = dist[a] ^ dist[b] ^ 1;
    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    parent.resize(n + 1);
    dist.resize(n + 1, 0);
    for (int i = 0; i <= n; ++i) {
        parent[i] = i;
    }

    string result;
    bool flag = true;

    while (m--) {
        int a, b;
        cin >> a >> b;

        if (flag) {
            if (!unite(a, b)) {
                flag = false;
            }
        }
        result += flag ? '1' : '0';
    }

    cout << result << "\n";

    return 0;
}
