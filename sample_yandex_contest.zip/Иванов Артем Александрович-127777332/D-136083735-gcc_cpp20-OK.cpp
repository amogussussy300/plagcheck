#include <bits/stdc++.h>
#define int long long
using namespace std;

const int INF = 1e18;

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    vector<vector<int>> adj(n + 1);
    vector<int> d(n + 1, 0);

    for (int i = 0; i < m; ++i) {
        int b, e;
        cin >> b >> e;
        adj[b].push_back(e);
        d[e]++;
    }

    queue<int> q;
    for (int i = 1; i <= n; ++i) {
        if (d[i] == 0) {
            q.push(i);
        }
    }
    vector<int> ans(n + 1, 0);

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        for (int v : adj[u]) {
            ans[v] = max(ans[v], ans[u] + 1);
            d[v]--;
            if (d[v] == 0) {
                q.push(v);
            }
        }
    }

    int res = 0;
    for (int i = 1; i <= n; ++i) {
        res = max(res, ans[i]);
    }

    cout << res << "\n";

    return 0;
}