#include <iostream>
#include <string>
#include <vector>
using namespace std;

vector<int> parent, dist;

int find(int v) {
    if (v == parent[v]) return v;
    int old_parent = parent[v];
    int root = find(old_parent);
    parent[v] = root;
    dist[v] ^= dist[old_parent];
    return root;
}

bool unite(int a, int b) {
    int pa = find(a), pb = find(b);
    if (pa == pb) {
        return dist[a] != dist[b];
    }
    parent[pa] = pb;
    dist[pa] = dist[a] ^ dist[b] ^ 1;
    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    cin >> n >> m;
    parent.resize(n + 1);
    dist.resize(n + 1, 0);
    for (int i = 0; i <= n; ++i) parent[i] = i;
    string res;
    while (m--) {
        int a, b;
        cin >> a >> b;
        res += unite(a, b) ? '1' : '0';
    }
    cout << res << "\n";
}
