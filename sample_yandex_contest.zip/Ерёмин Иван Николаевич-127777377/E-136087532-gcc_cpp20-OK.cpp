#include <iostream>
#include <vector>
#include <algorithm>

std::vector<int> parent;
std::vector<int> rank;
std::vector<int> color;
std::pair<int, int> find(int x) {
    if (parent[x] != x) {
        std::pair<int, int> root_info = find(parent[x]);
        parent[x] = root_info.first;    
        color[x] ^= root_info.second; 
        return std::make_pair(parent[x], color[x]);
    }
    return std::make_pair(x, color[x]);
}
bool unite(int x, int y) {
    std::pair<int, int> x_info = find(x);
    std::pair<int, int> y_info = find(y);
    int rx = x_info.first, cx = x_info.second;
    int ry = y_info.first, cy = y_info.second;

    if (rx == ry) {
        return cx != cy;
    }

    if (rank[rx] > rank[ry]) {
        parent[ry] = rx;
        color[ry] = cx ^ cy ^ 1;
    }
    else {
        parent[rx] = ry;
        color[rx] = cx ^ cy ^ 1;
        if (rank[rx] == rank[ry]) {
            rank[ry]++;
        }
    }
    return true;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    parent.resize(n);
    rank.resize(n, 0);
    color.resize(n, 0);

    for (int i = 0; i < n; ++i) {
        parent[i] = i;
    }

    std::string ans(m, '0');
    bool is_bi = true;

    for (int i = 0; i < m; ++i) {
        int u, v;
        std::cin >> u >> v;
        u--; v--;

        if (is_bi) {
            is_bi = unite(u, v);
            if (is_bi) {
                ans[i] = '1';
            }
        }
    }

    std::cout << ans << std::endl;
}