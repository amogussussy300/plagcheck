#include <iostream>
#include <vector>
#include <deque>
#include <string>

int main() {
    int n, s, m;
    std::cin >> n >> s >> m;
    std::vector<std::vector<int>> graph(n + 1);

    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        graph[b].push_back(a);
    }

    std::vector<int> dis(n + 1, -1);
    dis[s] = 0;
    std::deque<int> q;
    q.push_back(s);

    while (!q.empty()) {
        int cur = q.front();
        q.pop_front();
        for (int i : graph[cur]) {
            if (dis[i] == -1) {
                dis[i] = dis[cur] + 1;
                q.push_back(i);
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        std::cout << dis[i] << (i < n ? " " : "");
    }
}