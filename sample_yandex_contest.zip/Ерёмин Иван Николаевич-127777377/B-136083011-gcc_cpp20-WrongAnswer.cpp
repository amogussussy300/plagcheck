#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <unordered_map>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<pair<int, int>> ver;
    for (int i = 0; i < n - 1; ++i) {
        int v;
        cin >> v;
        ver.emplace_back(i + 2, v - 1);
    }

    unordered_map<int, vector<int>> gr;
    for (const auto& [u, v] : ver) {
        gr[u].push_back(v);
        gr[v].push_back(u);
    }

    vector<int> d(n + 1, -1);
    d[1] = 0;
    queue<int> q;
    q.push(1);

    while (!q.empty()) {
        int temp = q.front();
        q.pop();

        for (int i : gr[temp]) {
            if (d[i] == -1) {
                d[i] = d[temp] + 1;
                q.push(i);
            }
        }
    }

    int m_ans = *max_element(d.begin(), d.end());
    vector<int> f;
    for (int i = 0; i < d.size(); ++i) {
        if (d[i] == m_ans) {
            f.push_back(i);
        }
    }

    cout << m_ans << endl;
    cout << f.size() << endl;

    sort(f.begin(), f.end());
    for (int i = 0; i < f.size(); ++i) {
        if (i != 0) cout << " ";
        cout << f[i];
    }
    cout << endl;
}