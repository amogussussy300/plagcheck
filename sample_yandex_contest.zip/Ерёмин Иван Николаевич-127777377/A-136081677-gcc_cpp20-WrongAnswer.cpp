#include <iostream>
#include <vector>

void dfs(int v, std::vector<bool>& used, std::vector<int>& p, std::vector<std::vector<int>>& graph, std::vector<int>& cycle) {
    used[v] = 1;
    for (auto to : graph[v]) {
        if (used[to] == 0) {
            p[to] = v;
            dfs(to, used, p, graph, cycle);
            if (!cycle.empty()) return;
        }
        else if (used[to] == 1 && to != p[v]) {
            for (int u = v; u != to; u = p[u]) {
                cycle.push_back(u);
            }
            cycle.push_back(to);
            return;
        }
    }
    used[v] = 2;
}

void dfs(int v, std::vector<bool>& used, std::vector<int>& components, std::vector<std::vector<int>>& graph) {
    used[v] = true;
    components.push_back(v);
    for (auto to : graph[v]) {
        if (!used[to]) {
            dfs(to, used, components, graph);
        }
    }
}

int main() {
    int n, m = 0;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n);
    for (int i = 0; i < m; ++i) {
        int ch1, ch2;
        std::cin >> ch1 >> ch2;
        --ch1;
        --ch2;
        graph[ch1].push_back(ch2);
    }
    std::vector<bool> used(n, 0);
    std::vector<int> p(n, -1);
    std::vector<int> cycle;
    std::vector<int> components;

    for (int i = 0; i < n; ++i) {
        if (!used[i]) {
            dfs(i, used, p, graph, cycle);
            if (!cycle.empty()) break;
        }
    }

    if (cycle.empty() && components.size() == 0) {
        std::cout << "YES" << std::endl;
    }
    else {
        std::cout << "NO" << std::endl;
    }
}