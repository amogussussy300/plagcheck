#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

int main() {
    int n;
    std::cin >> n;
    std::vector<std::vector<int>> ch(n + 1);
    std::vector<int> dp(n + 1, 0);

    for (int i = 2; i <= n; ++i) {
        int p;
        std::cin >> p;
        ch[p].push_back(i);
    }

    std::queue<int> q;
    q.push(1); 
    dp[1] = 0;

    while (!q.empty()) {
        int cur = q.front();
        q.pop();

        for (int child : ch[cur]) {
            dp[child] = dp[cur] + 1;
            q.push(child);
        }
    }

    int mx = *max_element(dp.begin() + 1, dp.end());
    std::vector<int> mx_node;

    for (int i = 1; i <= n; ++i) {
        if (dp[i] == mx) {
            mx_node.push_back(i);
        }
    }

    std::cout << mx << std::endl;
    std::cout << mx_node.size() << std::endl;

    for (int node : mx_node) {
        std::cout << node << " ";
    }
}