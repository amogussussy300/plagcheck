#include <iostream>
#include <vector>

bool hasCycle(int v, const std::vector<std::vector<int>>& graph, std::vector<bool>& visited, int parent, std::vector<int>& cycle) {
    visited[v] = true;
    for (int to : graph[v]) {
        if (!visited[to]) {
            if (hasCycle(to, graph, visited, v, cycle)) {
                if (cycle.empty() || cycle.front() != to) {
                    cycle.push_back(v);
                    return true;
                }
            }
        }
        else if (to != parent) {
            cycle.push_back(to);
            cycle.push_back(v);
            return true;
        }
    }
    return false;
}

bool isTree(const std::vector<std::vector<int>>& graph, int n) {
    if (n == 0) return true; 

    std::vector<bool> visited(n, false);
    std::vector<int> cycle;
    if (hasCycle(0, graph, visited, -1, cycle)) {
        return false;
    }
    for (bool v : visited) {
        if (!v) return false;
    }

    return true;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    if (m != n - 1) {  
        std::cout << "NO" << std::endl;
        return 0;
    }
    std::vector<std::vector<int>> graph(n);
    for (int i = 0; i < m; ++i) {
        int u, v;
        std::cin >> u >> v;
        --u; --v;  
        graph[u].push_back(v);
        graph[v].push_back(u);
    }
    if (isTree(graph, n)) {
        std::cout << "YES" << std::endl;
    }
    else {
        std::cout << "NO" << std::endl;
    }
}