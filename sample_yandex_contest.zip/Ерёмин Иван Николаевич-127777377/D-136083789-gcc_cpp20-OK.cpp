#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>


int main() {
    int n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int>> graph(n + 1);
    std::vector<int> deg(n + 1, 0);

    while (m--) {
        int u, v;
        std::cin >> u >> v;
        graph[u].emplace_back(v);
        deg[v] = deg[v] + 1;
    }

    std::queue<int> q;

    for (int i = 1; i <= n; ++i) {
        if (deg[i] == 0) q.push(i);
    }

    std::vector<int> topo;

    while (!q.empty()) {
        int n = q.front();
        q.pop();
        topo.emplace_back(n);

        for (int i : graph[n]) {
            deg[i] = deg[i] - 1;
            if (deg[i] == 0) q.push(i);
        }
    }

    std::vector<int> arr(n + 1);
    int answer = 0;

    for (int n : topo) {
        for (int i : graph[n]) {
            arr[i] = std::max(arr[i], arr[n] + 1);
        }
    }

    answer = *std::max_element(arr.begin(), arr.end());
    std::cout << answer;
}