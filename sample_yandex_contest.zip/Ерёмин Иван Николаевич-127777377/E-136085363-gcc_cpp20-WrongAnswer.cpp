#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>


bool check_bi(int v, std::vector<int>& metka, std::vector<std::vector<int>>& g) {
    for (int to : g[v]) {
        int metka_to = 3 - metka[v];
        if (metka[to] == 0) {
            metka[to] = metka_to;
            if (!check_bi(to, metka, g)) {
                return false;
            }
        }
        else if (metka[to] == metka[v]) {
            return false;
        }
    }
    return true;
}


int main() {
    int n, m = 0;
    std::cin >> n >> m;
    std::vector<int> ans;
    std::vector<std::vector<int>> g(n);
    for (int i = 0; i < m; ++i) {
        int ch1, ch2 = 0;
        std::cin >> ch1 >> ch2;
        g[ch1 - 1].push_back(ch2 - 1);
        g[ch2 - 1].push_back(ch1 - 1);
        std::vector<int> metka(n, 0);
        for (int i = 0; i < n; ++i) {
            if (metka[i] == 0) {
                metka[i] = 1;
                if (!check_bi(i, metka, g)) {
                    ans.push_back(0);
                    break;
                }
            }
        }
        ans.push_back(1);
    }
    for (size_t i = 0; i < ans.size() - 1; ++i) {
        std::cout << ans[i];
    }
}