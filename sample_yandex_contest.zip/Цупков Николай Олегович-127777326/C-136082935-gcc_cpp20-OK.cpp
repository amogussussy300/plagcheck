﻿#include <iostream>
#include <vector>
#include <queue>


const int INF = -1;

class BFS {
private:
    std::vector<std::vector<int>> g;
    std::vector<int> dist;
    int n;

public:
    BFS(const std::vector<std::vector<int>>& graph, int size) : g(graph), n(size), dist(size, INF) {}

    void run(int s) {
        std::queue<int> q;
        q.push(s);
        dist[s] = 0;

        while (!q.empty()) {
            int v = q.front();
            q.pop();
            for (int u : g[v]) {
                if (dist[u] == INF) {
                    dist[u] = dist[v] + 1;
                    q.push(u);
                }
            }
        }
    }

    std::vector<int> get_distances() const {
        return dist;
    }
};

int main() {

    int n, s, m;
    std::cin >> n >> s >> m;
    s--;

    std::vector<std::vector<int>> g(n);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        a--; b--;
        g[b].push_back(a);
    }

    BFS bfs(g, n);
    bfs.run(s);
    std::vector<int> distances = bfs.get_distances();

    for (int i = 0; i < n; ++i) {
        if (i != 0) std::cout << " ";
        std::cout << distances[i];
    }
    std::cout << std::endl;

}