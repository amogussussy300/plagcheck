﻿#include <iostream>
#include <vector>
#include <queue>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, s, m;
    std::cin >> n >> s >> m;
    s--;

    std::vector<std::vector<int>> rg(n);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        a--; b--;
        rg[b].push_back(a);
    }

    std::vector<int> d(n, -1);
    d[s] = 0;

    std::queue<int> q;
    q.push(s);

    while (!q.empty()) {
        int v = q.front();
        q.pop();
        for (int u : rg[v]) {
            if (d[u] == -1) {
                d[u] = d[v] + 1;
                q.push(u);
            }
        }
    }

    for (int i = 0; i < n; ++i) {
        if (i) std::cout << " ";
        std::cout << d[i];
    }
    std::cout << std::endl;

    return 0;
}