#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int>> graph(n + 1);
    std::vector<int> in_degree(n + 1, 0);

    for (int i = 0; i < m; ++i) {
        int from, to;
        std::cin >> from >> to;
        graph[from].push_back(to);
        in_degree[to]++;
    }

    std::queue<int> q;
    for (int i = 1; i <= n; ++i) {
        if (in_degree[i] == 0) {
            q.push(i);
        }
    }

    std::vector<int> dp(n + 1, 0);
    int max_path = 0;

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        for (int v : graph[u]) {
            if (dp[v] < dp[u] + 1) {
                dp[v] = dp[u] + 1;
                max_path = std::max(max_path, dp[v]);
            }
            if (--in_degree[v] == 0) {
                q.push(v);
            }
        }
    }

    std::cout << max_path << std::endl;

}