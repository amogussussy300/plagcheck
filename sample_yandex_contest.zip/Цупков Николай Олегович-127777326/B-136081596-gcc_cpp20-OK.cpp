﻿#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

class BFS {
private:
    std::vector<std::vector<int>> g;
    std::vector<int> d;
    std::vector<int> p;
    int n;

public:
    BFS(const std::vector<std::vector<int>>& gr, int size) : g(gr), n(size), d(size), p(size) {}

    void run(int s) {
        std::queue<int> q;
        q.push(s);
        std::vector<bool> u(n, false);
        u[s] = true;
        p[s] = -1;

        while (!q.empty()) {
            int v = q.front();
            q.pop();
            for (int t : g[v]) {
                if (t < n && !u[t]) {
                    u[t] = true;
                    q.push(t);
                    d[t] = d[v] + 1;
                    p[t] = v;
                }
            }
        }
    }

    int get_md() const {
        return *std::max_element(d.begin(), d.end());
    }

    std::vector<int> get_fn() const {
        int md = get_md();
        std::vector<int> r;
        for (int i = 1; i < n; ++i) {
            if (d[i] == md) {
                r.push_back(i);
            }
        }
        return r;
    }
};

int main() {
    int n;
    std::cin >> n;

    std::vector<std::vector<int>> g(n + 1);
    for (int i = 2; i <= n; ++i) {
        int pr;
        std::cin >> pr;
        g[pr].push_back(i);
    }

    BFS bfs(g, n + 1);
    bfs.run(1);

    int md = bfs.get_md();
    std::vector<int> fn = bfs.get_fn();

    std::cout << md << std::endl;
    std::cout << fn.size() << std::endl;
    for (size_t i = 0; i < fn.size(); ++i) {
        if (i != 0) std::cout << " ";
        std::cout << fn[i];
    }
    std::cout << std::endl;

}