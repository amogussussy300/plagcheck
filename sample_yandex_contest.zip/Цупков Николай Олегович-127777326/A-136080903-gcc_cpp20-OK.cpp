﻿#include <iostream>
#include <vector>
#include <queue>

bool f(int n, int m, const std::vector<std::pair<int, int>>& e) {
    if (m != n - 1) return false;

    std::vector<std::vector<int>> g(n + 1);
    for (const auto& p : e) {
        g[p.first].push_back(p.second);
        g[p.second].push_back(p.first);
    }

    std::vector<bool> v(n + 1);
    std::queue<int> q;
    q.push(1);
    v[1] = true;
    int c = 1;

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int x : g[u]) {
            if (!v[x]) {
                v[x] = true;
                c++;
                q.push(x);
            }
        }
    }

    return c == n;
}

int main() {
    int n, m;
    std::cin >> n >> m;

    std::vector<std::pair<int, int>> e(m);
    for (int i = 0; i < m; ++i) {
        std::cin >> e[i].first >> e[i].second;
    }

    std::cout << (f(n, m, e) ? "YES" : "NO") << std::endl;

}