#include <iostream>
#include <vector>
#include <queue>

using namespace std;

bool fn(int n, int m, const vector<vector<int>>& s) {
    if (m != n - 1)
        return false;
    vector<bool> vis(n + 1, false);
    queue<int> q;
    q.push(1);
    vis[1] = true;
    int cn = 1;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : s[u]) {
            if (!vis[v]) {
                vis[v] = true;
                cn++;
                q.push(v);
            }
        }
    }
    if (cn == n)
        return true;
    return false;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> s(n + 1);
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        s[u].push_back(v);
        s[v].push_back(u);
    }
    if (fn(n, m, s)) 
        cout << "YES" << endl;
    else 
        cout << "NO" << endl;
    return 0;
}