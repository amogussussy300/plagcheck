#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<vector<int>> child(n + 1);
    vector<int> parent(n + 1);
    for (int v = 2; v <= n; ++v) {
        cin >> parent[v];
        child[parent[v]].push_back(v);
    }
    vector<int> dist(n + 1, -1);
    queue<int> q;
    q.push(1);
    dist[1] = 0;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : child[u])
            if (dist[v] == -1) {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
    }
    int mdist = *max_element(dist.begin() + 1, dist.end());
    vector<int> sss;
    for (int v = 1; v <= n; ++v) 
        if (dist[v] == mdist) 
            sss.push_back(v);
    cout << mdist << endl;
    cout << sss.size() << endl;
    for (int v : sss)
        cout << v << " ";
    cout << endl;
    return 0;
}