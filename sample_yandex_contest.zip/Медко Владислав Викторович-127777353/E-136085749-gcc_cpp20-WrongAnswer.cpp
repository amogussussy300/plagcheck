#include <iostream>
#include <vector>
using namespace std;

void fn(int v, vector<vector<int>>& graph, vector<int>& cl, int fl, bool& fc) {
    cl[v] = fl;
    for (int u : graph[v]) {
        if (!fc)
            return;
        if (cl[u] == 0)
            fn(u, graph, cl, 3 - fl, fc);
        else if (cl[u] == cl[v]) {
            fc = false;
            return;
        }
    }
}

int main() {
    int N, M;
    cin >> N >> M;
    vector<vector<int>> graph(N);
    vector<int> cl(N, 0);
    bool fc = true;
    for (int k = 0; k < M; ++k) {
        int i, j;
        cin >> i >> j;
        graph[i - 1].push_back(j - 1);
        graph[j - 1].push_back(i - 1);
        if (!fc)
            break;
        if (cl[k] == 0)
            fn(k, graph, cl, 1, fc);
        if (fc)
            cout << 1;
        else
            cout << 0;
    }
    return 0;
}