#include <iostream>
#include <vector>
using namespace std;

void fn(int v, vector<vector<int>>& graph, vector<int>& cl, int fl, bool& fc) {
    cl[v] = fl;
    for (int u : graph[v]) {
        if (!fc) return;
        if (cl[u] == 0) {
            fn(u, graph, cl, 3 - fl, fc);
        }
        else if (cl[u] == fl) {
            fc = false;
            return;
        }
    }
}

int main() {
    int N, M;
    cin >> N >> M;
    vector<vector<int>> graph(N);
    for (int k = 0; k < M; ++k) {
        int i, j;
        cin >> i >> j;
        i--; j--;
        graph[i].push_back(j);
        graph[j].push_back(i);
        vector<int> cl(N, 0);
        bool fc = true;
        for (int v = 0; v < N; ++v) {
            if (cl[v] == 0) {
                fn(v, graph, cl, 1, fc);
                if (!fc) break;
            }
        }
        if (fc)
            cout << 1;
        else
            cout << 0;
    }
    return 0;
}