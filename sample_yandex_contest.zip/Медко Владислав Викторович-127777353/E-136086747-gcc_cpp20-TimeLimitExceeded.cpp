#include <iostream>
#include <vector>
#include <queue>
using namespace std;

bool fn(const vector<vector<int>>& graph) {
    int n = graph.size();
    vector<int> color(n, -1);
    queue<int> q;
    for (int i = 0; i < n; ++i) {
        if (color[i] == -1) {
            color[i] = 0;
            q.push(i);
            while (!q.empty()) {
                int v = q.front();
                q.pop();
                for (int u : graph[v]) {
                    if (color[u] == -1) {
                        color[u] = 1 - color[v];
                        q.push(u);
                    }
                    else if (color[u] == color[v])
                        return false;
                }
            }
        }
    }
    return true;
}

int main() {
    int N, M;
    cin >> N >> M;
    vector<vector<int>> graph(N);
    for (int k = 0; k < M; ++k) {
        int i, j;
        cin >> i >> j;
        --i; --j;
        graph[i].push_back(j);
        graph[j].push_back(i);
        if (fn(graph))
            cout << 1;
        else
            cout << 0;
    }
    return 0;
}