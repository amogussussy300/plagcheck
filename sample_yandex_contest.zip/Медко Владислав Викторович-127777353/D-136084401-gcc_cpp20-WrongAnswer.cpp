#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

void fn(vector<vector<int>>& s, vector<int>& ss, int n) {
    queue<int> q;
    for (int u = 1; u <= n; ++u)
        if (ss[u] == 0)
            q.push(u);
    vector<int> tp;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        tp.push_back(u);
        for (int v : s[u])
            if (ss[v] == 1)
                q.push(v);
    }
    vector<int> dp(n + 1, 0);
    int ml = 0;
    for (int u : tp) 
        for (int v : s[u]) 
            if (dp[v] < dp[u] + 1) {
                dp[v] = dp[u] + 1;
                ml = max(ml, dp[v]);
            }
    cout << ml << endl;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> s(n + 1);
    vector<int> ss(n + 1, 0);
    for (int i = 0; i < m; ++i) {
        int b, e;
        cin >> b >> e;
        s[b].push_back(e);
        ss[e]++;
    }
    fn(s, ss, n);
    return 0;
}