#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

void fn(const vector<vector<int>>& graph, int start) {
    int n = graph.size();
    vector<int> dist(n, INT_MAX);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    dist[start] = 0;
    pq.push({ 0, start });
    while (!pq.empty()) {
        int u = pq.top().second;
        int current_dist = pq.top().first;
        pq.pop();
        if (current_dist > dist[u]) 
            continue;
        for (auto& edge : graph[u]) {
            int v = edge;

            if (dist[v] > dist[u] + 1) {
                dist[v] = dist[u] + 1;
                pq.push({ dist[v], v });
            }
        }
    }
    for (int i = 0; i < n; ++i) {
        if (dist[i] != INT_MAX)
            cout << dist[i] << ' ';
        else
            cout << -1 << ' ';
    }
}

int main() {
    int n, s, m;
    cin >> n >> s >> m;
    vector<vector<int>> graph(n);
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> b >> a;
        graph[a - 1].push_back(b - 1);
    }
    fn(graph, s - 1);
    return 0;
}