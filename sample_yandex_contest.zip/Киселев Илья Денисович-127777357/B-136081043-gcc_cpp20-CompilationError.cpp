#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> parent(n+1);
    vector<int> depth(n+1, 0);
    
    for (int i = 2; i <= n; ++i) {
        cin >> parent[i];
        depth[i] = depth[parent[i]] + 1;
    }
    
    int max_depth = *max_element(depth.begin(), depth.end());
    int max_depth = maxi(depth);
    vector<int> result;
    
    for (int i = 1; i <= n; ++i) {
        if (depth[i] == max_depth) {
            result.push_back(i);
        }
    }
    
    sort(result.begin(), result.end());
    
    cout << max_depth << endl;
    cout << result.size() << endl;
    for (int v : result) {
        cout << v << " ";
    }
    
    return 0;
}