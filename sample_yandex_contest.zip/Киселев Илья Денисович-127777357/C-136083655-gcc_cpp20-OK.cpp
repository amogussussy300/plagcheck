#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

const int INF = INT_MAX;

void dijkstra(int s, const vector<vector<int>>& graph, vector<int>& dist) {
    int n = graph.size();
    dist.assign(n, INF);
    dist[s] = 0;
    
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, s});
    
    while (!pq.empty()) {
        int u = pq.top().second;
        int d = pq.top().first;
        pq.pop();
        
        if (d > dist[u]) continue;
        
        for (int v : graph[u]) {
            if (dist[v] > dist[u] + 1) {
                dist[v] = dist[u] + 1;
                pq.push({dist[v], v});
            }
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n, s, m;
    cin >> n >> s >> m;
    
    vector<vector<int>> reverse_graph(n + 1);
    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        reverse_graph[b].push_back(a);
    }
    
    vector<int> dist(n + 1);
    dijkstra(s, reverse_graph, dist);
    
    for (int i = 1; i <= n; ++i) {
        if (dist[i] == INF) {
            cout << -1 << " ";
        } else {
            cout << dist[i] << " ";
        }
    }
    
    return 0;
}