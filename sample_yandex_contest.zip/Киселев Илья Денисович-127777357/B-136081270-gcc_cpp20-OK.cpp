#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;



int main() {
    int n;
    cin >> n;
    vector<vector<int>> g(n+1);
    
    for (int i = 2; i <= n; ++i) {
        int p;
        cin >> p;
        g[p].push_back(i);
    }
    
    queue<int> q;
    vector<int> dist(n+1, -1);
    q.push(1);
    dist[1] = 0;
    
    while (!q.empty()) {
        int v = q.front();
        q.pop();
        
        for (int to : g[v]) {
            if (dist[to] == -1) {
                dist[to] = dist[v] + 1;
                q.push(to);
            }
        }
    }
    
    int max_dist = *max_element(dist.begin(), dist.end());
    vector<int> result;
    
    for (int i = 1; i <= n; ++i) {
        if (dist[i] == max_dist) {
            result.push_back(i);
        }
    }
    
    sort(result.begin(), result.end());
    
    cout << max_dist << endl;
    cout << result.size() << endl;
    for (int v : result) {
        cout << v << " ";
    }
    
    return 0;
}