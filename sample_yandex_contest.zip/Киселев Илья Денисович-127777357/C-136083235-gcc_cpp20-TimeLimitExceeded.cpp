#include <iostream>
#include <vector>
#include <set>
#include <algorithm>

using namespace std;

const int INF = -1e9;

void dijkstra(int s, const vector<vector<pair<int, int>>>& g, vector<int>& d) {
    int n = g.size();
    d.assign(n, INF);
    d[s] = 0;
    set<pair<int, int>> q;
    q.insert({0, s});

    while (!q.empty()) {
        int v = q.begin()->second;
        q.erase(q.begin());

        for (auto edge : g[v]) {
            int to = edge.first;
            int len = edge.second;

            if (d[v] + len > d[to]) {
                q.erase({d[to], to});
                d[to] = d[v] + len;
                q.insert({d[to], to});
            }
        }
    }
}

int main() {
    int n, s, m;
    cin >> n >> s>> m;
    vector<vector<pair<int, int>>> g(n+1);

    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        g[a].push_back({b, 1});
    }

    vector<int> d(n+1);
    dijkstra(s, g, d);
    int res = 0;
    for (int i = n; i >=1; --i) {
        if(d[i]==INF){
            cout<<-1<<' ';
        }
        else {
            cout<<d[i]<<' ';
        }
    }
    
    return 0;
}