#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<vector<int>> g;
vector<int> used;
vector<int> p;
bool cycle = false;

void dfs(int v) {
    used[v] = 1;
    for (auto to : g[v]) {
        if (used[to] == 0) {
            p[to] = v;
            dfs(to);
        } else if (used[to] == 1 && to != p[v]) {
            cycle = true;
        }
    }
    used[v] = 2;
}

bool isConnected(int n) {
    used.assign(n + 1, 0);
    dfs(1);
    for (int i = 1; i <= n; ++i) {
        if (!used[i]) return false;
    }
    return true;
}

int main() {
    int n, m;
    cin >> n >> m;
    
    if (m != n - 1) {
        cout << "NO";
        return 0;
    }

    g.resize(n + 1);
    used.resize(n + 1);
    p.resize(n + 1);

    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }

    cycle = false;
    used.assign(n + 1, 0);
    p.assign(n + 1, -1);
    for (int i = 1; i <= n; ++i) {
        if (!used[i]) {
            dfs(i);
        }
    }

    if (cycle || !isConnected(n)) {
        cout << "NO";
    } else {
        cout << "YES";
    }

    return 0;
}