#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;

    vector<int> arr(n + 1, 0);
    vector<vector<int>> graph(n + 1);
    std::vector<int> queue;

    for (size_t i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        graph[a].push_back(b);
        arr[b]++;
    }

    for (size_t i = 0; i <= n; ++i) {
        if(i == 0) continue;
        if (arr[i] == 0) {
            queue.push_back(i);
        }
    }

    vector<int> arr2;
    while (!queue.empty()) {
        int node = queue.front();
        queue.pop_back();
        arr2.push_back(node);

        for (int i : graph[node]) {
            arr[i]--;
            if (arr[i] == 0) {
                queue.push_back(i);
            }
        }
    }

    vector<int> res(n + 1, 0);
    for (int node : arr2) {
        for (auto i : graph[node]) {
            res[i] = max(res[i], res[node] + 1);
        }
    }

    int rs = 0;
    for (int i = 1; i <= n; ++i) {
        rs = max(rs, res[i]);
    }
    cout << rs << endl;

    return 0;
}