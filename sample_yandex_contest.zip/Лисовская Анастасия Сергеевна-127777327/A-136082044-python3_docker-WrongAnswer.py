def isTree(n, m, e):
    if(m != n - 1):
        return False

    graph = {i: [] for i in range(1, n+1)}

    for u, v in e:
        graph[u].append[v]
        graph[v].append[u]
        
    
    used = [False]* n

    def dfs(v, p):
        used[v] = True
        for to in graph[v]:
            if(not used[to]):
                if not dfs(to, v):
                    return False
            elif to != p:
                return False
        return True
            
    if not dfs(1, -1):
        return False
    
    print(*used)
    
    for i in range(1, n+1):
        if not used[i]:
            return False
    return True
    


n, m = list(map(int, input().split()))

l = []
a = [tuple(map(int, input().split())) for i in range(m)]

if(isTree(n, m, l)):
    print('YES')
else:
    print('NO')

