def sol(n, m, e):
    if m != n - 1: 
        return False

    graph = {i: [] for i in range(1, n + 1)} 
    for u, v in edges:
        graph[u].append(v)
        graph[v].append(u)

    used = [False] * (n + 1) 

    def dfs(v, parent):
        used[v] = True
        for neighbor in graph[v]:
            if not used[neighbor]:
                if not dfs(neighbor, v): 
                    return False
            elif neighbor != parent: 
                return False
        return True
 
    if not dfs(1, -1):
        return False

    for i in range(1, n + 1):
        if not used[i]:
            return False

    return True

n, m = map(int, input().split())
edges = [tuple(map(int, input().split())) for _ in range(m)]

if sol(n, m, edges):
    print("YES")
else:
    print("NO")
