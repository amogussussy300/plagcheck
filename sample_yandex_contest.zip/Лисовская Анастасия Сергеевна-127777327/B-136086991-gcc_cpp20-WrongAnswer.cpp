#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <algorithm>

using namespace std;

vector<int> sol(int n, const vector<int>& parents) {
    vector<vector<int>> tree(n + 1);
    int root = 1;

    for (int i = 2; i <= n; ++i) {
        tree[parents[i - 2]].push_back(i);
    }
    vector<int> height(n + 1, -1);
    height[root] = 0;
    queue<int> q;
    q.push(root);
    unordered_map<int, int> h2;

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        for (int child : tree[node]) {
            height[child] = height[node] + 1;
            q.push(child);
        }
    }

    for (int i = 1; i <= n; ++i) {
        h2[height[i]]++;
    }
    int mxh = 0;
    for (const auto& [level, count] : h2) {
        if (level > mxh) {
            mxh = level;
        }
    }
    vector<int> f;
    for (int i = 1; i <= n; ++i) {
        if (height[i] == mxh) {
            f.push_back(i);
        }
    }
    vector<int> res;
    for (const auto& [level, count] : h2) {
        res.push_back(count);
    }
    sort(res.rbegin(), res.rend());
    for(size_t i = 0; i < res.size(); ++i)
        std::cout << res[i] << std::endl;

    return f;
}

int main() {
    int n;
    cin >> n;

    vector<int> temp(n - 1);
    for (int i = 0; i < n - 1; ++i) {
        cin >> temp[i];
    }
    vector<int> f = sol(n, temp);
    
    for (int n : f) {
        cout << n << " ";
    }
    cout << endl;

    return 0;
}
