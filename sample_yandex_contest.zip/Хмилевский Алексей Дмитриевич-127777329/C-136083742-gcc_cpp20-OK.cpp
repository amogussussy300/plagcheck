#include <iostream>
#include <vector>
#include <deque>

std::vector<int> find_min_costs(int n, int s, int m, const std::vector<std::pair<int, int>>& roads) {
    std::vector<std::vector<int>> graph(n + 1);
    for (const auto& road : roads) {
        graph[road.second].push_back(road.first);
    }
    
    std::vector<int> dist(n + 1, -1);
    dist[s] = 0;
    
    std::vector<bool> visited(n + 1, false);
    visited[s] = true;
    
    std::deque<int> queue;
    queue.push_back(s);
    
    while (!queue.empty()) {
        int curr = queue.front();
        queue.pop_front();
        for (int next_city : graph[curr]) {
            if (!visited[next_city]) {
                visited[next_city] = true;
                dist[next_city] = dist[curr] + 1;
                queue.push_back(next_city);
            }
        }
    }
    
    std::vector<int> result(n);
    for (int i = 1; i <= n; ++i) {
        result[i - 1] = dist[i];
    }
    return result;
}

int main() {
    int n, s, m;
    std::cin >> n >> s >> m;
    
    std::vector<std::pair<int, int>> roads(m);
    for (int i = 0; i < m; ++i) {
        std::cin >> roads[i].first >> roads[i].second;
    }
    
    std::vector<int> result = find_min_costs(n, s, m, roads);
    for (int i = 0; i < n; ++i) {
        std::cout << result[i];
        if (i < n - 1) std::cout << " ";
    }
    std::cout << std::endl;
    
    return 0;
}