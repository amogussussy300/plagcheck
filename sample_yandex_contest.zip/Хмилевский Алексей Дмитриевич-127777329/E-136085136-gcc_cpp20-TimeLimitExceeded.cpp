#include <iostream>
#include <vector>
#include <queue>

bool is_bipartite(int n, const std::vector<std::pair<int, int>>& edges, int m) {
    std::vector<std::vector<int>> graph(n + 1);
    for (int i = 0; i < m; ++i) {
        graph[edges[i].first].push_back(edges[i].second);
        graph[edges[i].second].push_back(edges[i].first);
    }
    
    std::vector<int> colors(n + 1, -1);
    std::queue<int> q;
    
    for (int start = 1; start <= n; ++start) {
        if (colors[start] == -1) {
            colors[start] = 0;
            q.push(start);
            
            while (!q.empty()) {
                int u = q.front();
                q.pop();
                for (int v : graph[u]) {
                    if (colors[v] == -1) {
                        colors[v] = 1 - colors[u];
                        q.push(v);
                    } else if (colors[v] == colors[u]) {
                        return false;
                    }
                }
            }
        }
    }
    return true;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::pair<int, int>> edges(m);
    for (int i = 0; i < m; ++i) {
        std::cin >> edges[i].first >> edges[i].second;
    }
    
    for (int i = 0; i < m; ++i) {
        std::cout << (is_bipartite(n, edges, i + 1) ? 1 : 0);
    }
    std::cout << std::endl;
    
    return 0;
}