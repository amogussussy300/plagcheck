#include <iostream>
#include <vector>
#include <queue>

int longest_path(int n, int m, const std::vector<std::pair<int, int>>& edges) {
    std::vector<std::vector<int>> graph(n + 1);
    std::vector<int> in_degree(n + 1, 0);
    for (const auto& edge : edges) {
        graph[edge.first].push_back(edge.second);
        in_degree[edge.second]++;
    }
    
    std::vector<int> dp(n + 1, 0);
    std::queue<int> q;
    for (int i = 1; i <= n; ++i) {
        if (in_degree[i] == 0) {
            q.push(i);
        }
    }
    
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : graph[u]) {
            dp[v] = std::max(dp[v], dp[u] + 1);
            if (--in_degree[v] == 0) {
                q.push(v);
            }
        }
    }
    
    int max_path = 0;
    for (int i = 1; i <= n; ++i) {
        max_path = std::max(max_path, dp[i]);
    }
    return max_path;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::pair<int, int>> edges(m);
    for (int i = 0; i < m; ++i) {
        std::cin >> edges[i].first >> edges[i].second;
    }
    std::cout << longest_path(n, m, edges) << std::endl;
    return 0;
}