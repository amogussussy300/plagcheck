#include <iostream>
#include <vector>

struct UnionFind {
    std::vector<int> parent, rank, color;
    
    UnionFind(int n) : parent(n + 1), rank(n + 1, 0), color(n + 1, -1) {
        for (int i = 1; i <= n; ++i) parent[i] = i;
    }
    
    int find(int u) {
        if (parent[u] != u) {
            int root = find(parent[u]);
            color[u] ^= color[parent[u]];
            parent[u] = root;
        }
        return parent[u];
    }
    
    bool unite(int u, int v) {
        int pu = find(u), pv = find(v);
        if (pu == pv) {
            return (color[u] ^ color[v]) == 1;
        }
        if (rank[pu] < rank[pv]) {
            parent[pu] = pv;
            color[pu] = color[u] ^ color[v] ^ 1;
        } else {
            parent[pv] = pu;
            color[pv] = color[u] ^ color[v] ^ 1;
            if (rank[pu] == rank[pv]) ++rank[pu];
        }
        return true;
    }
};

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::pair<int, int>> edges(m);
    for (int i = 0; i < m; ++i) {
        std::cin >> edges[i].first >> edges[i].second;
    }
    
    UnionFind uf(n);
    for (int i = 0; i < m; ++i) {
        int u = edges[i].first, v = edges[i].second;
        std::cout << (uf.unite(u, v) ? 1 : 0);
    }
    std::cout << std::endl;
    
    return 0;
}