#include <iostream>
#include <vector>
#include <queue>

std::vector<int> fmin(int n, int s, const std::vector<std::pair<int, int>>& r) {
    std::vector<std::vector<int>> g(n + 1);
    
    for (const auto& edge : r) {
        g[edge.second].push_back(edge.first);
    }

    std::vector<int> pr(n + 1, -1);
    pr[s] = 0;

    std::queue<int> q;
    q.push(s);
    while (!q.empty()) {
        int curr = q.front();
        q.pop();
        for (int neigh : g[curr]) {
            if (pr[neigh] == -1) {
                pr[neigh] = pr[curr] + 1;
                q.push(neigh);
            }
        }
    }
    return std::vector<int>(pr.begin() + 1, pr.end());
}

int main() {
    int n = 0;
    int s = 0;
    int m = 0;
    std::cin >> n >> s >> m;
    std::vector<std::pair<int, int>> r(m);
    for (int j = 0; j < m; ++j) {
        std::cin >> r[j].first >> r[j].second;
    }

    std::vector<int> res = fmin(n, s, r);
    for (int val : res) {
        std::cout << val << " ";
    }
    std::cout << std::endl;

    return 0;
}