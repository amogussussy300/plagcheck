#include <iostream>
#include <vector>
#include <string>
#include <sstream>

// на питоне не заходило :(
std::string isbi(const std::vector<std::vector<int>>& g, int n) {
    std::vector<int> col(n + 1, -1);
    for (int s = 0; s < n; s++) {
        if (col[s] == -1) {
            std::vector<int> dq;
            dq.push_back(s);
            col[s] = 0;
            while (!dq.empty()) {
                int node = dq.back();
                dq.pop_back();
                for (int neigh : g[node]) {
                    if (col[neigh] == col[node]) {
                        return "0";
                    } else if (col[neigh] == -1) {
                        col[neigh] = 1 - col[node];
                        dq.push_back(neigh);
                    }
                }
            }
        }
    }
    return "1";
}

int main() {
    int n = 0;
    int m = 0;
    std::cin >> n >> m;
    std::vector<std::vector<int>> e(m, std::vector<int>(2));
    for (int j = 0; j < m; j++) {
        std::cin >> e[j][0] >> e[j][1];
    }

    std::vector<std::vector<int>> g(n + 1);
    std::string res = "";
    for (int j = 0; j < m; j++) {
        int x = e[j][0], y = e[j][1];
        g[x].push_back(y);
        g[y].push_back(x);
        res += isbi(g, n);
    }

    std::cout << res;

    return 0;
}

// видит мужик другой сидит с бананами в ушах:
// - мужик ты че почему у тебя в ушах бананы?
// - ААААААААА Я НИЧЕ НЕ СЛЫШУ У МЕНЯ БАНАНЫ В УШАХ