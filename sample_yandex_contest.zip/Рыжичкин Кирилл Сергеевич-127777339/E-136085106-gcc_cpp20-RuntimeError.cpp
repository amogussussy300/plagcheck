#include <iostream>
#include <vector>
#include <queue>
#include <string>

std::string isbi(std::vector<std::vector<int>>& g, int n) {
    std::vector<int> col(n + 1, -1);
    for (int s = 1; s <= n; s++) {
        if (col[s - 1] == -1) {
            std::queue<int> q;
            q.push(s - 1);
            col[s - 1] = 0;
            while (!q.empty()) {
                int node = q.front();
                q.pop();
                for (int neigh : g[node]) {
                    if (col[neigh] == col[node]) {
                        return "0";
                    } else if (col[neigh] == -1) {
                        col[neigh] = 1 - col[node];
                        q.push(neigh);
                    }
                }
            }
        }
    }
    return "1";
}

int main() {
    int n = 0;
    int m = 0;
    std::cin >> n >> m;
    std::vector<std::vector<int>> e(m);
    for (int i = 0; i < m; i++) {
        std::cin >> e[i][0] >> e[i][1];
    }
    std::vector<std::vector<int>> g(n + 1);
    std::string res;
    for (int i = 0; i < m; i++) {
        g[e[i][0]].push_back(e[i][1]);
        g[e[i][1]].push_back(e[i][0]);
        res += isbi(g, n);
    }
    std::cout << res << std::endl;
    return 0;
}