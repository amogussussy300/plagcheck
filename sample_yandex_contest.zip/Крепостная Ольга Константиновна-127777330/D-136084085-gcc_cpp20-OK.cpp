#include <iostream>
#include <vector>
#include <queue>

int main() {
    int n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int>> g(n + 1);
    std::vector<int> idx(n + 1, 0);
    for (int i = 0; i < m; ++i) {
        int u, v;
        std::cin >> u >> v;
        g[u].push_back(v);
        idx[v]++;
    }
    std::queue<int> q;
    for (int i = 1; i <= n; ++i) {
        if (idx[i] == 0) {
            q.push(i);
        }
    }
    std::vector<int> way;
    while (!q.empty()) {
        int v = q.front();
        q.pop();
        way.push_back(v);

        for (int i : g[v]) {
            idx[i]--;
            if (idx[i] == 0) {
                q.push(i);
            }
        }
    }
    std::vector<int> arr(n + 1, 0);
    for (int v : way) {
        for (int i : g[v]) {
            arr[i] = std::max(arr[i], arr[v] + 1);
        }
    }
    int maxim = 0;
    for (int i = 1; i <= n; ++i) {
        maxim = std::max(maxim, arr[i]);
    }

    std::cout << maxim << std::endl;

}
