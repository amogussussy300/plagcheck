#include <iostream>
#include <vector>


bool Cycle(int v, const std::vector<std::vector<int>>& graph, std::vector<bool>& used, int parent, std::vector<int>& cycle) {
    used[v] = true;
    for (int to : graph[v]) {
        if (!used[to]) {
            if (Cycle(to, graph, used, v, cycle)) {
                if (cycle.empty() || cycle.front() != to) {
                    cycle.push_back(v);
                    return true;
                }
            }
        } else if (to != parent) {
            cycle.push_back(to);
            cycle.push_back(v);
            return true;
        }
    }
    return false;
}

bool Tree(const std::vector<std::vector<int>>& graph, int n) {
    if (n == 0) return true;

    std::vector<bool> used(n, false);
    std::vector<int> cycle;

    if (Cycle(0, graph, used, -1, cycle)) {
        return false;
    }

    for (bool v : used) {
        if (!v) return false;
    }

    return true;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    if (m != n - 1) {
        std::cout << "NO" << "\n";
        return 0;
    }
    std::vector<std::vector<int>> graph(n);
    for (int i = 0; i < m; ++i) {
        int u, v;
        std::cin >> u >> v;
        --u; --v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }
    if (Tree(graph, n))
        std::cout << "YES" <<"\n";
    else 
        std::cout << "NO" << "\n";
    
}