#include <iostream>
#include <vector>
#include <deque>
#include <string>


int main() {
    int n, s, m;
    std::cin >> n >> s >> m;
    std::vector<std::vector<int>> g(n + 1);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        g[b].push_back(a);
    }
    std::vector<int> help(n + 1, -1);
    help[s] = 0;
    std::deque<int> q;
    q.push_back(s);
    while (!q.empty()) {
        int v = q.front();
        q.pop_front();

        for (int i : g[v]) {
            if (help[i] == -1) {
                help[i] = help[v] + 1;
                q.push_back(i);
            }
        }
    }
    for (int i = 1; i <= n; ++i) {
        std::cout << help[i] << (i < n ? " " : "");
    }
}