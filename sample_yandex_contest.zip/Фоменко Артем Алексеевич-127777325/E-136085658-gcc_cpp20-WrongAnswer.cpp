#include <iostream>
#include <vector>
#include <string>

struct DSU {
    std::vector<int> parent, rank, color;
    std::vector<bool> bip;

    DSU(int n) {
        parent.resize(n + 1);
        rank.resize(n + 1, 0);
        color.resize(n + 1, 0);
        bip.resize(n + 1, true);
        for (int i = 1; i <= n; i++)
            parent[i] = i;
    }

    std::pair<int, int> find(int a) {
        if (parent[a] == a)
            return { a, 0 };
        auto pr = find(parent[a]);

        color[a] = pr.second;
        parent[a] = pr.first;
        return { parent[a], color[a] };
    }

    bool unionset(int a, int b) {
        auto pa = find(a);
        auto pb = find(b);
        int ra = pa.first, rb = pb.first;
        int ca = pa.second, cb = pb.second;

        if (ra == rb) {
            if (ca == cb)
                bip[ra] = false;
            return bip[ra];
        }

        if (rank[ra] < rank[rb]) {
            parent[ra] = rb;
            color[ra] = ca ^ cb ^ 1;
            bip[rb] = bip[ra] && bip[rb];
            return bip[rb];
        }
        else {
            parent[rb] = ra;
            color[rb] = ca ^ cb ^ 1;
            bip[ra] = bip[ra] && bip[rb];
            if (rank[ra] == rank[rb])
                rank[ra]++;
            return bip[ra];
        }
    }
};

int main() {
    int n, m;
    std::cin >> n >> m;
    DSU dsu(n);
    std::string result;
    bool globbip = true;

    for (int i = 0; i < m; i++) {
        int u, v;
        std::cin >> u >> v;
        bool compbip = dsu.unionset(u, v);
        if (!compbip)
            globbip = false;
        result.push_back(globbip ? '1' : '0');
    }
    std::cout << result;
}

