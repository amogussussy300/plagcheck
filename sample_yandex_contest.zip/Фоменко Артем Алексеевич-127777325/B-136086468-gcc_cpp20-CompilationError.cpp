n = int(input())
depth = [0] * (n + 1)
depth[1] = 0

for i in range(2, n + 1):
    parent = int(input())
    depth[i] = depth[parent] + 1

if not depth:
    exit(0)

maxd = max(depth)

farthn = [i for i in range(1, n + 1) if depth[i] == maxd]
farthn.sort()

print(maxd)
print(len(farthn))
print(*farthn)