#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n+1);
    std::vector<int> indeg(n + 1, 0);

    for (int i = 0; i < m; i++) {
        int u, v;
        std::cin >> u >> v;
        graph[u].push_back(v);
        indeg[v]++;
    }

    std::queue<int> q;
    for (int i = 1; i <= n; i++) {
        if (indeg[i] == 0)
            q.push(i);
    }

    std::vector<int> topo;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        topo.push_back(u);
        for (int v : graph[u]) {
            indeg[v]--;
            if (indeg[v] == 0)
                q.push(v);
        }
    }

    std::vector<int> dp(n + 1, 0);
    for (int u : topo) {
        for (int v : graph[u]) {
            dp[v] = std::max(dp[v], dp[u] + 1);
        }
    }

    int ans = 0;
    for (int i = 1; i <= n; i++) {
        ans = std::max(ans, dp[i]);
    }

    std::cout << ans << "\n";
}