#include <iostream>
#include <vector>
#include <queue>

int main() {
    int n, s, m;
    std::cin >> n >> s >> m;

    std::vector<std::vector<int>> rev(n + 1);
    for (int i = 0; i < m; i++) {
        int a, b;
        std::cin >> a >> b;
        rev[b].push_back(a);
    }

    std::vector<int> dist(n + 1, -1);
    std::queue<int> q;
    dist[s] = 0;
    q.push(s);

    while (!q.empty()) {
        int cur = q.front();
        q.pop();
        for (int next : rev[cur]) {
            if (dist[next] == -1) {
                dist[next] = dist[cur] + 1;
                q.push(next);
            }
        }
    }

    for (int i = 1; i <= n; i++) {
        std::cout << dist[i] << " ";
    }
}