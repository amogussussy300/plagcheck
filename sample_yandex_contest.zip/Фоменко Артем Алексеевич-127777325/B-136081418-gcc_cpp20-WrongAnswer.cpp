#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int n;
    std::cin >> n;
    std::vector<int> depth(n + 1, 0);
    depth[1] = 0;

    for (int i = 2; i <= n; i++) {
        int parent;
        std::cin >> parent;
        depth[i] = depth[parent] + 1;
    }

    int maxd = 0;
    for (int i = 1; i <= n; i++) {
        maxd = std::max(maxd, depth[i]);
    }

    std::vector<int> farthn;
    for (int i = 1; i <= n; i++) {
        if (depth[i] == maxd)
            farthn.push_back(i);
    }

    std::sort(farthn.begin(), farthn.end());

    std::cout << maxd << "\n";
    std::cout << farthn.size() << "\n";
    for (int node : farthn)
        std::cout << node << " ";
}