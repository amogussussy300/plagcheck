#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>


int main() {
    int n;
    std::cin >> n;
    std::vector<int> depth(n + 1, -1);
    depth[1] = 0;

    std::vector<std::vector<int>> children(n + 1);
    std::vector<int> parents(n + 1, 0);

    for (int i = 2; i <= n; i++) {
        int parent;
        std::cin >> parent;
        parents[i] = parent;
        children[parent].push_back(i);
    }

    std::queue<int> q;
    q.push(1);
    depth[1] = 0;

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : children[u]) {
            if (depth[v] == -1) {
                depth[v] = depth[u] + 1;
                q.push(v);
            }
        }
    }

    int maxd = 0;
    for (int i = 1; i <= n; i++) {
        maxd = std::max(maxd, depth[i]);
    }

    std::vector<int> farthn;
    for (int i = 1; i <= n; i++) {
        if (depth[i] == maxd)
            farthn.push_back(i);
    }

    std::cout << maxd << "\n";
    std::cout << farthn.size() << "\n";
    for (int node : farthn)
        std::cout << node << " ";
}