#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

using vvi = std::vector<std::vector<int>>;

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int>> g(n);
    std::vector<int> ind(n, 0);

    for (int i = 0; i < m; i++) {
        int u, v;
        std::cin >> u >> v;

        u--;
        v--;

        g[u].push_back(v);
        ind[v]++;
    }

    std::queue<int> q;
    for (int i = 0; i < n; i++) {
        if (ind[i] == 0) {
            q.push(i);
        }
    }

    std::vector<int> dp(n, 0);
    while (!q.empty()) {
        int u = q.front();
        q.pop();

        for (int v : g[u]) {
            dp[v] = std::max(dp[v], dp[u] + 1);

            if (--ind[v] == 0) {
                q.push(v);
            }
        }
    }

    int answ = 0;
    for (auto value : dp) {
        answ = std::max(answ, value);
    }

    std::cout << answ;

    return 0;
}