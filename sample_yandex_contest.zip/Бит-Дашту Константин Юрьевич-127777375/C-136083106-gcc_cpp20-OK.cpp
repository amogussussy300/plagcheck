#include <iostream>
#include <vector>
#include <queue>
#include <limits>

using vvi = std::vector<std::vector<int>>;

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, s, m;
    std::cin >> n >> s >> m;

    --s;

    vvi g(n);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;

        --a;
        --b;

        g[b].push_back(a);
    }

    std::vector<int> dist(n, -1);
    std::queue<int> q;

    q.push(s);
    dist[s] = 0;

    while (!q.empty()) {
        int c = q.front();
        q.pop();

        for (int nei : g[c]) {
            if (dist[nei] == -1) {
                dist[nei] = dist[c] + 1;
                q.push(nei);
            }
        }
    }

    for (int i = 0; i < n; ++i) {
        std::cout << dist[i] << " ";
    }

    return 0;
}