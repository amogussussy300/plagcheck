#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>

using vvi = std::vector<std::vector<int>>;

int main() {
    int n;
    std::cin >> n;
    std::vector<int> d(n + 1, 0);

    for (int i = 2; i <= n; i++) {
        int p;
        std::cin >> p;
        d[i] = d[p] + 1;
    }

    int max_dist = 0;
    for (int i = 1; i <= n; i++) {
        if (d[i] > max_dist) {
            max_dist = d[i];
        }
    }

    std::vector<int> very_long_d;
    for (int i = 1; i <= n; i++) {
        if (d[i] == max_dist) {
            very_long_d.push_back(i);
        }
    }

    std::cout << max_dist << "\n" << very_long_d.size() << "\n";
    for (size_t i = 0; i < very_long_d.size(); i++) {
        std::cout << very_long_d[i] << " ";
    }

    return 0;
}