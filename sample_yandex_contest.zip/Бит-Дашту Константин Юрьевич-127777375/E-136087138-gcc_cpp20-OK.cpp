#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>

using vvi = std::vector<std::vector<int>>;

class DSet {
public:
    DSet(int n)
        : parent_(n),
        rank_(n, 0),
        color_(n, 0) {
        for (int i = 0; i < n; i++) {
            parent_[i] = i;
        }
    }

    int Get(int x1) {
        if (parent_[x1] != x1) {
            int t = Get(parent_[x1]);

            color_[x1] ^= color_[parent_[x1]];
            parent_[x1] = t;
        }

        return parent_[x1];
    }

    bool Merge(int x1, int y1) {
        int x2 = Get(x1);
        int y2 = Get(y1);

        if (x2 == y2) {
            if (color_[x1] == color_[y1])
                return false;

            return true;
        }

        if (rank_[x2] < rank_[y2]) {
            parent_[x2] = y2;
            color_[x2] = color_[x1] ^ color_[y1] ^ 1;
        } else {
            parent_[y2] = x2;
            color_[y2] = color_[x1] ^ color_[y1] ^ 1;

            if (rank_[x2] == rank_[y2]) {
                ++rank_[x2];
            }
        }

        return true;
    }

private:
    std::vector<int> parent_;
    std::vector<int> rank_;
    std::vector<int> color_;
};

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, m;
    std::cin >> n >> m;

    DSet st(n);

    std::string answ;

    answ.resize(m);

    bool two_sides_state = true;

    for (int i = 0; i < m; i++) {
        int u, v;
        std::cin >> u >> v;

        --u;
        --v;

        if (two_sides_state) {
            if (!st.Merge(u, v))
                two_sides_state = false;
        } else {
            st.Merge(u, v);
        }

        if (two_sides_state) {
            answ[i] = '1';
        } else {
            answ[i] = '0';
        }
    }

    std::cout << answ;

    return 0;
}