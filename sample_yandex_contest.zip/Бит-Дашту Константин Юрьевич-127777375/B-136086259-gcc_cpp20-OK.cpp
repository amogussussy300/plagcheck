#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>

using vvi = std::vector<std::vector<int>>;

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    
    int n;
    std::cin >> n;
    
    vvi childs(n + 1);
    
    for (int i = 2; i <= n; ++i) {
        int p;
        std::cin >> p;

        childs[p].push_back(i);
    }
    
    std::vector<int> d(n + 1, -1);
    
    d[1] = 0;
    
    std::queue<int> q;
    q.push(1);

    while (!q.empty()) {
        int u = q.front();
        q.pop();
    
        for (int v : childs[u]) {
            d[v] = d[u] + 1;
            q.push(v);
        }
    }
    
    int max_d = 0;
    
    for (int i = 1; i <= n; ++i) {
        if (d[i] > max_d) {
            max_d = d[i];
        }
    }
    
    std::vector<int> long_nodes;
    
    for (int i = 1; i <= n; ++i) {
        if (d[i] == max_d) {
            long_nodes.push_back(i);
        }
    }
    
    std::sort(long_nodes.begin(), long_nodes.end());
    
    std::cout << max_d << std::endl;
    std::cout << long_nodes.size() << std::endl;
    
    for (size_t j = 0; j < long_nodes.size(); ++j) {
        std::cout << long_nodes[j];

        if (j + 1 < long_nodes.size()) {
            std::cout << " ";
        }
    }

    return 0;
}