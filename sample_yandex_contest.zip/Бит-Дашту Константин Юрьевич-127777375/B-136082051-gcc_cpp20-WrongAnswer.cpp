#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>

using vvi = std::vector<std::vector<int>>;

int main() {
    int n;
    std::cin >> n;

    std::vector<int> p(n + 1);
    std::vector<int> d(n + 1, 0);

    for (size_t i = 2; i <= n; ++i) {
        std::cin >> p[i];
    }

    for (size_t i = 2; i <= n; ++i) {
        d[i] = d[p[i]] + 1;
    }

    auto max_d = *std::max_element(d.begin(), d.end());
    std::vector<int> nodes;

    for (size_t i = 1; i <= n; ++i) {
        if (d[i] == max_d) {
            nodes.push_back(i);
        }
    }

    std::cout << max_d << std::endl;
    std::cout << nodes.size() << std::endl;

    for (auto node : nodes) {
        std::cout << node << " ";
    }

    return 0;
}