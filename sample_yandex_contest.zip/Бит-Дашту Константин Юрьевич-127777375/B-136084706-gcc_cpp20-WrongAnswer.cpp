#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

using vvi = std::vector<std::vector<int>>;

int main() {
    int n;
    std::cin >> n;
    
    std::vector<int> p(n + 1);
    std::vector<int> d(n + 1, 0);
    
    d[1] = 0;
    
    for (int i = 2; i <= n; ++i) {
        std::cin >> p[i];
        d[i] = d[p[i]] + 1;
    }

    int max_d = *max_element(d.begin() + 1, d.end());

    std::vector<int> answ;

    for (int i = 1; i <= n; ++i) {
        if (d[i] == max_d) {
            answ.push_back(i);
        }
    }

    std::sort(answ.begin(), answ.end());
    
    std::cout << max_d << std::endl;
    std::cout << answ.size() << std::endl;
    
    for (size_t i = 0; i < answ.size(); ++i) {
        if (i != 0) {
            std::cout << " ";
        }

        std::cout << answ[i];
    }
    
    return 0;
}