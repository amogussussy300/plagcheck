#include <iostream>
#include <vector>
#include <queue>

using vvi = std::vector<std::vector<int>>;

bool IsTree(const vvi& g, int n, int m) {
    if (m != (n - 1))
        return false;

    std::vector<bool> visited(n + 1, false);
    std::queue<int> q;
    
    q.push(1);
    visited[1] = true;

    int visited_count = 0;

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        visited_count++;

        for (int nei : g[node]) {
            if (!visited[nei]) {
                visited[nei] = true;
                q.push(nei);
            }
        }
    }

    return visited_count == n;
}

int main() {
    int n, m;
    std::cin >> n >> m;

    vvi g(n + 1);

    for (int i = 0; i < m; ++i) {
        int u, v;
        std::cin >> u >> v;

        g[u].push_back(v);
        g[v].push_back(u);
    }

    if (IsTree(g, n, m)) {
        std::cout << "YES" << std::endl;
    } else {
        std::cout << "NO" << std::endl;
    }

    return 0;
}