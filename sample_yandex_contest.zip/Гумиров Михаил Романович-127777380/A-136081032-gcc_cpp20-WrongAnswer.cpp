#include <iostream>
#include <vector>

void dfs(int v, std::vector<bool>& used,  std::vector<std::vector<int>>& graph, std::vector<int>& parents, bool& cycle) {
    used[v] = true;
    for (auto& to : graph[v]) {
        if (!used[to]) {
            parents[to] = v;
            dfs(to, used, graph, parents, cycle);
        }
        else if (v == parents[v]) {
            cycle = true;
        }
    }
}

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n);
    int x, y;
    for (int i = 0; i < m; ++i) {
        std::cin >> x >> y;
        x--;
        y--;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }

    std::vector<bool> used(n, false);
    std::vector<int> parents(n);
    bool cycle = false;
    dfs(0, used, graph, parents, cycle);
    if (cycle) {
        std::cout << "NO";
    }
    else {
        std::cout << "YES";
    }
}
