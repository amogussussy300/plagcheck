#include <vector>
#include <queue>
#include <algorithm>

int main() {
    ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int n, s, m;
    std::cin >> n >> s >> m;
    s--;
    std::vector<std::vector<int>> graph(n);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        graph[b - 1].push_back(a - 1);
    }
    std::vector<int> distance(n, -1);
    distance[s] = 0;
    std::queue<int> queue;
    queue.push(s);
    while (!queue.empty()) {
        int v = queue.front();
        queue.pop();
        for (int x : graph[v]) {
            if (distance[x] == -1) {
                distance[x] = distance[v] + 1;
                queue.push(x);
            }
        }
    }
    for (auto& d : distance) {
        cout << d << ' ';
    }
}