#include <iostream>
#include <vector>
#include <queue>

int main() {
    int n, s, m;
    std::cin >> n >> s >> m;
    std::vector<std::vector<int>> graph(n);
    int x, y;
    for (int i = 0; i < m; ++i) {
        std::cin >> x >> y;
        graph[y-1].push_back(x-1);
    }
    std::priority_queue<std::pair<int, int>> queue;
    std::vector<int> distance(n, 1e9);
    std::vector<int> parents(n);
    distance[s-1] = 0;
    queue.push({0, s-1});
    while (!queue.empty()) {
        int v = queue.top().second;
        int cur_d = queue.top().first;
        queue.pop();
        if (cur_d > distance[v]) {
            continue;
        }
        for (int to : graph[v]) {
            if (cur_d + 1 < distance[to]) {
                distance[to] = cur_d + 1;
                queue.push({-distance[to], to});
            }
        }
    }
    for (auto& it : distance) {
        if (it == 1e9) {
            std::cout << -1 << " ";
        }
        else {
            std::cout << it << " ";
        }
    }
}