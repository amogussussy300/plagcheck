#include <iostream>
#include <vector>

void check_biparity(int v, std::vector<std::vector<int>>& graph, std::vector<int>& used, bool& isdvudol) {
    for(int to : graph[v]) {
        int metka_to = 3 - used[v];
        if (used[to] == 0) {
            used[to] = metka_to;
            check_biparity(to, graph, used, isdvudol);
        } else if (used[to] == used[v]) {
            isdvudol = false;
            return;
        }
    }
}

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n);
    bool isdvudol = true;
    int x, y;
    for (int i = 0; i < m; ++i) {
        std::cin >> x >> y;
        graph[x-1].push_back(y-1);
        graph[y-1].push_back(x-1);
        std::vector<int> used(n, 0);
        bool isdvudol = true;
        check_biparity(x-1, graph, used, isdvudol);
        if (isdvudol) {
            std::cout << 1;
        }
        else {
            std::cout << 0;
        }
    }
}