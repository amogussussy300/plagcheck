#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

void dfs(int u, std::vector<std::vector<int>>& graph, std::vector<bool>& used, std::stack<int>& stack) {
    used[u] = true;
    for (int v : graph[u]) {
        if (!used[v]) {
            dfs(v, graph, used, stack);
        }
    }
    stack.push(u);
}

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n + 1);
    for (int i = 0; i < m; ++i) {
        int b, e;
        std::cin >> b >> e;
        graph[b-1].push_back(e-1);
    }
    std::vector<bool> used(n + 1, false);
    std::stack<int> stack;
    for (int i = 1; i <= n; ++i) {
        if (!used[i]) {
            dfs(i, graph, used, stack);
        }
    }
    std::vector<int> distance(n + 1, 0);
    int max= 0;
    while (!stack.empty()) {
        int u = stack.top();
        stack.pop();
        for (int v : graph[u]) {
            if (distance[v] < distance[u] + 1) {
                distance[v] = distance[u] + 1;
                if (distance[v] > max) {
                    max = distance[v];
                }
            }
        }
    }
    std::cout << max + 1 << "\n";
}