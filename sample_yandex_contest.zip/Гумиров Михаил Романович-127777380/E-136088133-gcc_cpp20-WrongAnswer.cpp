#include <iostream>
#include <vector>
#include <string>

void dfs(int v, const std::vector<std::vector<int>>& graph, 
         std::vector<int>& color, bool& is_bipartite) {
    for (int to : graph[v]) {
        if (color[to] == -1) {
            color[to] = color[v] ^ 1;
            dfs(to, graph, color, is_bipartite);
        } else if (color[to] == color[v]) {
            is_bipartite = false;
        }
        if (!is_bipartite) return;
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n);
    std::vector<int> color(n, -1);
    bool is_bipartite = true;
    std::string result;

    for (int i = 0; i < m; ++i) {
        int x, y;
        std::cin >> x >> y;
        x--; y--;

        if (is_bipartite) {
            graph[x].push_back(y);
            graph[y].push_back(x);

            if (color[x] == -1 && color[y] == -1) {
                color[x] = 0;
                dfs(x, graph, color, is_bipartite);
            } else if (color[x] == -1) {
                color[x] = color[y] ^ 1;
                dfs(x, graph, color, is_bipartite);
            } else if (color[y] == -1) {
                color[y] = color[x] ^ 1;
                dfs(y, graph, color, is_bipartite);
            } else if (color[x] == color[y]) {
                is_bipartite = false;
            }
        }
        result += is_bipartite ? '1' : '0';
    }

    std::cout << result << '\n';
    return 0;
}