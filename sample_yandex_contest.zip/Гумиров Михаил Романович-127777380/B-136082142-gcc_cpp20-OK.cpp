#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

int main() {
    int n;
    std::cin >> n;
    std::vector<std::vector<int>> graph(n);
    int x;
    for (int i = 0; i < n-1; ++i) {
        std::cin >> x;
        graph[x-1].push_back(i+1);
        graph[i+1].push_back(x-1);
    }
    std::vector<bool> used(n, false);
    std::stack<std::pair<int, int>> stack;
    int max_len = -1;
    std::vector<int> ans;
    stack.push({0, 0});
    while (!stack.empty()) {
        int v = stack.top().first;
        int len = stack.top().second;
        if (len > max_len) {
            max_len = len;
            ans.clear();
            ans.push_back(v+1);
        }
        else if (len == max_len) {
            ans.push_back(v+1);
        }
        used[v] = true;
        stack.pop();
        for (auto& to : graph[v]) {
            if (!used[to]) {
                stack.push({to, len+1});
            }
        }
    }
    std::cout << max_len << "\n";
    std::cout << ans.size() << "\n";
    std::sort(ans.begin(), ans.end());
    for (auto& it : ans) {
        std::cout << it << " ";
    }
}