#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n);
    int x, y;
    for (int i = 0; i < m; ++i) {
        std::cin >> x >> y;
        graph[x-1].push_back(y-1);
        graph[y-1].push_back(x-1);
    }
    std::vector<bool> used(n, false);
    std::stack<std::pair<int, int>> stack;
    int max_len = -1;
    std::vector<int> ans;
    stack.push({0, 0});
    while (!stack.empty()) {
        int v = stack.top().first;
        int len = stack.top().second;
        if (len > max_len) {
            max_len = len;
            ans.clear();
            ans.push_back(v+1);
        }
        else if (len == max_len) {
            ans.push_back(v+1);
        }
        used[v] = true;
        stack.pop();
        for (auto& to : graph[v]) {
            if (!used[to]) {
                stack.push({to, len+1});
            }
        }
    }
    if (ans.empty()) {
        std::cout << 0;
        break;
    }
    std::vector<bool> used_(n, false);
    std::stack<std::pair<int, int>> stack_;
    int max_len_ = -1;
    std::vector<int> ans_;
    stack_.push({ans[0], 0});
    while (!stack_.empty()) {
        int v = stack_.top().first;
        int len = stack_.top().second;
        if (len > max_len_) {
            max_len_ = len;
            ans_.clear();
            ans_.push_back(v+1);
        }
        else if (len == max_len_) {
            ans_.push_back(v+1);
        }
        used_[v] = true;
        stack_.pop();
        for (auto& to : graph[v]) {
            if (!used_[to]) {
                stack_.push({to, len+1});
            }
        }
    }
    std::cout << max_len;
}