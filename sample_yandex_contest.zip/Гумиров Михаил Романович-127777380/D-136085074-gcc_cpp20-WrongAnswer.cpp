#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n);
    std::vector<std::vector<int>> new_graph(n);
    int x, y;
    for (int i = 0; i < m; ++i) {
        std::cin >> x >> y;
        graph[x-1].push_back(y-1);
        new_graph[y-1].push_back(x-1);
    }
    std::vector<bool> used(n, false);
    std::stack<std::pair<int, int>> stack;
    int max_len = -1;
    std::vector<int> ans;
    for (int i = 0; i < n; ++i) {
        if (!used[i]) {
            stack.push({i, 0});
            while (!stack.empty()) {
                int v = stack.top().first;
                int len = stack.top().second;
                if (len > max_len) {
                    max_len = len;
                    ans.clear();
                    ans.push_back(v+1);
                }
                else if (len == max_len) {
                    ans.push_back(v+1);
                }
                used[v] = true;
                stack.pop();
                for (auto& to : graph[v]) {
                    if (!used[to]) {
                        stack.push({to, len+1});
                    }
                }
            }
        }
    }
    if (!ans.empty()) {
        std::vector<bool> used(n, false);
        std::stack<std::pair<int, int>> stack;
        int max_len = -1;
        int new_v = ans[0];
        std::vector<int> ans;
        if (!used[new_v]) {
            stack.push({new_v, 0});
            while (!stack.empty()) {
                int v = stack.top().first;
                int len = stack.top().second;
                if (len > max_len) {
                    max_len = len;
                    ans.clear();
                    ans.push_back(v+1);
                }
                else if (len == max_len) {
                    ans.push_back(v+1);
                }
                used[v] = true;
                stack.pop();
                for (auto& to : new_graph[v]) {
                    if (!used[to]) {
                        stack.push({to, len+1});
                    }
                }
            }
        }
        std::cout << max_len + 1;
    }
    else {
        std::cout << 0;
    }
}