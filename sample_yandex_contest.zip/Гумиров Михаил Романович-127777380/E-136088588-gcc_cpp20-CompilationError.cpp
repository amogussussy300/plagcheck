#include <iostream>
#include <vector>
#include <algorithm>

std::pair<int, int> find(int x, std::vector<int>& parent, std::vector<int>& distance, std::vector<int>& massiv) {
    if (parent[x] != x) {
        std::pair<int, int> root_info = find(parent[x]);
        parent[x] = root_info.first;    
        massiv[x] ^= root_info.second; 
        return {parent[x], massiv[x]};
    }
    return {x, massiv[x]};
}
bool unite(int x, int y, std::vector<int>& parent, std::vector<int>& distance, std::vector<int>& massiv) {
    std::pair<int, int> x_info = find(x, parent, distance, massiv);
    std::pair<int, int> y_info = find(y, parent, distance, massiv);
    int point_x = x_info.first, parent_x = x_info.second;
    int point_y = y_info.first, parent_y = y_info.second;

    if (point_x == point_y) {
        return parent_x != parent_y;
    }

    if (distance[point_x] > distance[point_y]) {
        parent[point_y] = point_x;
        massiv[point_y] = parent_x ^ parent_y ^ 1;
    }
    else {
        parent[point_x] = point_y;
        massiv[point_x] = parent_x ^ parent_y ^ 1;
        if (distance[point_x] == distance[point_y]) {
            distance[point_y]++;
        }
    }
    return true;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<int> parent(n);
    std::vector<int> distance(n);
    std::vector<int> massiv(n);
    for (int i = 0; i < n; ++i) {
        parent[i] = i;
    }
    std::string ans(m, '0');
    bool isbiparity = true;
    for (int i = 0; i < m; ++i) {
        int u, v;
        std::cin >> u >> v;
        if (isbiparity) {
            isbiparity = unite(u-1, v-1, parent, distance, massiv);
            if (isbiparity) {
                ans[i] = '1';
            }
        }
    }
    std::cout << ans << std::endl;
}