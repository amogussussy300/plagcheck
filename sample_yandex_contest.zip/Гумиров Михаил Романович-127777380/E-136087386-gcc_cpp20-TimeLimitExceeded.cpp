#include <iostream>
#include <vector>

void check_bipartite(int v, const std::vector<std::vector<int>>& graph, std::vector<int>& used, bool& is_bipartite) {
    for(int to : graph[v]) {
        if (used[to] == 0) {
            used[to] = 3 - used[v];
            check_bipartite(to, graph, used, is_bipartite);
        } else if (used[to] == used[v]) {
            is_bipartite = false;
        }
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n);
    bool is_bipartite = true;
    
    for (int i = 0; i < m; ++i) {
        int x, y;
        std::cin >> x >> y;
        x--; y--;
        
        if (is_bipartite) {
            graph[x].push_back(y);
            graph[y].push_back(x);
            
            std::vector<int> used(n, 0);
            used[x] = 1;
            check_bipartite(x, graph, used, is_bipartite);
            
            std::cout << (is_bipartite ? 1 : 0);
        } else {
            std::cout << 0;
        }
    }
    
    return 0;
}