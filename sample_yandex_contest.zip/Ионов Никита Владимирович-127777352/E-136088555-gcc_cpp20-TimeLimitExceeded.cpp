#include <iostream>
#include <vector>

void dfs(int64_t v, int64_t color, std::vector<std::vector<int64_t>>& graph, std::vector<int64_t>& used, bool& correct) {
    for (auto to : graph[v]) {
        if (used[to] == color) {
            correct = false;
            return;
        }
        else if (used[to] == 0) {
            used[to] = 3 - color;
            dfs(to, 3 - color, graph, used, correct);
        }
    }
}

int main()
{
    int64_t n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int64_t>> graph(n);
    bool correct = true;

    for (int64_t i = 0; i < m; i++) {
        correct = true;
        int64_t from, to;
        std::cin >> from >> to;
        from--; to--;
        graph[from].push_back(to);
        graph[to].push_back(from);
        std::vector<int64_t> used(n, 0);
        for (int64_t i = 0; i < n; i++) {
            if (used[i] == 0) {
                used[i] = 1;
                dfs(i, 1, graph, used, correct);
            }
        }
        if (correct) {
            std::cout << 1;
        }
        else {
            std::cout << 0;
        }
    }


}