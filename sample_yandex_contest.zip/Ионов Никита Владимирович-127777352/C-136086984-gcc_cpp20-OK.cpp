#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

const int INF = 1e9;

int main()
{
	int n, s, m;
	std::cin >> n >> s >> m;
	s--;

	std::vector<std::vector<int>> graph(n);

	for (int i = 0; i < m; i++) {
		int from, to;
		std::cin >> from >> to;
		from--; to--;
		graph[to].push_back(from);
	}

	std::vector<int> res;
	
	std::vector<int> dist(n, INF);
	std::queue<int> q;
	q.push(s);
	dist[s] = 0;
	while (!q.empty()) {
		int cur = q.front();
		q.pop();

		for (auto to : graph[cur]) {
			if (dist[to] > dist[cur] + 1) {
				dist[to] = dist[cur] + 1;
				q.push(to);
			}
		}
	}

	for (int i = 0; i < n; i++) {
		if (dist[i] == INF) {
			std::cout << -1 << " ";
		}
		else {
			std::cout << dist[i] << " ";
		}
	}
}