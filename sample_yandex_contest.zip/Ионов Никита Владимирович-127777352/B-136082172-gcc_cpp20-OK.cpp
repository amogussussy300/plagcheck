#include <iostream>
#include <vector>
#include <queue>

const int INF = 1e9;

int main()
{
	int n;
	std::cin >> n;

	std::vector<std::vector<int>> graph(n);
	for (int i = 0; i < n - 1; i++) {
		int from, to = i + 1;
		std::cin >> from;
		from--;

		graph[from].push_back(to);
		graph[to].push_back(from);
	}

	std::vector<int> dist(n, INF);

	std::queue<int> q;
	q.push(0);
	dist[0] = 0;
	int max = 0;

	while (!q.empty()) {
		int cur = q.front();
		q.pop();

		for (auto to : graph[cur]) {
			if (dist[to] == INF) {
				dist[to] = dist[cur] + 1;
				q.push(to);
				if (dist[to] > max) {
					max = dist[to];
				}
			}
		}
	}

	std::cout << max << '\n';
	std::vector<int> res;
	for (int i = 0; i < dist.size(); i++) {
		if (dist[i] == max) {
			res.push_back(i + 1);
		}
	}
	std::cout << res.size() << '\n';
	for (auto x : res) {
		std::cout << x << " ";
	}
}