#include <iostream>
#include <stack>
#include <vector>

int main()
{
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(m);

    for (int i = 0; i < m; i++) {
        int from, to;
        std::cin >> from >> to;
        from--; to--;
        graph[from].push_back(to);
    }
    if (n == 0 || m == 0) {
        std::cout << 0;
        return 0;
    }
    std::stack<int> s;
    std::vector<int> dist(n, 0);
    std::vector<int> used(n, 0);
    used[0] = 1;
    std::pair<int, int> max = {0, 0};
    s.push(0);

    while (!s.empty()) {
        int cur = s.top();
        s.pop();

        for (auto to : graph[cur]) {
            if (used[to] != 1) {
                dist[to] = dist[cur] + 1;
                used[to] = 1;
                s.push(to);
                if (dist[to] > max.first) {
                    max.first = dist[to];
                    max.second = to;
                }
            }
        }
    }

    s.push(max.second);

    while (!s.empty()) {
        int cur = s.top();
        s.pop();

        for (auto to : graph[cur]) {
            if (dist[to] < dist[cur] + 1) {
                dist[to] = dist[cur] + 1;
                s.push(to);
                if (dist[to] > max.first) {
                    max.first = dist[to];
                }
            }
        }
    }

    std::cout << max.first;
}