#include <iostream>
#include <vector>
#include <queue>

int main()
{
	int n, m;
	std::cin >> n >> m;
	
	std::vector<std::vector<int>> graph (n);
	for (int i = 0; i < m; i++) {
		int from, to;
		std::cin >> from >> to;
		from--; to--;

		graph[from].push_back(to);
		graph[to].push_back(from);
	}

	if (m != n - 1) {
		std::cout << "NO";
		return 0;
	}

	std::vector<int> used(n, 0);

	std::queue<int> q;
	q.push(0);
	used[0] = 1;

	while (!q.empty()) {
		int cur = q.front();
		q.pop();

		for (auto to : graph[cur]) {
			if (used[to] != 1) {
				used[to] = 1;
				q.push(to);
			}
		}
	}

	for (int i = 0; i < used.size(); i++) {
		if (used[i] == 0) {
			std::cout << "NO";
			return 0;
		}
	}

	std::cout << "YES";
}