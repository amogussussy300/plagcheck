#include <iostream>
#include <vector>

void dfs(int v, int color, std::vector<std::vector<int>>& graph, std::vector<int>& used, bool& correct) {
    for (auto to : graph[v]) {
        if (used[to] == color) {
            correct = false;
            return;
        }
        else if (used[to] == 0) {
            used[to] = 3 - color;
            dfs(to, 3 - color, graph,used, correct);
        }
    }
}

int main()
{
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> graph(n);
    bool correct = true;

    for (int i = 0; i < m; i++) {
        int from, to;
        std::cin >> from >> to;
        from--; to--;
        graph[from].push_back(to);
        std::vector<int> used(n, 0);
        for (int i = 0; i < n; i++) {
            if (used[i] == 0) {
                dfs(i, 1, graph, used, correct);
            }
        }
        if (correct) {
            std::cout << 1;
        }
        else {
            std::cout << 0;
        }
        correct = true;
    }


}