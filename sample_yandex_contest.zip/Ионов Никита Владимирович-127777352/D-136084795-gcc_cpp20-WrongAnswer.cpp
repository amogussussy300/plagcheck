#include <iostream>
#include <queue>
#include <vector>

int main()
{
	int n, m;
	std::cin >> n >> m;
	std::vector<std::vector<int>> graph(n);

	for (int i = 0; i < m; i++) {
		int from, to;
		std::cin >> from >> to;
		from--; to--;
		graph[from].push_back(to);
	}
	if (n == 0 || m == 0) {
		std::cout << 0;
		return 0;
	}
	std::queue<int> q;
	std::vector<int> dist(n, 0);
	std::vector<int> used(n, 0);
	used[0] = 1;
	dist[0] = 0;
	std::pair<int, int> max = { -1, 0 };
	q.push(0);

	while (!q.empty()) {
		int cur = q.front();
		q.pop();

		for (auto to : graph[cur]) {
			if (used[to] != 1) {
				dist[to] = dist[cur] + 1;
				used[to] = 1;
				q.push(to);
				if (dist[to] > max.first) {
					max.first = dist[to];
					max.second = to;
				}
			}
		}
	}

	q.push(max.second);
	used = std::vector<int>(n, 0);
	used[max.second] = 1;
	dist = std::vector<int>(n, 0);

	while (!q.empty()) {
		int cur = q.front();
		q.pop();

		for (auto to : graph[cur]) {
			if (used[to] != 1) {
				dist[to] = dist[cur] + 1;
				q.push(to);
				if (dist[to] > max.first) {
					max.first = dist[to];
				}
				used[to] = 1;
			}
		}
	}

	std::cout << max.first;
}