#include <iostream>
#include <vector>
#include <algorithm>

int64_t dfs(int64_t v, const std::vector<std::vector<int64_t>>& graph, std::vector<int64_t>& dist, std::vector<int64_t>& visited) {
    if (visited[v]) {
        return dist[v];
    }
    visited[v] = 1;
    int64_t max = 0;
    for (int64_t to : graph[v]) {
        int64_t new_d = dfs(to, graph, dist, visited);
        max = std::max(max, 1 + new_d);
    }
    dist[v] = max;
    return dist[v];
}

int main() {
    int64_t n, m;
    std::cin >> n >> m;

    std::vector<std::vector<int64_t>> graph(n);
    for (int64_t i = 0; i < m; i++) {
        int64_t from, to;
        std::cin >> from >> to;
        from--; to--;
        graph[from].push_back(to);
    }

    std::vector<int64_t> dist(n, -1);
    std::vector<int64_t> visited(n, 0);

    int64_t max = 0;
    for (int64_t i = 0; i < n; ++i) {
        if (!visited[i]) {
            max = std::max(max, dfs(i, graph, dist, visited));
        }
    }

    std::cout << max;
}