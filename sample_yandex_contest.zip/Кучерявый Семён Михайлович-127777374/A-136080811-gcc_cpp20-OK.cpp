#include <iostream>
#include <vector>

void dfs(int v, std::vector<int>& used, const std::vector<std::vector<int>>& g) {
	used[v] = 1;
	for (int to : g[v]) {
		if (!used[to]) {
			dfs(to, used, g);
		}
	}
}

int main() {
	int n, m;
	std::cin >> n >> m;
	std::vector<std::vector<int>> g(n);
	std::vector<int> used(n, 0);
	for (int i = 0; i < m; ++i) {
		int a, b;
		std::cin >> a >> b;
		--a;
		--b;
		g[a].push_back(b);
		g[b].push_back(a);
	}
	if (m != n - 1) {
		std::cout << "NO";
		return 0;
	}
	dfs(0, used, g);
	for (int u : used) {
		if (!u) {
			std::cout << "NO";
			return 0;
		}
	}
	std::cout << "YES";
}