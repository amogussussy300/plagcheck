#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <limits>

int INF = 1e9;

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<std::pair<int, int>>> g(n);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        --a;
        --b;
        g[a].push_back({b, -1});
    }
    std::vector<int> d(n, INF);
    d[0] = 0;
    for (int i = 0; i < n - 1; ++i) {
        for (int u = 0; u < n; ++u) {
            if (d[u] != INF) {
                for (std::pair<int, int> to : g[u]) {
                    if (d[to.first] > d[u] + to.second) {
                        d[to.first] = d[u] + to.second;
                    }
                }
            }
        }
    }
    int ans = 0;
    for (int d : d) {
        if (d != INT_MAX and -d > ans) {
            ans = -d;
        }
    }
    std::cout << ans;
}