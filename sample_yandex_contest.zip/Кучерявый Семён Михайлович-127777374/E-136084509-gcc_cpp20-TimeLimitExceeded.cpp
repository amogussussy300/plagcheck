#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

bool bfs(const std::vector<std::vector<int>>& g) {
	std::vector<int> color(g.size(), -1);
	std::queue<int> q;
	for (int i = 0; i < g.size(); ++i) {
		if (color[i] == -1) {
			color[i] = 0;
			q.push(i);
			while (!q.empty()) {
				int v = q.front();
				q.pop();
				for (int to : g[v]) {
					if (color[to] == -1) {
						color[to] = (color[v] == 0 ? 1 : 0);
						q.push(to);
					}
					else if (color[to] == color[v]) {
						return false;
					}
				}
			}
		}
	}
	return true;
}

int main() {
	int n, m;
	std::cin >> n >> m;
	std::vector<std::vector<int>> g(n);
	for (int i = 0; i < m; ++i) {
		int a, b;
		std::cin >> a >> b;
		--a;
		--b;
		g[b].push_back(a);
		g[a].push_back(b);
		if (bfs(g)) {
			std::cout << 1;
		}
		else {
			std::cout << 0;
		}
	}
}