#include <iostream>
#include <vector>

int main() {
	int n, m;
	std::cin >> n >> m;
	std::vector<std::vector<int>> g(n);
	for (int i = 0; i < m; ++i) {
		int a, b;
		std::cin >> a >> b;
		--a;
		--b;
		g[a].push_back(b);
	}
	if (m == n - 1) {
		std::cout << "YES";
	}
	else {
		std::cout << "NO";
	}
}