#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

const int INF = 1e9;

std::vector<int> sort(const std::vector<std::vector<std::pair<int, int>>>& g) {
    std::vector<int> d(g.size(), 0);
    for (int u = 0; u < g.size(); ++u) {
        for (std::pair<int, int> to : g[u]) {
            ++d[to.first];
        }
    }
    std::queue<int> q;
    for (int u = 0; u < g.size(); ++u) {
        if (d[u] == 0) {
            q.push(u);
        }
    }
    std::vector<int> sortedG;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        sortedG.push_back(u);
        for (std::pair<int, int> to : g[u]) {
            if (--d[to.first] == 0) {
                q.push(to.first);
            }
        }
    }
    return sortedG;
}

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<std::pair<int, int>>> g(n);
    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        --a;
        --b;
        g[a].push_back({ b, -1 });
    }
    std::vector<int> sortedG = sort(g);
    std::vector<int> d(n, INF);
    d[0] = 0;
    for (int u : sortedG) {
        if (d[u] != INF) {
            for (std::pair<int, int> to : g[u]) {
                if (d[to.first] > d[u] + to.second) {
                    d[to.first] = d[u] + to.second;
                }
            }
        }
    }
    int ans = 0;
    for (int dist : d) {
        if (dist != INF and -dist > ans) {
            ans = -dist;
        }
    }
    std::cout << ans;
}