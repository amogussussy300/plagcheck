#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

void bfs(int v, std::vector<int>& d, std::vector<int>& used, const std::vector<std::vector<int>>& g) {
	std::queue<int> q;
	q.push(v);
	used[v] = 1;
	d[v] = 0;
	while (!q.empty()) {
		int u = q.front();
		q.pop();
		for (int to : g[u]) {
			if (d[to] == -1 and !used[to]) {
				d[to] = d[u] + 1;
				q.push(to);
				used[to] = 1;
			}
		}
	}
}

int main() {
	int n, m;
	std::cin >> n >> m;
	std::vector<std::vector<int>> g(n);
	for (int i = 0; i < m; ++i) {
		int a, b;
		std::cin >> a >> b;
		--a;
		--b;
		g[a].push_back(b);
		g[b].push_back(a);
	}
	int MAX = 0;
	for (int v = 0; v < n; ++v) {
		std::vector<int> used(n, 0);
		std::vector<int> d(n, -1);
		d[v] = 0;
		bfs(v, d, used, g);
		int maxD = -1;
		int maxV = -1;
		for (int i = 0; i < n; ++i) {
			if (d[i] > maxD) {
				maxD = d[i];
				maxV = i;
			}
		}
		std::vector<int> used1(n, 0);
		std::vector<int> d1(n, -1);
		d1[maxV] = 0;
		bfs(maxV, d1, used1, g);
		maxD = -1;
		maxV = -1;
		for (int i = 0; i < n; ++i) {
			if (d1[i] > maxD) {
				maxD = d1[i];
				maxV = i;
			}
		}
		MAX = std::max(MAX, maxD);
	}
	std::cout << MAX;
}