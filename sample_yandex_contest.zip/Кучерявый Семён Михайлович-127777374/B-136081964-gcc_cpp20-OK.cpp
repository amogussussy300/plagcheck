#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

void bfs(int v, std::vector<int>& d, const std::vector<std::vector<int>>& g) {
	std::queue<int> q;
	q.push(v);
	d[v] = 0;
	while (!q.empty()) {
		int u = q.front();
		q.pop();
		for (int to : g[u]) {
			d[to] = d[u] + 1;
			q.push(to);
		}
	}
}

int main() {
	int n;
	std::cin >> n;
	std::vector<std::vector<int>> g(n);
	std::vector<int> d(n);
	d[0] = 0;
	for (int i = 1; i < n; ++i) {
		int p;
		std::cin >> p;
		--p;
		g[p].push_back(i);
	}
	bfs(0, d, g);
	int max = 0;
	for (int x : d) {
		max = std::max(max, x);
	}
	std::vector<int> ans;
	for (int i = 0; i < n; ++i) {
		if (d[i] == max) {
			ans.push_back(i + 1);
		}
	}
	std::sort(ans.begin(), ans.end());
	std::cout << max << '\n';
	std::cout << ans.size() << '\n';
	for (int a : ans) {
		std::cout << a << ' ';
	}
}