// ConsoleApplication1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <vector>
#include <queue>

int n, s, m;
std::vector<std::vector<int>> al;
std::vector<int> v;
std::vector<int> d;



void dfs(int st) {
    for (int i = 0; i < al[st].size(); ++i) {
        int to = al[st][i];
        if (v[to] == 0) {
            v[to] = 1;
            d[to] = d[st] + 1;
            dfs(to);
        }
    }
}

void bfs(int st) {
    std::queue<int> q;
    q.push(st);
    d[st] = 0;
    v[st] = 1;
    while (!q.empty()) {
        int fr = q.front();
        q.pop();
        for (int i = 0; i < al[fr].size(); ++i) {
            int to = al[fr][i];
            if (v[to] == 0) {
                d[to] = d[fr] + 1;
                v[to] = 1;
                q.push(to);
            }
        }
    }


}

int main()
{ 
    std::cin >> n >> s >> m;
    s--;
    al.resize(n, std::vector<int>());
    v.resize(n, 0);
    d.resize(n, -1);

    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        a--;
        b--;
        al[b].push_back(a);
    }

    bfs(s);
    for (int i = 0; i < n; ++i) {
        std::cout << d[i] << ' ';
    }


    /*int mx = 0;
    for (int i = 0; i < n; ++i) {
        mx = std::max(mx, d[i]);
    }
    std::cout << mx << '\n';;
    int cnt = 0;
    for (int i = 0; i < n; ++i) {
        if (d[i] == mx) cnt++;
    }
    std::cout << cnt << '\n';;
    for (int i = 0; i < n; ++i) {
        if (d[i] == mx) std::cout << i + 1 << ' ';
    }*/
    //std::cout << ((n == m + 1 && cnt == 1) ? "YES" : "NO") << '\n';
    //std::cout << (n == m + 1) << '\n';
    //std::cout << (cnt == 1) << '\n';

}