// ConsoleApplication1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <vector>

int n;
std::vector<std::vector<int>> al;
std::vector<int> v;
std::vector<int> d;

void dfs(int st) {
    for (int i = 0; i < al[st].size(); ++i) {
        int to = al[st][i];
        if (v[to] == 0) {
            v[to] = 1;
            d[to] = d[st] + 1;
            dfs(to);
        }
    }
}

int main()
{ 
    std::cin >> n;
    al.resize(n, std::vector<int>());
    v.resize(n, 0);
    d.resize(n, 0);
    d[0] = 0;

    for (int i = 0; i < n - 1; ++i) {
        int a;
        std::cin >> a;
        a--;
        al[a].push_back(i + 1);
    }
    dfs(0);
    int mx = 0;
    for (int i = 0; i < n; ++i) {
        mx = std::max(mx, d[i]);
    }
    std::cout << mx << '\n';;
    int cnt = 0;
    for (int i = 0; i < n; ++i) {
        if (d[i] == mx) cnt++;
    }
    std::cout << cnt << '\n';;
    for (int i = 0; i < n; ++i) {
        if (d[i] == mx) std::cout << i + 1 << ' ';
    }
    //std::cout << ((n == m + 1 && cnt == 1) ? "YES" : "NO") << '\n';
    //std::cout << (n == m + 1) << '\n';
    //std::cout << (cnt == 1) << '\n';

}