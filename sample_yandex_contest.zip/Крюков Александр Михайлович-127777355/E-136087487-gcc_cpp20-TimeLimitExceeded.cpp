// ConsoleApplication1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <vector>
#include <queue>

int n, m;
std::vector<std::vector<int>> al;
std::vector<int> v;
std::vector<int> c;


int bfs(int st) {
    std::queue<int> q;
    q.push(st);
    c[st] = 0;
    v[st] = 1;
    while (!q.empty()) {
        int fr = q.front();
        q.pop();
        for (int i = 0; i < al[fr].size(); ++i) {
            int to = al[fr][i];
            if (v[to] == 1 && c[to] == c[fr]) {
                return 0;
            }
            if (v[to] == 0) {
                c[to] = 1 - c[fr];
                v[to] = 1;
                q.push(to);
            }
        }
    }
    return 1;
}


int main()
{ 
    std::cin >> n >> m;
    al.resize(n, std::vector<int>());
    c.resize(n, -1);
    int f = 1;

    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        a--;
        b--;
        al[a].push_back(b);
        al[b].push_back(a);
        v.clear();
        v.resize(n, 0);
        if (f == 0) {
            std::cout << 0;
            continue;
        }
        int doub = bfs(a);
        std::cout << doub;
        f = doub;
    }

}