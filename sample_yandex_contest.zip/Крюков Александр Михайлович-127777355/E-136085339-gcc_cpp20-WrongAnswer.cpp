// ConsoleApplication1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <vector>
#include <queue>

int n, m;
std::vector<std::vector<int>> al;
std::vector<int> c; 


int main()
{ 
    std::cin >> n >> m;
    al.resize(n, std::vector<int>());
    c.resize(n, -1);
    int doub = 1;

    for (int i = 0; i < m; ++i) {
        int a, b;
        std::cin >> a >> b;
        a--;
        b--;
        if (doub) {
            if (c[a] == -1 && c[b] == -1) {
                c[a] = 0;
                c[b] = 1;
            }
            else if (c[a] == -1 && c[b] != -1) {
                c[a] = 1 - c[b];
            }
            else if (c[a] != -1 && c[b] == -1) {
                c[b] = 1 - c[a];
            }
            else {
                if (c[a] == c[b]) doub = 0;
            }
        }
        std::cout << doub;
        al[a].push_back(b);
        al[b].push_back(a);
    }

}