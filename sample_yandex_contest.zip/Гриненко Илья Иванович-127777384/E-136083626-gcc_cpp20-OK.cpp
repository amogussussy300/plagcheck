#include <iostream>
#include <vector>
#include <string>
#include <utility>

using namespace std;

class DSU {
private:
    vector<int> parent;
    vector<int> rank;
    vector<int> color;

public:
    DSU(int n) {
        parent.resize(n + 1);
        rank.resize(n + 1, 0);
        color.resize(n + 1, 0);
        for (int i = 0; i <= n; ++i) {
            parent[i] = i;
        }
    }

    int find(int u) {
        if (parent[u] != u) {
            int orig_parent = parent[u];
            parent[u] = find(parent[u]);
            color[u] ^= color[orig_parent];
        }
        return parent[u];
    }

    bool union_set(int u, int v) {
        int root_u = find(u);
        int root_v = find(v);

        if (root_u == root_v) {
            return (color[u] == color[v]);
        }

        if (rank[root_u] > rank[root_v]) {
            swap(root_u, root_v);
            swap(u, v);
        }

        parent[root_u] = root_v;
        color[root_u] = 1 ^ color[u] ^ color[v];
        if (rank[root_u] == rank[root_v]) {
            rank[root_v]++;
        }
        return false;
    }
};

int main() {
    int n, m;
    cin >> n >> m;

    vector<pair<int, int>> edges;
    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        edges.emplace_back(a, b);
    }

    string result;
    DSU dsu(n);
    bool is_bipartite = true;

    for (auto &edge : edges) {
        int u = edge.first;
        int v = edge.second;

        if (!is_bipartite) {
            result += '0';
            continue;
        }

        // Проверка на конфликт при добавлении ребра
        bool conflict = dsu.union_set(u, v);
        if (conflict) {
            is_bipartite = false;
            result += '0';
        } else {
            result += '1';
        }
    }

    cout << result << endl;
    return 0;
}
