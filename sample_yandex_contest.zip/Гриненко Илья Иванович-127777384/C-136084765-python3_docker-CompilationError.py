#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

int main() {
    int n, z, m;
    cin >> n >> z >> m;

    vector<vector<int>> reverse_graph(n + 1);
    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        reverse_graph[b].push_back(a); 
    }

    vector<int> distance(n + 1, -1);
    queue<int> q;
    distance[z] = 0;
    q.push(z);

    while (!q.empty()) {
        int current = q.front();
        q.pop();

        for (int neighbor : reverse_graph[current]) {
            if (distance[neighbor] == -1) {
                distance[neighbor] = distance[current] + 1;
                q.push(neighbor);
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        cout << distance[i] << " ";
    }

    return 0;
}