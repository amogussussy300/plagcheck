#include <iostream>
#include <vector>
#include <queue>

void dij(std::vector<std::vector<std::pair<int, int>>>& g, std::vector<int>& p, std::vector<int>& d, int s) {
  std::priority_queue<std::pair<int, int>> q;
  d[s] = 0; 
  q.push(std::make_pair(0, s));
  while (!q.empty()) {
    int v = q.top().second;
    int cur_d = -q.top().first;
    q.pop();
    if (cur_d > d[v]) {
      continue;
    }
    for (size_t j = 0; j < g[v].size(); j++) {
      int to = g[v][j].first;
      int len = g[v][j].second;
      if (d[v] + len < d[to]) {
        d[to] = d[v] + len;
        p[to] = v;
        q.push(std::make_pair(-d[to], to));
      }
    }
  }
}

int main() {
  int n = 0;
  int s = 0;
  int m = 0;
  std::cin >> n >> s >> m;
  s--;
  int c = 0;
  int b = 0;
  std::vector<std::vector<std::pair<int, int>>> g(n);
  for (int i = 0; i < m; i++) {
    std::cin >> c >> b;
    //g[c-1].push_back({b-1, 1});
    g[b-1].push_back({c-1, 1});
  }
  std::vector<int> p(n, -1);
  std::vector<int> d(n, 1e9);
  dij(g, p, d, s);
  for (int i = 0; i < n; i++) {
      if (d[i] != 1e9) {
        std::cout << d[i] << ' ';
      }
      else {
          std::cout << -1 << ' ';
      }
  }
}
