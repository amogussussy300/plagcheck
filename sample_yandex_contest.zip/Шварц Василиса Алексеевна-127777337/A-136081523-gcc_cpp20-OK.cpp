#include <iostream>
#include <vector>

void dfs(std::vector<std::vector<int>>& g,   std::vector<int>& used, int v, bool& flag, int p = -1) {
  used[v] = 1;
  for (auto to : g[v]) {
    if (flag == true) {
      return;
    }
    if (used[to] == 1 && to != p) {
      flag = true;
      return;
    }
    else if (used[to] == 1 && to == p) {
      continue;
    }
    else {
      dfs(g, used, to, flag, v);
    }
  }
  used[v] = 2;
}

int main() {
  int n = 0;
  int m = 0;
  std::cin >> n >> m;
  std::vector<std::vector<int>> g(n);
  std::vector<int> used(n, 0);
  int v;
  int a = 0;
  int b = 0;
  for (int i = 0; i < m; ++i) {
      std::cin >> a >> b;
      g[a-1].push_back(b-1);
      g[b-1].push_back(a-1);
    
  }
  bool flag = false;
  dfs(g, used, 0, flag);
  for (int i = 0; i < n; ++i) {
    if (used[i] == 0) {
      flag = true;
    }
  }
  if (!flag) {
    std::cout << "YES\n";
  }
  else {
    std::cout << "NO\n";
  }
}