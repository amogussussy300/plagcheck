#include <iostream>
#include <queue>
#include <vector>

void bfs(std::vector<std::vector<int>> m, int s, std::vector<int>& d) {
  std::queue<int> q;
  q.push(s);
  d[s] = 0;
  while (!q.empty()) {
    int v = q.front();
    q.pop();
    for (auto to : m[v]) {
      if (d[to] == -1) {
        q.push(to);
        d[to] = d[v] + 1;
      }
    }
  }

}

int main() {
  int n = 0;
  int m = 0;
  std::cin >> n >> m;
  std::vector<std::vector<int>> g(n);
  int s = 0;
  int f = 0;
  for (int i = 0; i < m; i++) {
    std::cin >> s >> f;
    g[s - 1].push_back(f - 1);
  }
  int max = 0;
  for (int i = 0; i < n; i++) {
    std::vector<int> d(n, -1);
    bfs(g, i, d);
    for (int j = 0; j < n; j++) {
        max = std::max(max, d[j]);
    }
  }
  std::cout << max;
}