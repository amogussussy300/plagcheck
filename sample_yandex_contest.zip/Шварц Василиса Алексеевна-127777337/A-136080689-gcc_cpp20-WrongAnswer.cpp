#include <iostream>
#include <vector>

void dfs(std::vector<std::vector<int>>& g, std::vector<int>& used, int v, bool& cycle, std::vector<int>& p) {
  used[v] = 1;
  for (auto to : g[v]) {
      if (used[to] == 0) {
          p[to] = v;
          dfs(g, used, to, cycle, p);
      }
      else if (used[to] == 1 && to != p[v]) {
          cycle = true;
      }
  }
      
}

int main() {
    int n = 0;
    int m = 0;
    std::cin >> n >> m;
    std::vector<std::vector<int>> g(n);
    int a = 0;
    int b = 0;
    for (int i = 0; i < m; i++) {
        std::cin >> a >> b;
        a--;
        b--;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    std::vector<int> used(n, 0);
    std::vector<int> p(n, -1);
    bool cycle = false;
    dfs(g, used, 0, cycle, p);
    if (cycle == true) {
        std::cout << "NO";
    }
    else {
        std::cout << "YES";
    }
    return 0;
}










