#include <iostream>
#include <vector>
#include <queue>


void bfs(std::vector<std::vector<int>>& g, std::vector<int>& d, int s) {
    d[s] = 0;
    std::queue<int> q;
    std::vector<int> used(g.size(), 0);
    used[s] = 1;
    q.push(s);
    while (!q.empty()) {
        int v = q.front();
        q.pop();
        for (auto to : g[v]) {
            if (d[to] == -1) {
                d[to] = d[v] + 1;
                q.push(to);
            }
        }
    }
}

int main(){
    int n = 0;
    std::cin >> n;
    std::vector<std::vector<int>> g (n);
    std::vector<int> d(n, -1);
    int s = 0;
    for (int i = 1; i < n; ++i){
        std::cin >> s;
        g[s-1].push_back(i);
    }
    bfs(g, d, 0);
    int answer = 0;
    std::vector<int> ans;
    for (int i = 0; i < n ; ++i){
        answer = std::max(answer, d[i]);
    }
    for (int i = 0; i < n; ++i){
        if (d[i] == answer){
            ans.push_back(i);
        }
    }
    std::cout << answer << '\n';
    std::cout << ans.size() << '\n';
    for (int i = 0; i < ans.size(); ++i){
        std::cout << ans[i] + 1 << ' ';
    }
    
}