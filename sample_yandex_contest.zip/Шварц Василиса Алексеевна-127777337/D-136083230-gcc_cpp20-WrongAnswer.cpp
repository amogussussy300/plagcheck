#include <iostream>
#include <queue>
#include <vector>

void bfs(std::vector<std::vector<int>> g, int s, std::vector<int>& d) {
  std::queue<int> q;
  q.push(s);
  std::vector<int> used(g.size(), 0);
  std::vector<int> p(g.size());
  used[s] = 1;
  p[s] = -1;
  while (!q.empty()) {
    int v = q.front();
    q.pop();
    for (auto to : g[v]) {
      if (!used[to]) {
        used[to] = 1;
        q.push(to);
        d[to] = d[v] + 1;
        p[to] = v;
      }
    }
  }

}

int main() {
  int n = 0;
  int m = 0;
  std::cin >> n >> m;
  std::vector<std::vector<int>> g(n);
  int s = 0;
  int f = 0;
  for (int i = 0; i < m; i++) {
    std::cin >> s >> f;
    g[s - 1].push_back(f - 1);
    g[f - 1].push_back(s - 1);
  }
  std::vector<int> d(n, 0);
  bfs(g, 0, d);
  int start = 0;
  int max = 0;
  for (int i = 0; i < n; i++) {
    if (max < d[i]) {
      max = d[i];
      start = i;
    }
  }
  std::vector<int> new_d(n, 0);
  bfs(g, start, new_d);
  int ans = 0;
  for (int i = 0; i < n; i++) {
    ans = std::max(ans, new_d[i]);
  }
  std::cout << ans;
}