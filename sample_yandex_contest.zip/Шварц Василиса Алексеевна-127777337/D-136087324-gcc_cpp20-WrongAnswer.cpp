#include <iostream>
#include <queue>
#include <vector>

void bfs(std::vector<std::vector<long long>> m, long long s, std::vector<long long>& d) {
  std::queue<long long> q;
  q.push(s);
  d[s] = 0;
  while (!q.empty()) {
    long long v = q.front();
    q.pop();
    for (auto to : m[v]) {
      if (d[to] == -1) {
        q.push(to);
        d[to] = d[v] + 1;
      }
    }
  }

}

int main() {
  long long n = 0;
  long long m = 0;
  std::cin >> n >> m;
  std::vector<std::vector<long long>> g(n);
  long long s = 0;
  long long f = 0;
  for (int i = 0; i < m; i++) {
    std::cin >> s >> f;
    g[s - 1].push_back(f - 1);
  }
  long long max = 0;
  for (size_t i = 0; i < n; i++) {
    std::vector<long long> d(n, -1);
    bfs(g, i, d);
    for (size_t j = 0; j < n; j++) {
        max = std::max(max, d[j]);
    }
  }
  std::cout << max;
}