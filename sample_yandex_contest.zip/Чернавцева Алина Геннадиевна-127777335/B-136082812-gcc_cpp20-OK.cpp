#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

void dfs(int node, int d, vector<vector<int>>& vec, vector<int>& dis) {
	dis[node] = d;
	for (int nghb : vec[node]) {
		dfs(nghb, d + 1, vec, dis);
	}
}

int main() {
	int n, max_d = 0;
	cin >> n;
	vector<vector<int>> vec(n + 1);
	vector<int> dis(n + 1, -1);
	vector<int> f;
	dis[1] = 0;

	for (int i = 2; i <= n; i++) {
		int parent;
		cin >> parent;
		vec[parent].push_back(i);
	}

	dfs(1, 0, vec, dis);

	for (int i = 1; i <= n; i++) {
		max_d = max(max_d, dis[i]);
	}

	for (int i = 1; i <= n; i++) {
		if (dis[i] == max_d) {
			f.push_back(i);
		}
	}

	sort(f.begin(), f.end());
	cout << max_d << '\n' << f.size() << '\n';
	for (int i : f) {
		cout << i << " ";
	}
	
	return 0;
}