#include <iostream>
#include <vector>

using namespace std;

vector<int> leader;
vector<int> treeSize;
vector<int> parity;
pair<int, int> find(int node) {
    if (leader[node] != node) {
        auto parentInfo = find(leader[node]);
        leader[node] = parentInfo.first;
        parity[node] ^= parentInfo.second;
    }
    return { leader[node], parity[node] };
}

bool unite(int a, int b) {
    auto aInfo = find(a);
    auto bInfo = find(b);
    int rootA = aInfo.first, parityA = aInfo.second;
    int rootB = bInfo.first, parityB = bInfo.second;

    if (rootA == rootB) {
        return parityA != parityB;
    }

    if (treeSize[rootA] < treeSize[rootB]) {
        swap(rootA, rootB);
    }

    leader[rootB] = rootA;
    parity[rootB] = parityA ^ parityB ^ 1;
    treeSize[rootA] += treeSize[rootB];

    return true;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int nodeCount, edgeCount;
    cin >> nodeCount >> edgeCount;

    leader.resize(nodeCount);
    treeSize.resize(nodeCount, 1);
    parity.resize(nodeCount, 0);

    for (int i = 0; i < nodeCount; ++i) {
        leader[i] = i;
    }

    string answer(edgeCount, '0');
    bool isBipartite = true;

    for (int i = 0; i < edgeCount; ++i) {
        int u, v;
        cin >> u >> v;
        --u; --v;

        if (isBipartite) {
            isBipartite = unite(u, v);
            answer[i] = isBipartite ? '1' : '0';
        }
    }

    cout << answer;
    return 0;
}

