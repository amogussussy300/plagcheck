#include <iostream>
#include <vector>

using namespace std;

bool dvudol(int s, vector<vector<int>>& vec, vector<int>& c) {
    vector<int> q;
    q.push_back(s);
    c[s] = 1;
    int head = 0;

    while (head < q.size()) {
        int node = q[head++];
        for (int nghb : vec[node]) {
            if (c[nghb] == -1) {
                c[nghb] = 1 - c[node];
                q.push_back(nghb);
            }
            else if (c[nghb] == c[node]) {
                return false;
            }
        }
    }
    return true;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;
    vector<vector<int>> vec(n + 1);
    vector<int> c(n + 1, -1);
    string res;

    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        vec[a].push_back(b);
        vec[b].push_back(a);

        fill(c.begin(), c.end(), -1);
        bool dv = true;

        for (int j = 1; j <= n; ++j) {
            if (c[j] == -1) {
                if (!dvudol(j, vec, c)) {
                    dv = false;
                    break;
                }
            }
        }
        if (dv) {
            res += '1';
        }
        else {
            res += '0';
        }
    }

    cout << res;
    return 0;
}

