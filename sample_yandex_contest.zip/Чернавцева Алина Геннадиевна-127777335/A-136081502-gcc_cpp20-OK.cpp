#include <iostream>
#include <vector>

using namespace std;

bool dfs(int a, int parent, vector<vector<int>>& vec, vector<bool>& vis) {
    vis[a] = true;
    for (int nghb : vec[a]) {
        if (nghb != parent) {
            if (vis[nghb]) {
                return true;
            }
            if (dfs(nghb, a, vec, vis)) {
                return true;
            }
        }
    }
    return false;
}

int main()
{
    int n, m;
    cin >> n >> m;
    vector<vector<int>> vec(n + 1);
    vector<bool> vis(n + 1, 0);

    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        vec[u].push_back(v);
        vec[v].push_back(u);
    }

    if (dfs(1, -1, vec, vis)) {
        cout << "NO" << endl;
        return 0;
    }

    for (int i = 1; i <= n; ++i) {
        if (!vis[i]) {
            cout << "NO" << endl;
            return 0;
        }
    }

    cout << "YES" << endl;
    return 0;
}
