#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
#include <string>

using namespace std;

bool dvudol(int s, vector<vector<int>>& vec, vector<int> c) {
	queue<int> q;
	q.push(s);
	c[s] = 1;

	while (!q.empty()) {
		int node = q.front();
		q.pop();

		for (int nghb : vec[node]) {
			if (c[nghb] == -1) {
				c[nghb] = 1 - c[node];
				q.push(nghb);
			}
			else if (c[nghb] == c[node]) {
				return false;
			}
		}
	}
	return true;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> vec(n + 1);
    vector<int> c(n + 1, -1);
    string res;

    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;

        vec[a].push_back(b);
        vec[b].push_back(a);
        fill(c.begin(), c.end(), -1);
        bool dv = true;

        for (int j = 1; j <= n; ++j) {
            if (c[j] == -1) {
                if (!dvudol(j, vec, c)) {
                    dv = false;
                    break;
                }
            }
        }
        
        if (dv) {
            res += '1';
        }
        else {
            res += '0';
        }
    }

    cout << res;
    return 0;
}