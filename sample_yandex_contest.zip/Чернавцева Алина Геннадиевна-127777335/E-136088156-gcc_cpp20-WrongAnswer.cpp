#include <iostream>
#include <vector>
#include <string>

using namespace std;

int find(int x, vector<int>& parent) {
    if (parent[x] != x) {
        parent[x] = find(parent[x], parent);
    }
    return parent[x];
}

bool unionSets(int x, int y, vector<int>& parent, vector<int>& rank, vector<int>& с) {
    int rootX = find(x, parent);
    int rootY = find(y, parent);

    if (rootX == rootY) {
        return с[x] == с[y];
    }

    if (rank[rootX] < rank[rootY]) {
        parent[rootX] = rootY;
        с[rootX] = 1 - с[y];
    }
    else if (rank[rootX] > rank[rootY]) {
        parent[rootY] = rootX;
        с[rootY] = 1 - с[x];
    }
    else {
        parent[rootY] = rootX;
        с[rootY] = 1 - с[x];
        rank[rootX]++;
    }
    return true;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;
    string res;
    vector<int> parent(n + 1);
    vector<int> rank(n + 1, 0);
    vector<int> с(n + 1, -1);

    for (int i = 1; i <= n; ++i) {
        parent[i] = i;
    
        for (int i = 0; i < m; ++i) {
            int u, v;
            cin >> u >> v;

            if (с[u] == -1 && с[v] == -1) {
                с[u] = 0;
                с[v] = 1;
            }
            if (!unionSets(u, v, parent, rank, с)) {
                res += '0';
            }
            else {
                res += '1';
            }
        }
    }

    cout << res;
    return 0;
}

