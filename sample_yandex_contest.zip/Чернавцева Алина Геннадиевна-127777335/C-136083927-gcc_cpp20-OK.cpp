#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>

using namespace std;

int main() {
	int n, s, m;
	cin >> n >> s >> m;

	vector<vector<int>> vec(n + 1);
	vector<int> dis(n + 1, -1);
	queue<int> q;

	for (int i = 0; i < m; i++) {
		int a, b;
		cin >> a >> b;
		vec[b].push_back(a);
	}

	dis[s] = 0;
	q.push(s);
	while (!q.empty()) {
		int u = q.front();
		q.pop();

		for (int i : vec[u]) {
			if (dis[i] == -1) {
				dis[i] = dis[u] + 1;
				q.push(i);
			}
		}
	}

	for (int i = 1; i <= n; i++) {
		cout << dis[i] << ' ';
	}
	return 0;
}