#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
	int n, m, head = 0, maxl = 0;
	cin >> n >> m;
	vector<vector<int>> vec(n + 1);
	vector<int> deg(n + 1, 0);
	vector<int> dp(n + 1, 0);
	vector<int> q;

	for (int i = 0; i < m; i++) {
		int a, b;
		cin >> a >> b;
		vec[a].push_back(b);
		deg[b]++;
	}

	for (int i = 1; i <= n; i++) {
		if (deg[i] == 0) {
			q.push_back(i);
		}
	}

	while (head < q.size()) {
		int a = q[head++];
		for (int i : vec[a]) {
			dp[i] = max(dp[i], dp[a] + 1);
			deg[i]--;
			if (deg[i] == 0) {
				q.push_back(i);
			}
		}
	}

	for (int i = 1; i <= n; i++) {
		maxl = max(maxl, dp[i]);
	}
	cout << maxl;
	return 0;
}