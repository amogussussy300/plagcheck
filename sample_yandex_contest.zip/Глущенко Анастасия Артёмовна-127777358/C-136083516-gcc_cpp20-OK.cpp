#include <iostream>
#include <vector>
#include <queue>
int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int n, s, m;
	std::cin >> n >> s >> m;
	std::vector<std::vector<int>>g(n + 1);
	for (int i = 0; i < m; i++) {
		int a, b;
		std::cin >> a >> b;
		g[b].push_back(a);
	}
	std::vector<int>d(n + 1, -1);
	std::queue<int>qu;
	d[s] = 0;
	qu.push(s);
	while (!qu.empty()) {
		int u = qu.front();
		qu.pop();
		for (int v : g[u]) {
			if (d[v] == -1) {
				d[v] = d[u] + 1;
				qu.push(v);
			}
		}
	}
	for (int i = 1; i <= n; i++) {
		std::cout << d[i] << (i < n ? " " : "\n");
	}
	return 0;
}