#include <iostream>
#include <vector>
void dfs(int v, const std::vector<std::vector<int>>& adj, std::vector<bool>& vis) {
    vis[v] = true;
    for (int nxt : adj[v])
        if (!vis[nxt])
            dfs(nxt, adj, vis);
}
int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int n, m;
    std::cin >> n >> m;
    if (m != n - 1) {
        std::cout << "NO";
        return 0;
    }
    std::vector<std::vector<int>> adj(n + 1);
    for (int i = 0; i < m; i++) {
        int u, v;
        std::cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    std::vector<bool> vis(n + 1, false);
    dfs(1, adj, vis);
    for (int i = 1; i <= n; i++) {
        if (!vis[i]) {
            std::cout << "NO";
            return 0;
        }
    }
    std::cout << "YES";
    return 0;
}
