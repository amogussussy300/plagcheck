#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int n;
	std::cin >> n;
	std::vector<std::vector<int>>chill(n + 1);
	for (int i = 2; i <= n; i++) {
		int p;
		std::cin >> p;
		chill[p].push_back(i);
	}
	std::vector<int>dist(n + 1, 0);
	std::queue<int>q;
	q.push(1);
	while (!q.empty()) {
		int v = q.front();
		q.pop();
		for (int c : chill[v]) {
			dist[c] = dist[v] + 1;
			q.push(c);
		}
	}
	int maxd = 0;
	for (int i = 1; i <= n; i++) {
		if (dist[i] > maxd)
			maxd = dist[i];
	}
	std::vector<int> ans;
	for (int i = 1; i <= n; i++) {
		if (dist[i] == maxd)
			ans.push_back(i);
	}
	std::sort(ans.begin(), ans.end());
	std::cout << maxd << "\n" << ans.size() << "\n";
	for (size_t i = 0; i < ans.size(); i++) {
		std::cout << ans[i] << (i + 1 < ans.size() ? " " : "\n");
	}
	return 0;
}