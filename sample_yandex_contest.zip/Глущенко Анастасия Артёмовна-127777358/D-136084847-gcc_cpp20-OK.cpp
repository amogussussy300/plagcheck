#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> g(n + 1);
    std::vector<int> indeg(n + 1, 0), dp(n + 1, 0);
    for (int i = 0; i < m; i++) {
        int u, v;
        std::cin >> u >> v;
        g[u].push_back(v);
        indeg[v]++;
    }
    std::queue<int> qu;
    for (int i = 1; i <= n; i++) {
        if (indeg[i] == 0)
            qu.push(i);
    }
    while (!qu.empty()) {
        int u = qu.front();
        qu.pop();
        for (int v : g[u]) {
            dp[v] = std::max(dp[v], dp[u] + 1);
            if (--indeg[v] == 0)
                qu.push(v);
        }
    }
    int ans = 0;
    for (int i = 1; i <= n; i++) {
        ans = std::max(ans, dp[i]);
    }
    std::cout << ans;
    return 0;
}