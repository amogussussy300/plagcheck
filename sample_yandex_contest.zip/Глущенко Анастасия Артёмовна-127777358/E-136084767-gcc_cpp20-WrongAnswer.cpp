#include <iostream>
#include <vector>
#include <string>
int findp(int x, std::vector<int> par, std::vector<int>& col) {
	if (par[x] == x)
		return x;
	int p = findp(par[x], par, col);
	col[x] ^= col[par[x]];
	return par[x] = p;
}
void unionp(int u, int v, std::vector<int>& par, std::vector<int>& rk, std::vector<int>& col, bool& bip) {
	int ru = findp(u, par, col);
	int rv = findp(v, par, col);
	if (ru == rv) {
		if (col[u] == col[v])
			bip = false;
		return;
	}
	if (rk[ru] < rk[rv])
		std::swap(ru, rv);
	par[rv] = ru;
	col[rv] = col[u] ^ col[v] ^ 1;
	if (rk[ru] == rk[rv])
		rk[ru]++;
}
int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int n, m;
	std::cin >> n >> m;
	std::vector<int>par(n + 1), rk(n + 1, 0), col(n + 1, 0);
	for (int i = 1; i <= n; i++)
		par[i] = i;
	bool bip = true;
	std::string ans;
	ans.reserve(m);
	for (int i = 0; i < m; i++) {
		int u, v;
		std::cin >> u >> v;
		if (bip)
			unionp(u, v, par, rk, col, bip);
		ans.push_back(bip ? '1' : '0');
	}
	std::cout << ans;
	return 0;
}