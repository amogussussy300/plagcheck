#include <iostream>
#include <vector>

using namespace std;

class GraphChecker {
    vector<int> roots;
    vector<int> levels;
    vector<int> sizes;
    
public:
    GraphChecker(int n) : roots(n+1), levels(n+1), sizes(n+1, 1) {
        for (int i = 0; i <= n; ++i) {
            roots[i] = i;
            levels[i] = 0;
        }
    }
    
    int getRoot(int node) {
        if (roots[node] != node) {
            int original_root = roots[node];
            roots[node] = getRoot(roots[node]);
            levels[node] ^= levels[original_root];
        }
        return roots[node];
    }
    
    bool checkEdge(int a, int b) {
        int rootA = getRoot(a);
        int rootB = getRoot(b);
        
        if (rootA == rootB) {
            return levels[a] != levels[b];
        }
        
        if (sizes[rootA] < sizes[rootB]) {
            swap(rootA, rootB);
            swap(a, b);
        }
        
        roots[rootB] = rootA;
        levels[rootB] = 1 ^ levels[a] ^ levels[b];
        sizes[rootA] += sizes[rootB];
        
        return true;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int vertexCount, edgeCount;
    cin >> vertexCount >> edgeCount;
    
    GraphChecker checker(vertexCount);
    string output;
    bool valid = true;
    
    for (int i = 0; i < edgeCount; ++i) {
        int from, to;
        cin >> from >> to;
        
        if (valid) {
            valid = checker.checkEdge(from, to);
            output += valid ? '1' : '0';
        } else {
            output += '0';
        }
    }
    
    cout << output << '\n';
    
    return 0;
}