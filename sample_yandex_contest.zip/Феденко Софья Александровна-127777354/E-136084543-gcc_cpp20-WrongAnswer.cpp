#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct D {
    vector<int> p, r, c;

    D(int n) {
        p.resize(n + 1);
        r.resize(n + 1, 0);
        c.resize(n + 1, 0);
        for (int i = 1; i <= n; ++i) p[i] = i;
    }

    int f(int u) {
        if (p[u] != u) {
            int op = p[u];
            p[u] = f(p[u]);
            c[u] ^= c[op];
        }
        return p[u];
    }

    bool u(int u, int v) {
        int ru = f(u), rv = f(v);
        if (ru == rv) return c[u] != c[v];
        if (r[ru] > r[rv]) {
            p[rv] = ru;
            c[rv] = c[u] ^ c[v] ^ 1;
        } else {
            p[ru] = rv;
            c[ru] = c[u] ^ c[v] ^ 1;
            if (r[ru] == r[rv]) r[rv]++;
        }
        return true;
    }
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    D d(n);
    string res;

    while (m--) {
        int u, v;
        cin >> u >> v;
        res += d.u(u, v) ? '1' : '0';
    }

    cout << res << endl;
}