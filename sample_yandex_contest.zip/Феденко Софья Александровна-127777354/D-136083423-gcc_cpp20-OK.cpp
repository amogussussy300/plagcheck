#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;

    vector<vector<int>> adj(n + 1);  
    vector<int> indeg(n + 1, 0); 
    vector<int> dp(n + 1, 0);        

    for (int i = 0; i < m; ++i) {
        int b, e;
        cin >> b >> e;
        adj[b].push_back(e);
        indeg[e]++;
    }

    queue<int> q;
    for (int i = 1; i <= n; ++i) {
        if (indeg[i] == 0) {
            q.push(i);
        }
    }

    vector<int> top;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        top.push_back(u);

        for (int v : adj[u]) {
            if (--indeg[v] == 0) {
                q.push(v);
            }
        }
    }

    int maxl = 0;
    for (int u : top) {
        for (int v : adj[u]) {
            if (dp[v] < dp[u] + 1) {
                dp[v] = dp[u] + 1;
                if (dp[v] > maxl) {
                    maxl = dp[v];
                }
            }
        }
    }

    cout << maxl << endl;

    return 0;
}
