#include <iostream>
#include <vector>
using namespace std;

struct DSU {
    vector<int> p, r, c;
    DSU(int n) : p(n+1), r(n+1,0), c(n+1,0) { for(int i=1;i<=n;++i) p[i]=i; }
    int f(int u) {
        if(p[u]!=u) {
            int op=p[u];
            p[u]=f(p[u]);
            c[u]^=c[op];
        }
        return p[u];
    }
    bool u(int u, int v) {
        int ru=f(u), rv=f(v);
        if(ru==rv) return c[u]!=c[v];
        if(r[ru]>r[rv]) swap(ru,rv), swap(u,v);
        p[ru]=rv;
        c[ru]=c[u]^c[v]^1;
        if(r[ru]==r[rv]) r[rv]++;
        return true;
    }
};

int main() {
    ios::sync_with_stdio(0); cin.tie(0);
    int n,m; cin>>n>>m;
    DSU d(n);
    string res;
    while(m--) {
        int u,v; cin>>u>>v;
        res+=d.u(u,v)?'1':'0';
    }
    cout<<res;
}