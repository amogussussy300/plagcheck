#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<vector<int>> ch(n + 1); 
    vector<int> dep(n + 1, 0);       
    queue<int> q;

    for (int i = 2; i <= n; ++i) {
        int par;
        cin >> par;
        ch[par].push_back(i);
    }

    q.push(1);  
    dep[1] = 0;

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        for (int v : ch[u]) {
            dep[v] = dep[u] + 1;
            q.push(u);
        }
    }

    int max_d = *max_element(dep.begin() + 1, dep.end());
    
    vector<int> max_ver;
    for (int i = 1; i <= n; ++i) {
        if (dep[i] == max_d) {
            max_ver.push_back(i);
        }
    }

    sort(max_ver.begin(), max_ver.end());

    cout << max_d << endl;
    cout << max_ver.size() << endl;
    for (int i = 0; i < max_ver.size(); ++i) {
        if (i > 0) cout << " ";
        cout << max_ver[i];
    }
    cout << endl;

    return 0;
}
