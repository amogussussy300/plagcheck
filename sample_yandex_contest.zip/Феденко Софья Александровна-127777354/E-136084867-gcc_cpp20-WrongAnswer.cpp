#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct BipartiteDSU {
    vector<int> parent;
    vector<int> rank;
    vector<int> color; 
    
    BipartiteDSU(int n) : parent(n+1), rank(n+1, 0), color(n+1, 0) {
        for (int i = 1; i <= n; ++i)
            parent[i] = i;
    }
    
    int find(int x) {
        if (parent[x] != x) {
            int orig_parent = parent[x];
            parent[x] = find(parent[x]);
            color[x] ^= color[orig_parent];
        }
        return parent[x];
    }
    
    bool add_edge(int x, int y) {
        int x_root = find(x);
        int y_root = find(y);
        
        if (x_root == y_root) {
            return color[x] != color[y];
        }
        
        if (rank[x_root] > rank[y_root]) {
            parent[y_root] = x_root;
            color[y_root] = color[x] ^ color[y] ^ 1;
        } else {
            parent[x_root] = y_root;
            color[x_root] = color[x] ^ color[y] ^ 1;
            if (rank[x_root] == rank[y_root])
                rank[y_root]++;
        }
        return true;
    }
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n, m;
    cin >> n >> m;
    
    BipartiteDSU dsu(n);
    string result;
    
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        if (dsu.add_edge(u, v)) {
            result += '1';
        } else {
            result += '0';
        }
    }
    
    cout << result << endl;
    
    return 0;
}