from collections import deque

n = int(input())
children = [[] for _ in range(n + 1)]
parents = [0] * (n + 1)

for i in range(2, n + 1):
    p = int(input())
    parents[i] = p
    children[p].append(i)

dist = [-1] * (n + 1)
q = deque([1])
dist[1] = 0

while q:
    u = q.popleft()
    for v in children[u]:
        if dist[v] == -1:
            dist[v] = dist[u] + 1
            q.append(v)

result = max(dist[1:])
aux = [v for v in range(1, n + 1) if dist[v] == result]

print(result)
print(len(aux))
print(*aux)
