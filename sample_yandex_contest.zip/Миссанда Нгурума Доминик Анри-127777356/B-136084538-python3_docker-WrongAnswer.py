from collections import deque

n = int(input())
parents = [0] * (n + 1)
children = [[] for _ in range(n + 1)]

for i in range(2, n + 1):
    p = int(input())
    parents[i] = p
    children[p].append(i)

adj = [0] * (n + 1)

queue = deque([1])

while queue:
    u = queue.popleft()
    for v in children[u]:
        adj[v] = adj[u] + 1
        queue.append(v)

depth = max(adj)
c = adj.count(depth)
nodes = [i for i in range(1, n + 1) if adj[i] == depth]
nodes.sort()

print(depth)
print(c)
print(*nodes)