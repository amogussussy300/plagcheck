n = int(input())
adj = [0] * (n + 1)
for i in range(2, n + 1):
    p = int(input())
    adj[i] = adj[p] + 1

depth = max(adj)
nodes = [i for i in range(1, n + 1) if adj[i] == depth]
c = len(nodes)

print(depth)
print(c)
print(' '.join(map(str, nodes)))