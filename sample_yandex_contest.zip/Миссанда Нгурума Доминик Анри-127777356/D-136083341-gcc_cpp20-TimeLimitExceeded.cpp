#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

int dfs(int u, vector<vector<int>> adj, vector<int> dist) {
    if (dist[u] != 0) {
        return dist[u];
    }

    int path = 0;
    for (int v : adj[u]) {
        path = max(path, dfs(v, adj, dist) + 1);
    }
    dist[u] = path;
    return path;
}

int main() {
    int n, m;
    cin >> n >> m;

    vector<vector<int>> adj(n + 1);
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
    }

    vector<int> dist(n + 1);

    int length, cur;
    length = 0;
    for (int i = 1; i < n + 1; ++i) {
        if (dist[i] == 0) {
            cur = dfs(i, adj, dist);
            length = max(length, cur);
        }
    }

    cout << length;

    return 0;
}