import sys
sys.setrecursionlimit(1 << 25)

def find(u):
    if parent[u] != u:
        aux = parent[u]
        parent[u] = find(parent[u])
        color[u] ^= color[aux]
    return parent[u]


n, m = map(int, input().split())
parent = list(range(n + 1))
color = [0] * (n + 1)
result = ''

flag = True

for _ in range(m):
    u, v = map(int, input().split())
    if not flag:
        result += '0'
        continue
    
    root_u = find(u)
    root_v = find(v)
    
    if root_u == root_v:
        if color[u] == color[v]:
            flag = False
    else:
        parent[root_v] = root_u
        color[root_v] = color[u] ^ color[v] ^ 1
    
    if flag:
        result += '1'
    else:
        result += '0'

print(result)