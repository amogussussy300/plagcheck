#include <iostream>
#include <vector>
using namespace std;

vector<int> parent;
vector<int> color;

int find(int u) {
    if (parent[u] != u) {
        int aux = parent[u];
        parent[u] = find(parent[u]);
        color[u] ^= color[aux];
    }
    return parent[u];
}

int main() {
    int n, m;
    cin >> n >> m;

    parent.resize(n + 1);
    color.resize(n + 1, 0);
    for (int i = 0; i <= n; ++i) {
        parent[i] = i;
    }

    string result;
    bool flag = true;

    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;

        if (!flag) {
            result += '0';
            continue;
        }

        int root_u = find(u);
        int root_v = find(v);

        if (root_u == root_v) {
            if (color[u] == color[v]) {
                flag = false;
            }
        }
        else {
            parent[root_v] = root_u;
            color[root_v] = color[u] ^ color[v] ^ 1;
        }

        if (flag) {
            result += '1';
        }
        else {
            result += '0';
        }
    }

    cout << result << endl;

    return 0;
}